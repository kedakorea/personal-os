# -*- coding: utf-8 -*-
"""퍼스널 OS — 네이버 블로그 글 올리기 견본 (윈도우·맥 공용, 자동화 크롬 사용)

준비: 'AutoChrome.bat' 로 크롬을 띄우고, 그 크롬에서 네이버에 로그인해 둔다.
글 폴더 구성:
    원고.txt   첫 줄 '제목: …', 다음 줄부터 본문. 사진 넣을 자리에 [사진1] [사진2] …
               ■ 로 시작하는 문단은 굵게(소제목)
    태그.txt   쉼표로 구분 (예: 블로그,홈페이지형블로그,완주)
    사진\\      1_무엇.jpg, 2_무엇.jpg … (번호로 [사진N] 과 짝지음)
실행:
    python blog_post.py <글폴더> --blog 블로그아이디            ← 기본은 '임시저장'까지만
    python blog_post.py <글폴더> --blog 블로그아이디 --publish  ← 바로 발행
    (--cat 카테고리이름 을 붙이면 발행할 때 카테고리를 고른다)
"""
import base64, glob, html, json, os, re, sys, time
import cdp

D = os.path.abspath(sys.argv[1])
ARG = sys.argv
BLOG = ARG[ARG.index("--blog") + 1]
PUBLISH = "--publish" in ARG
CAT = ARG[ARG.index("--cat") + 1] if "--cat" in ARG else ""

raw = open(os.path.join(D, "원고.txt"), encoding="utf-8").read()
title = re.search(r"^제목:\s*(.+)$", raw, re.M).group(1).strip()
body = raw.split("\n", 1)[1].strip()
tp = os.path.join(D, "태그.txt")
TAGS = [t.strip() for t in open(tp, encoding="utf-8").read().split(",") if t.strip()] if os.path.exists(tp) else []

PRE = "var w=document.getElementById('mainFrame').contentWindow,d=w.document;"
def js(code, wait=0): return cdp.js("blog.naver.com", "(function(){" + code + "})()", wait)
def comps(): return js(PRE + "return [...d.querySelectorAll('.se-component')].map(c=>c.className.split(' ')[1]).join(',')") or ""

def paste_html(h):
    # 에디터에 '붙여넣기'로 문단을 넣는다 (한 글자씩 치는 것보다 빠르고 서식이 유지됨)
    js(PRE + "var bd=[...d.querySelectorAll('iframe')].find(i=>/input_buffer/.test(i.id)).contentDocument.body;"
       "var dt=new w.DataTransfer();dt.setData('text/html',%s);dt.setData('text/plain','.');"
       "bd.dispatchEvent(new w.ClipboardEvent('paste',{clipboardData:dt,bubbles:true,cancelable:true}));return 1" % json.dumps(h, ensure_ascii=False), 1.5)

def upload_image(path):
    b = base64.b64encode(open(path, "rb").read()).decode()
    name = os.path.basename(path)
    n0 = comps().count("se-image")
    js(PRE + "var x=d.querySelector('input[type=file]#hidden-file');if(!x){var b=[...d.querySelectorAll('button')].find(z=>/^사진/.test(z.innerText.trim()));"
       "var oc=w.HTMLInputElement.prototype.click;w.HTMLInputElement.prototype.click=function(){if(this.type=='file')return;return oc.apply(this,arguments)};b.click();w.HTMLInputElement.prototype.click=oc;x=d.querySelector('input[type=file]#hidden-file');}"
       "var s=atob('%s'),u=new Uint8Array(s.length);for(var i=0;i<s.length;i++)u[i]=s.charCodeAt(i);var dt=new w.DataTransfer();dt.items.add(new w.File([u],%s,{type:'image/jpeg'}));"
       "x.files=dt.files;x.dispatchEvent(new w.Event('change',{bubbles:true}));return 1" % (b, json.dumps(name)))
    for _ in range(30):
        time.sleep(1)
        if comps().count("se-image") > n0: break
    time.sleep(1.5)

def caret_to_title():
    js(PRE + "w.focus();d.querySelector('[contenteditable=true]').focus();var els=d.querySelectorAll('.se-documentTitle .se-text-paragraph');var el=els[els.length-1];var r=el.getBoundingClientRect();"
       "var o={bubbles:true,cancelable:true,clientX:r.left+20,clientY:r.top+r.height/2,button:0,buttons:1,view:w,detail:1};var tg=d.elementFromPoint(o.clientX,o.clientY)||el;"
       "tg.dispatchEvent(new w.PointerEvent('pointerdown',o));tg.dispatchEvent(new w.MouseEvent('mousedown',o));"
       "var rg=d.createRange();rg.selectNodeContents(el);rg.collapse(false);var s=w.getSelection();s.removeAllRanges();s.addRange(rg);"
       "tg.dispatchEvent(new w.PointerEvent('pointerup',o));tg.dispatchEvent(new w.MouseEvent('mouseup',o));tg.dispatchEvent(new w.MouseEvent('click',o));return 1", 0.6)

CLK = "var o={bubbles:true,cancelable:true,view:w,button:0};['pointerdown','mousedown','pointerup','mouseup','click'].forEach(t=>EL.dispatchEvent(new (t.startsWith('pointer')?w.PointerEvent:w.MouseEvent)(t,o)));"

# 1) 글쓰기 화면 열기
if not cdp.alive(): sys.exit("자동화 크롬이 꺼져 있습니다 — 'AutoChrome.bat' 를 먼저 실행하세요")
if not any("blog.naver.com" in t["url"] for t in cdp.tabs()):
    cdp.open_tab("https://blog.naver.com/%s" % BLOG, 8)
cdp.js("blog.naver.com", "window.onbeforeunload=null;location.href='https://blog.naver.com/%s?Redirect=Write&';1" % BLOG, 12)
if "nid.naver.com" in json.dumps(cdp.tabs()):
    sys.exit("네이버 로그인이 풀려 있습니다 — 자동화 크롬에서 직접 로그인한 뒤 다시 실행하세요")
js(PRE + "var b=[...d.querySelectorAll('button')].filter(x=>x.offsetParent&&x.innerText.trim()=='취소');if(b.length)b[0].click();return 1", 1.5)   # '작성 중인 글' 이어쓰기 창 닫기
js(PRE + "[...d.querySelectorAll('button')].filter(x=>x.offsetParent&&/help/.test(x.className)&&/닫기/.test(x.innerText+x.className)).forEach(x=>x.click());return 1", 1)

# 2) 본문 — 문단은 붙여넣기, [사진N] 자리는 사진 업로드
parts = re.split(r"\[사진(\d+)\]", body)
for k, chunk in enumerate(parts):
    if k % 2 == 1:
        found = sorted(glob.glob(os.path.join(D, "사진", "%s_*" % chunk)) + glob.glob(os.path.join(D, "사진", "%s.*" % chunk)))
        if found: upload_image(found[0])
        else: print("사진 %s 없음 — 건너뜀" % chunk)
        continue
    h = ""
    for p in [p.strip() for p in re.split(r"\n\s*\n", chunk) if p.strip()]:
        h += ("<p><b>%s</b></p>" % html.escape(p)) if p.startswith("■") else "<p>%s</p>" % html.escape(p).replace("\n", "<br>")
        h += "<p><br></p>"
    if h: paste_html(h)

# 3) 제목
for _ in range(3):
    caret_to_title()
    js(PRE + "var bd=[...d.querySelectorAll('iframe')].find(i=>/input_buffer/.test(i.id)).contentDocument.body;var dt=new w.DataTransfer();dt.setData('text/plain',%s);"
       "bd.dispatchEvent(new w.ClipboardEvent('paste',{clipboardData:dt,bubbles:true,cancelable:true}));return 1" % json.dumps(title, ensure_ascii=False), 4)
    if js(PRE + "return d.querySelector('.se-documentTitle').innerText.trim()") != "제목": break
print("제목:", js(PRE + "return d.querySelector('.se-documentTitle').innerText.trim()"))

# 4) 임시저장 또는 발행
if not PUBLISH:
    js(PRE + "[...d.querySelectorAll('button')].find(x=>x.innerText.trim()=='저장'&&x.offsetParent).click();return 1", 2)
    print("임시저장 완료 — 블로그 글쓰기에서 확인 후 직접 발행하세요"); sys.exit(0)
js(PRE + "var EL=[...d.querySelectorAll('button')].find(x=>x.textContent.trim()=='발행'&&!/confirm/.test(x.className));" + CLK + "return 1", 3)
if CAT:
    js(PRE + "var EL=d.querySelector('[class*=layer_publish] [class*=selectbox_button]');" + CLK + "return 1", 3)
    r = js(PRE + "var e=[...d.querySelectorAll('[data-testid^=categoryItemText_]')].find(x=>x.textContent.trim()==%s);if(!e)return 'NONE';var EL=e.closest('label,button,li')||e;" % json.dumps(CAT, ensure_ascii=False) + CLK + "return 1", 1)
    if r == "NONE": sys.exit("카테고리 '%s' 없음 — 발행 멈춤(글쓰기 화면은 열린 채)" % CAT)
if TAGS:
    js(PRE + "var L=d.querySelector('[class*=layer_publish]');var i=[...L.querySelectorAll('input')].find(x=>/태그 입력/.test(x.placeholder||''));var tags=%s;"
       "tags.forEach(function(t){i.focus();Object.getOwnPropertyDescriptor(w.HTMLInputElement.prototype,'value').set.call(i,t);i.dispatchEvent(new w.Event('input',{bubbles:true}));"
       "['keydown','keypress','keyup'].forEach(k=>i.dispatchEvent(new w.KeyboardEvent(k,{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true})));});return 1" % json.dumps(TAGS, ensure_ascii=False), 1.5)
js(PRE + "var EL=d.querySelector('[class*=layer_publish] [class*=confirm_btn]');" + CLK + "return 1")
post = ""
for _ in range(15):
    time.sleep(6)
    m = re.search(r"https://blog\.naver\.com/%s/\d+" % BLOG, json.dumps(cdp.tabs()))
    if m: post = m.group(0); break
print("발행:", post or "확인 실패 — 블로그에서 직접 확인")
