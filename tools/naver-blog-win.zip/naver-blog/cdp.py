# -*- coding: utf-8 -*-
"""퍼스널 OS — 자동화 크롬 조종 도구 (윈도우·맥 공용)
'AutoChrome.bat' 로 띄운 크롬(포트 9222)에 붙어서, 열린 탭 안에서 자바스크립트를 실행한다.
필요한 것: 파이썬 3 + `pip install websocket-client`

    import cdp
    cdp.open_tab("https://blog.naver.com/내블로그")      # 새 탭
    print(cdp.js("blog.naver.com", "document.title"))   # 주소에 blog.naver.com 이 든 탭에서 실행
    cdp.close_browser()                                   # 일 끝나면 자동화 크롬 닫기
"""
import json, time, urllib.request, urllib.parse
import websocket

PORT = 9222


def _get(path, method="GET"):
    req = urllib.request.Request("http://127.0.0.1:%d%s" % (PORT, path), method=method)
    return json.load(urllib.request.urlopen(req, timeout=5))


def alive():
    try:
        _get("/json/version"); return True
    except Exception:
        return False


def tabs():
    return [t for t in _get("/json") if t.get("type") == "page"]


def _tab(needle):
    for t in tabs():
        if needle in t.get("url", ""):
            return t
    raise RuntimeError("'%s' 가 열린 탭이 없습니다" % needle)


def _call(ws_url, method, params=None, timeout=120):
    ws = websocket.create_connection(ws_url, timeout=timeout, suppress_origin=True)
    try:
        ws.send(json.dumps({"id": 1, "method": method, "params": params or {}}))
        while True:
            r = json.loads(ws.recv())
            if r.get("id") == 1:
                if "error" in r: raise RuntimeError(r["error"])
                return r.get("result", {})
    finally:
        ws.close()


def js(needle, code, wait=0):
    """주소에 needle 이 든 탭에서 code 를 실행하고 결과(문자열·숫자 등)를 돌려준다."""
    r = _call(_tab(needle)["webSocketDebuggerUrl"], "Runtime.evaluate",
              {"expression": code, "returnByValue": True, "awaitPromise": True})
    if wait: time.sleep(wait)
    res = r.get("result", {})
    if r.get("exceptionDetails"):
        return "ERR " + str(r["exceptionDetails"].get("exception", {}).get("description", ""))[:300]
    return res.get("value")


def open_tab(url, wait=6):
    t = _get("/json/new?" + urllib.parse.quote(url, safe=":/?&=%"), method="PUT")
    time.sleep(wait)
    return t


def close_browser():
    """자동화 크롬을 닫는다 — 떠 있는 채로 두면 다른 자동화와 엉킬 수 있다."""
    try:
        _call(_get("/json/version")["webSocketDebuggerUrl"], "Browser.close", timeout=10)
    except Exception:
        pass
