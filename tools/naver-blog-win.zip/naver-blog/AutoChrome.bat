@echo off
REM Personal OS - automation Chrome (debug port 9222, separate profile)
REM First time: log in to Naver in this Chrome window yourself.
set CHROME="C:\Program Files\Google\Chrome\Application\chrome.exe"
if not exist %CHROME% set CHROME="C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
start "" %CHROME% --remote-debugging-port=9222 --user-data-dir="%USERPROFILE%\AutoChrome" --no-first-run --no-default-browser-check https://blog.naver.com
