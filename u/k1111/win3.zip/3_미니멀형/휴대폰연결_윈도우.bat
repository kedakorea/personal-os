@echo off
chcp 65001 >nul
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File ".os_키트\설치_윈도우.ps1" --phone
pause
