#!/usr/bin/env python3
"""퍼스널 OS 설치기 (설치 키트) — 설치.command 가 부른다.

순서: 클로드 코드 → 알림 부품 → 파일 깔기(적용.py) → PDF 미리보기 도구 → 자동 실행 등록 → 화면 열기 → 휴대폰 연결
몇 번을 다시 돌려도 안전하다. 이미 된 단계는 건너뛴다. 대화·할일 같은 자료는 지우지 않는다.
"""
import json, os, shutil, subprocess, sys, time, urllib.request

HOME = os.path.expanduser("~")
KIT_HERE = os.path.dirname(os.path.abspath(__file__))
OS_DIR = os.path.join(HOME, "퍼스널OS")
KIT = os.path.join(OS_DIR, ".os_키트")


def nfc_tree(root):
    """압축을 풀면 한글 파일명이 맥 방식(NFD)으로 바뀌어 'import 적용' 이 실패한다 → NFC 로 되돌림 (2026-10-18 1호 설치 때 발생)"""
    import unicodedata
    if not os.path.isdir(root):
        return
    for d, ds, fs in os.walk(root, topdown=False):
        for f in fs + ds:
            g = unicodedata.normalize("NFC", f)
            if g != f:
                try:
                    os.rename(os.path.join(d, f), os.path.join(d, g))
                except OSError:
                    pass
DATA = os.path.join(OS_DIR, ".os_데이터")
LA = os.path.join(HOME, "Library", "LaunchAgents")
PY = "/usr/bin/python3"
TS = "/Applications/Tailscale.app/Contents/MacOS/Tailscale"
CLAUDE = os.path.join(HOME, ".local", "bin", "claude")
LOG = os.path.join(HOME, "퍼스널OS_설치기록.log")


def step(n, t):
    print("\n\033[1;34m[%s] %s\033[0m" % (n, t))
    log("[%s] %s" % (n, t))


def log(t):
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(time.strftime("%F %T ") + t + "\n")


def ok(t):
    print("   \033[32m✓\033[0m " + t)
    log("  ok " + t)


def warn(t):
    print("   \033[33m!\033[0m " + t)
    log("  !! " + t)


def run(cmd, **kw):
    return subprocess.run(cmd, shell=isinstance(cmd, str), capture_output=True, text=True, **kw)


def ask(q, default=""):
    try:
        a = input("   %s%s: " % (q, " [%s]" % default if default else "")).strip()
    except EOFError:
        a = ""
    return a or default


DESIGN = os.path.join(os.path.dirname(KIT_HERE), "설계")


def load_design():
    """키트 옆 설계/ 폴더 — 인터뷰·컨펌을 마친 고객의 매니저 이름·부서표·부서 지침"""
    if not os.path.isdir(DESIGN):
        return {}
    d = {"폴더": DESIGN, "설정": {}, "부서수": 0}
    try:
        d["설정"] = json.load(open(os.path.join(DESIGN, "설정.json"), encoding="utf-8"))
    except Exception:
        pass
    try:
        d["부서수"] = len(json.load(open(os.path.join(DESIGN, "부서", "부서표.json"), encoding="utf-8")).get("부서", []))
    except Exception:
        pass
    return d


def s_hello():
    """앱을 처음 열면 매니저가 먼저 인사하고 부서를 소개한다 (설계에 첫인사.md 가 있으면 그것을, 없으면 부서표로 만든다)"""
    th = os.path.join(DATA, "threads")
    os.makedirs(th, exist_ok=True)
    if any(f.endswith(".json") for f in os.listdir(th)):
        return
    c = json.load(open(os.path.join(OS_DIR, "설정.json"), encoding="utf-8"))
    p = os.path.join(DESIGN, "첫인사.md")
    if os.path.exists(p):
        text = open(p, encoding="utf-8").read().strip()
    else:
        try:
            ds = json.load(open(os.path.join(OS_DIR, "부서", "부서표.json"), encoding="utf-8")).get("부서", [])
        except Exception:
            ds = []
        lines = ["- **%s** — %s" % (x.get("이름") or x["폴더"], x.get("일", "")) for x in ds]
        text = ("%s, 반갑습니다. 오늘부터 %s의 일을 맡은 **%s**입니다.\n\n"
                "지금 이 부서들이 대기하고 있습니다.\n%s\n\n"
                "부서를 고르실 필요 없이, 해야 할 일을 저에게 말씀만 하세요. 아침에는 **브리핑**이라고 해 주시면 오늘 할 일부터 정리해 드립니다.\n\n"
                "설치·사용 중 막히시면 브랜디움 카카오톡 채널로 편하게 물어보세요 → https://pf.kakao.com/_gMxogd"
                % (c.get("호칭", "대표님"), c.get("회사") or "회사", (c.get("실장") if c.get("실장") == c.get("직함") else (c.get("실장", "매니저") + " " + c.get("직함", "")).strip()), "\n".join(lines)))
    text += ("\n\n**가장 먼저 — 연결 4가지** (한 번만 하시면 됩니다)\n"
             "1. 구글 캘린더  2. 지메일  3. 구글 드라이브  4. 노션\n"
             "→ https://claude.ai/settings/connectors 에서 각각 **[연결]** 을 누르고 같은 구글 계정으로 허용해 주세요.\n"
             "끝나면 저에게 **\"연결했어\"** 라고 말씀해 주세요. 제가 바로 확인하고 오늘 일정부터 정리해 드립니다.")
    import uuid
    now = time.time()
    t = {"id": str(uuid.uuid4()), "session_id": str(uuid.uuid4()), "started": False, "title": "첫인사",
         "created": now, "updated": now,
         "messages": [{"role": "elvin", "text": text, "dept": "00 비서실", "ts": now}]}
    json.dump(t, open(os.path.join(th, t["id"] + ".json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    ok("첫인사 준비")


# ───────────────────────── 1. 클로드 코드
def s_claude():
    step(1, "클로드 코드 (OS의 두뇌)")
    if os.path.exists(CLAUDE) or shutil.which("claude"):
        ok("이미 설치돼 있음")
        return
    print("   공식 설치 프로그램을 받습니다 (1~2분)…")
    r = subprocess.run("curl -fsSL https://claude.ai/install.sh | bash", shell=True)
    if os.path.exists(CLAUDE):
        ok("설치 완료")
    else:
        warn("설치가 끝나지 않았습니다. 인터넷 연결을 확인하고 설치.command 를 다시 실행해 주세요.")
        sys.exit(1)


def logged_in():
    """로그인 정보가 있는 것만 보지 않고, 실제로 한 번 물어봐서 답이 오는지 본다 (만료된 로그인 걸러내기)"""
    if run(["security", "find-generic-password", "-s", "Claude Code-credentials"]).returncode != 0:
        return False
    try:
        r = run([CLAUDE, "-p", "ok", "--max-turns", "1"], timeout=90, cwd=HOME)   # 로그인 단계엔 ~/퍼스널OS 가 아직 없다 (1호 설치 때 오판)
    except Exception:
        return False
    out = (r.stdout or "") + (r.stderr or "")
    low = out.lower()
    return r.returncode == 0 and "invalid api key" not in low and "please run /login" not in low and "oauth" not in low


# ───────────────────────── 2. 알림 부품
def s_parts():
    step(2, "휴대폰 알림 부품")
    if run([PY, "-c", "import pywebpush, py_vapid"]).returncode == 0:
        ok("이미 있음")
        return
    print("   받는 중 (1~2분)…")
    run([PY, "-m", "pip", "install", "--user", "--quiet", "--upgrade", "pip"])   # 맥 기본 pip 는 너무 옛날이라 먼저 올린다
    r = run([PY, "-m", "pip", "install", "--user", "--quiet", "--only-binary=cryptography", "pywebpush"])
    if run([PY, "-c", "import pywebpush, py_vapid"]).returncode == 0:
        ok("설치 완료")
    else:
        warn("알림 부품 설치 실패 — 알림만 안 되고 나머지는 됩니다. (%s)" % (r.stderr or "")[-200:])


# ───────────────────────── 3. 파일 깔기
def s_files():
    step(3, "퍼스널 OS 파일 깔기 → ~/퍼스널OS")
    os.makedirs(DATA, exist_ok=True)
    if os.path.realpath(KIT_HERE) != os.path.realpath(KIT):
        if os.path.exists(KIT):
            shutil.rmtree(KIT)
        shutil.copytree(KIT_HERE, KIT)
    conf_p = os.path.join(OS_DIR, "설정.json")
    design = load_design()
    moved = os.path.exists(conf_p)   # 이사·재설치 — 이미 쓰던 기록이 있으면 부서 지침·추가지침을 덮어쓰지 않는다
    if not os.path.exists(conf_p):
        nfc_tree(KIT)
        sys.path.insert(0, KIT)
        import 적용
        c = dict(적용.DEFAULT)
        # 기본 키트(화면 6종 중 하나)면 그 화면으로 시작 — 고객 설계와 화면이 다르면 기본 키트 쪽을 따른다 (2026-10-28)
        base = {}
        try:
            base = json.load(open(os.path.join(KIT, "기본설정.json"), encoding="utf-8"))
        except Exception:
            pass
        c.update({k: v for k, v in base.items() if not k.startswith("_") and v not in (None, "")})
        c.update({k: v for k, v in design.get("설정", {}).items() if v not in (None, "")})
        if base.get("화면") and c.get("화면") != base["화면"]:
            warn("설계의 화면(%s)이 기본 키트 화면(%s)과 달라 기본 키트 화면으로 깝니다." % (c.get("화면"), base["화면"]))
            c["화면"] = base["화면"]
        if not c.get("비밀번호"):
            print("   앱에 들어갈 때 쓸 비밀번호를 정해 주세요 (8자 이상, 숫자만은 안 됨 · 예: brand2026). 기기마다 처음 한 번만 묻습니다.")
            while True:
                pw = ask("비밀번호")
                if len(pw) >= 8 and not pw.isdigit() and '"' not in pw and "\\" not in pw:
                    break
                warn("8자 이상, 숫자만은 안 되고 따옴표는 빼 주세요.")
            c["비밀번호"] = pw
        if not design:
            c["호칭"] = ask("매니저가 부를 호칭", c.get("호칭") or "대표님")
            c["회사"] = ask("회사(브랜드) 이름", c.get("회사", ""))
            c["실장"] = c.get("실장") or "매니저"
        json.dump(c, open(conf_p, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    if design:
        # 확정 설계 — 부서표·부서 지침·추가 지침을 먼저 깔아 두면 적용.py 가 그대로 쓴다
        src = design["폴더"]
        for root, dirs, files in os.walk(os.path.join(src, "부서")):
            for f in files:
                a = os.path.join(root, f)
                b = os.path.join(OS_DIR, os.path.relpath(a, src))
                if moved and os.path.exists(b):
                    continue
                os.makedirs(os.path.dirname(b), exist_ok=True)
                if f.endswith(".md"):
                    nfc_tree(KIT)
                    sys.path.insert(0, KIT)
                    import 적용
                    v = 적용.values(적용.load_conf())
                    open(b, "w", encoding="utf-8").write(적용.fill(open(a, encoding="utf-8").read(), v))
                else:
                    shutil.copy2(a, b)
        cs = os.path.join(src, "회사자료")
        if os.path.isdir(cs):
            shutil.copytree(cs, os.path.join(OS_DIR, "회사자료"), dirs_exist_ok=True)
            ok("회사 자료 %d개 → ~/퍼스널OS/회사자료" % len(os.listdir(cs)))
        ok("확정 설계 반영 — %s · 부서 %d개" % (design.get("설정", {}).get("실장", "실장"), design.get("부서수", 0)))
    # 웹푸시 열쇠 — 이 컴퓨터 전용으로 새로 만든다
    wp = os.path.join(DATA, "웹푸시.json")
    if not os.path.exists(wp):
        code = r'''
import json, base64, sys
from py_vapid import Vapid02
from cryptography.hazmat.primitives import serialization
v = Vapid02(); v.generate_keys()
b = lambda x: base64.urlsafe_b64encode(x).rstrip(b"=").decode()
priv = v.private_key.private_numbers().private_value.to_bytes(32, "big")
pub = v.public_key.public_bytes(serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint)
mail = sys.argv[2] or "noreply@example.com"
json.dump({"공개키": b(pub), "비밀키": b(priv), "메일": "mailto:" + mail, "설명": "휴대폰 알림용 웹푸시 열쇠. 밖에 내보내지 않는다."},
          open(sys.argv[1], "w", encoding="utf-8"), ensure_ascii=False, indent=1)
'''
        mail = json.load(open(conf_p, encoding="utf-8")).get("메일", "")
        r = run([PY, "-c", code, wp, mail])
        ok("알림 열쇠 만듦") if r.returncode == 0 else warn("알림 열쇠 실패: " + r.stderr[-200:])
    r = run([PY, os.path.join(KIT, "적용.py")])
    print("   " + (r.stdout.strip() or r.stderr.strip()[-300:]))
    # 첫 화면 '사무실'(신문 + 부서 직원) — 2026-10-18 기본 화면으로 확정
    r2 = run([PY, os.path.join(KIT, "사무실화면.py")])
    print("   " + (r2.stdout.strip() or r2.stderr.strip()[-200:]))
    run([PY, os.path.join(KIT, "적용.py")])
    for sub in ("threads", "uploads"):
        os.makedirs(os.path.join(DATA, sub), exist_ok=True)


# ───────────────────────── 4. PDF 미리보기 도구
def s_pdf():
    step(4, "PDF 미리보기 도구")
    d = os.path.join(OS_DIR, "부서", "00_비서실")
    exe, src = os.path.join(d, "pdf쪽그림"), os.path.join(d, "pdf쪽그림.swift")
    if os.path.exists(exe):
        ok("이미 있음")
        return
    if not shutil.which("swiftc"):
        warn("swiftc 없음 — PDF 미리보기만 빠집니다")
        return
    r = run(["swiftc", "-O", src, "-o", exe])
    ok("만듦") if r.returncode == 0 else warn("만들기 실패 — PDF 미리보기만 빠집니다")


# ───────────────────────── 5. 자동 실행
def plist(label, args, interval=None, at=None, keep=False, load=True, out=None):
    p = os.path.join(LA, label + ".plist")
    x = ['<?xml version="1.0" encoding="UTF-8"?>',
         '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">',
         '<plist version="1.0"><dict>',
         '<key>Label</key><string>%s</string>' % label,
         '<key>ProgramArguments</key><array>%s</array>' % "".join("<string>%s</string>" % a for a in args),
         '<key>WorkingDirectory</key><string>%s</string>' % OS_DIR,
         '<key>EnvironmentVariables</key><dict><key>PATH</key><string>%s/.local/bin:/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin</string><key>LANG</key><string>ko_KR.UTF-8</string></dict>' % HOME,
         '<key>RunAtLoad</key><%s/>' % ("true" if (keep or load) else "false")]
    if keep:
        x.append('<key>KeepAlive</key><true/>')
    if interval:
        x.append('<key>StartInterval</key><integer>%d</integer>' % interval)
    if at:
        x.append('<key>StartCalendarInterval</key><array>%s</array>' % "".join(
            "<dict><key>Hour</key><integer>%d</integer><key>Minute</key><integer>%d</integer></dict>" % hm for hm in at))
    o = out or os.path.join(DATA, label.split(".")[-1] + ".log")
    x += ['<key>StandardOutPath</key><string>%s</string>' % o, '<key>StandardErrorPath</key><string>%s</string>' % o, '</dict></plist>']
    os.makedirs(LA, exist_ok=True)
    open(p, "w", encoding="utf-8").write("\n".join(x))
    uid = os.getuid()
    run(["launchctl", "bootout", "gui/%d/%s" % (uid, label)])
    time.sleep(0.5)
    r = run(["launchctl", "bootstrap", "gui/%d" % uid, p])
    return r.returncode == 0


def s_agents():
    step(5, "자동 실행 등록 (컴퓨터를 켜면 알아서 출근)")
    b = os.path.join(OS_DIR, "부서", "00_비서실")
    jobs = [
        ("com.personalos.server", [PY, os.path.join(OS_DIR, "elvin_server.py"), "--phone"], dict(keep=True, out=os.path.join(DATA, "앱.log"))),
        ("com.personalos.loginwatch", ["/bin/bash", os.path.join(b, "로그인확인.sh")], dict(interval=10800)),
        ("com.personalos.tailscale", ["/bin/bash", os.path.join(b, "테일스케일_복구.sh")], dict(interval=600)),
        ("com.personalos.morningbrief", [PY, os.path.join(b, "자동", "아침브리핑.py")], dict(interval=600)),   # ☀️ 근무 시작 때 먼저 말 걸기 (2026-10-24)
        ("com.personalos.calendarcache", ["/bin/bash", os.path.join(b, "자동", "캘린더_캐시.sh")], dict(at=[(10, 0), (13, 0), (17, 0)], load=False)),
        # 데이터 지키기 (2026-10-19) — 매일 23:40 대화 원본·기억을 금고(옵시디언 폴더)에, 04:00 깃허브 비공개 저장소에(연결했을 때만)
        # 노션 도서관 (2026-11-08) — 매일 밤(꺼져 있었으면 다음에 켜질 때) 업무일지·대화 원본·결과물을 노션에(설치 날 Notion 커넥터 연결 필수, 기본 포함)
        ("com.personalos.notionlibrary", ["/bin/bash", os.path.join(b, "백업", "노션도서관.sh")], dict(interval=3600)),   # 한 시간마다 확인 → 22:30 이후 하루 한 번, 꺼져 있던 날은 켜지면 이월
        ("com.personalos.vaultbackup", ["/bin/bash", os.path.join(b, "백업", "금고백업.sh")], dict(at=[(23, 40)])),
        ("com.personalos.gitbackup", [PY, os.path.join(b, "백업", "깃백업.py")], dict(at=[(4, 0)])),
    ]
    # 작업 인계노트 — 대화가 압축되기 직전 지금까지 한 일을 적어 두고, 압축 뒤 다시 읽게 하는 훅
    try:
        sp = os.path.join(OS_DIR, ".claude", "settings.json"); os.makedirs(os.path.dirname(sp), exist_ok=True)
        try:
            st = json.load(open(sp, encoding="utf-8"))
        except Exception:
            st = {}
        hk = st.setdefault("hooks", {})
        hk["PreCompact"] = [{"matcher": "", "hooks": [{"type": "command", "command": PY + ' "$CLAUDE_PROJECT_DIR/부서/00_비서실/백업/인계노트_저장.py"', "timeout": 60}]}]
        hk["SessionStart"] = [{"matcher": "compact", "hooks": [{"type": "command", "command": PY + ' "$CLAUDE_PROJECT_DIR/부서/00_비서실/백업/인계노트_읽기.py"', "timeout": 30}]}]
        json.dump(st, open(sp, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
        ok("작업 인계노트 (대화가 길어져도 일이 이어지게)")
    except Exception as e:
        warn("인계노트 훅 등록 실패 — %s" % e)
    for label, args, kw in jobs:
        ok(label.split(".")[-1]) if plist(label, args, **kw) else warn(label + " 등록 실패")
    for i in range(20):
        try:
            urllib.request.urlopen("http://127.0.0.1:8765/api/hello", timeout=2)
            ok("앱 서버 켜짐 — http://127.0.0.1:8765")
            return True
        except Exception:
            time.sleep(1)
    warn("앱 서버가 아직 안 떴습니다. 로그: ~/퍼스널OS/.os_데이터/앱.log")
    return False


# ───────────────────────── 6. 휴대폰 연결
def s_phone():
    step(6, "휴대폰 연결 (테일스케일)")
    if not os.path.exists(TS):
        warn("테일스케일 앱이 없습니다. 앱스토어에서 'Tailscale' 을 받아 로그인한 뒤 '휴대폰연결.command' 를 실행하세요.")
        run(["open", "macappstore://apps.apple.com/app/tailscale/id1475387142"])
        return
    if run([TS, "status"]).returncode != 0:
        run(["open", "-a", "Tailscale"])
        warn("테일스케일에 로그인해 주세요(메뉴 막대 아이콘). 로그인 뒤 '휴대폰연결.command' 를 실행하세요.")
        return
    run([TS, "serve", "--bg", "--https=443", "http://127.0.0.1:8765"])
    try:
        dns = json.loads(run([TS, "status", "--json"]).stdout)["Self"]["DNSName"].rstrip(".")
    except Exception:
        dns = ""
    if not dns:
        warn("주소를 못 읽었습니다. 테일스케일 로그인 상태를 확인해 주세요.")
        return
    url = "https://" + dns
    conf_p = os.path.join(OS_DIR, "설정.json")
    c = json.load(open(conf_p, encoding="utf-8"))
    if c.get("보안주소") != url:
        c["보안주소"] = url
        json.dump(c, open(conf_p, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        run([PY, os.path.join(KIT, "적용.py")])
    ok("휴대폰 주소: " + url)
    print("   → 휴대폰에도 Tailscale 앱을 깔고 같은 계정으로 로그인 → 사파리로 위 주소 열기 → 공유 → '홈 화면에 추가'")
    print("   → 안드로이드(삼성 등): 크롬으로 위 주소 열기 → ⋮ → '홈 화면에 추가'. 그리고 꼭 Tailscale 앱 ⚙ → '앱별 분할 터널링'에서")
    print("     크롬(브라우저)만 Tailscale을 쓰게 하기 — 삼성페이·은행 앱이 VPN 때문에 막히지 않아요 (휴대폰연결_안내.md)")
    print("   (처음 열 때 https 인증서를 만드느라 30초쯤 걸릴 수 있어요)")


def trust_folders():
    """클로드가 처음 열 때 묻는 'Yes, I trust this folder' 를 미리 허락해 둔다 (1호 설치 때 고객이 헷갈려함)"""
    p = os.path.join(HOME, ".claude.json")
    try:
        c = json.load(open(p, encoding="utf-8")) if os.path.exists(p) else {}
        pr = c.setdefault("projects", {})
        for d in (HOME, OS_DIR):
            pr.setdefault(d, {})["hasTrustDialogAccepted"] = True
        json.dump(c, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    except Exception as e:
        log("폴더 신뢰 미리 허락 실패: %s" % e)


def s_login():
    step("1-2", "클로드 로그인 (설치 중 한 번만)")
    trust_folders()
    for n in range(3):
        if logged_in():
            ok("로그인돼 있음")
            return
        print("   클로드 창이 열리면 아래 순서대로 해 주세요:")
        print("   ① /login 입력 → 엔터")
        print("   ② 'Claude account with subscription' 고르고 엔터 → 브라우저에서 로그인·승인")
        print("   ③ 브라우저에 '사용 준비가 완료되었습니다'가 나오면 이 창으로 돌아오기")
        print("      (브라우저에 코드가 나오는 경우에만: [복사] → 이 창에 ⌘+V → 엔터)")
        print("   ④ 'Login successful' 이 보이면 엔터 → /exit 입력 → 설치가 이어집니다 (창을 닫지 마세요)")
        log("클로드 로그인 시도 %d" % (n + 1))
        subprocess.call([CLAUDE, "--dangerously-skip-permissions"], cwd=HOME)
    warn("로그인이 아직 안 됐습니다. 설치는 계속하고, 나중에 설치.command 를 다시 실행하면 이 단계부터 합니다.")


# ───────────────────────── 바탕화면·Dock 앱 (2026-10-18 1호 고객 피드백: 브라우저 탭 말고 앱처럼)
APP = os.path.join(HOME, "Applications", "퍼스널 OS.app")


def s_app():
    step("6-2", "바탕화면에 앱 아이콘 만들기")
    mac = os.path.join(APP, "Contents", "MacOS")
    res = os.path.join(APP, "Contents", "Resources")
    os.makedirs(mac, exist_ok=True)
    os.makedirs(res, exist_ok=True)
    run_sh = os.path.join(mac, "run")
    open(run_sh, "w").write("""#!/bin/bash
URL=http://127.0.0.1:8765
if [ -d "/Applications/Google Chrome.app" ]; then
  open -na "Google Chrome" --args --app="$URL" --window-size=1440,900
else
  open "$URL"
fi
""")
    os.chmod(run_sh, 0o755)
    open(os.path.join(APP, "Contents", "Info.plist"), "w").write("""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleName</key><string>퍼스널 OS</string><key>CFBundleDisplayName</key><string>퍼스널 OS</string>
<key>CFBundleIdentifier</key><string>com.personalos.app</string><key>CFBundleExecutable</key><string>run</string>
<key>CFBundleIconFile</key><string>icon</string><key>CFBundlePackageType</key><string>APPL</string><key>LSUIElement</key><false/>
</dict></plist>""")
    png = os.path.join(OS_DIR, "os_아이콘.png")
    if os.path.exists(png):
        ics = os.path.join(DATA, "icon.iconset")
        os.makedirs(ics, exist_ok=True)
        for sz in (16, 32, 128, 256, 512):
            run(["sips", "-z", str(sz), str(sz), png, "--out", os.path.join(ics, "icon_%dx%d.png" % (sz, sz))])
            run(["sips", "-z", str(sz * 2), str(sz * 2), png, "--out", os.path.join(ics, "icon_%dx%d@2x.png" % (sz, sz))])
        run(["iconutil", "-c", "icns", ics, "-o", os.path.join(res, "icon.icns")])
    run(["xattr", "-dr", "com.apple.quarantine", APP])
    desk = os.path.join(HOME, "Desktop", "퍼스널 OS")
    if not os.path.exists(desk):
        try:
            os.symlink(APP, desk)
        except OSError:
            pass
    # Dock 에도 고정
    dock = run(["defaults", "read", "com.apple.dock", "persistent-apps"])
    if "퍼스널 OS.app" not in (dock.stdout or "") and "%ED%8D%BC" not in (dock.stdout or ""):
        run(["defaults", "write", "com.apple.dock", "persistent-apps", "-array-add",
             "<dict><key>tile-data</key><dict><key>file-data</key><dict><key>_CFURLString</key><string>%s</string><key>_CFURLStringType</key><integer>0</integer></dict></dict></dict>" % APP])
        run(["killall", "Dock"])
    ok("바탕화면·Dock 에 '퍼스널 OS' 아이콘 — 앞으로 이걸 누르면 앱 창으로 열립니다")


def main():
    nfc_tree(os.path.dirname(KIT_HERE))
    print("\n\033[1m  퍼스널 OS 설치\033[0m — BRANDiUM · keda\n  중간에 멈춰도 괜찮습니다. 다시 실행하면 이어서 합니다.")
    only_phone = "--phone" in sys.argv
    if not only_phone:
        s_claude()
        s_login()
        s_parts()
        s_files()
        s_pdf()
        s_hello()
        s_agents()
    s_phone()
    if not only_phone:
        s_app()
        step(7, "연결하기 — 구글 캘린더 · 지메일 · 구글 드라이브 · 노션 (앱을 열기 전에 먼저)")
        print("   지금 열리는 클로드 설정(커넥터) 화면에서")
        print("   ① Google Calendar  ② Gmail  ③ Google Drive  ④ Notion 을 각각 [연결] → 같은 구글 계정으로 허용")
        print("   ※ Notion 은 꼭 연결해 주세요 — 매일 밤 기록을 노션 '퍼스널 OS 도서관'에 보관합니다(컴퓨터가 고장 나도 기록이 남아요)")
        print("   (클로드 로그인 화면이 먼저 나오면 같은 계정으로 로그인)")
        run(["open", "https://claude.ai/settings/connectors"])
        try:
            input("   네 개 다 연결하셨으면 엔터 ↵ (나중에 하려면 그냥 엔터)")
        except EOFError:
            pass
        step(8, "원격 도움 준비 (한 번만)")
        print("   열리는 크롬 화면에서 [원격 지원 받기]의 '다운로드'를 눌러 설치해 두면, 나중에 원격도움.command 한 번으로 바로 도와드릴 수 있어요.")
        run(["open", "https://remotedesktop.google.com/support"])
        step(9, "마무리 — 퍼스널 OS 열기")
        pw = json.load(open(os.path.join(OS_DIR, "설정.json"), encoding="utf-8")).get("비밀번호", "")
        run(["open", APP])
        ok("설치 끝 — 바탕화면·Dock 의 '퍼스널 OS' 아이콘으로 열립니다. 처음 들어갈 때 비밀번호: %s" % pw)
        if not logged_in():
            warn("클로드 로그인이 안 돼 있어 앱이 답하지 못합니다. 설치.command 를 다시 실행해 로그인해 주세요.")


if __name__ == "__main__":
    main()
