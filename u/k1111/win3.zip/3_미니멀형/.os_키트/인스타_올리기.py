#!/usr/bin/env python3
"""인스타그램에 바로 올리기 — 업로드 전용 크롬(업로드크롬.py) (2026-11-07, 본사 브랜디움 올리기를 고객 키트용으로)
사용: python3 인스타_올리기.py <결과 폴더> [--계정 아이디] [--연습]
  폴더의 *_01.mp4(있으면 맨 앞, 릴스로도 노출) + 01.jpg… 카드를 한 게시물(여러 장)로, 캡션.txt 를 캡션으로.
  --계정: 이 아이디로 로그인돼 있을 때만 올린다(여러 계정을 쓰는 분 오게시 방지). 없으면 지금 로그인된 계정.
  --연습: 공유 직전까지만 하고 닫는다.
파일은 진짜 파일 선택(DOM.setFileInputFiles)으로 넣는다 — 자바스크립트로 끼우면 인스타가 받지 않는다(2026-10-14·11-07 확인).
캡션은 진짜 입력(Input.insertText)으로 — 붙여넣기 이벤트는 화면엔 보여도 실제 게시물엔 빈 캡션으로 올라간다(2026-10-14 사고).
"""
import glob, json, os, re, subprocess, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import 업로드크롬 as UC

D = os.path.abspath(sys.argv[1]); DRY = "--연습" in sys.argv
WANT = sys.argv[sys.argv.index("--계정") + 1] if "--계정" in sys.argv else ""
cards = sorted(glob.glob(os.path.join(glob.escape(D), "[0-9][0-9].jpg")))
vid = glob.glob(os.path.join(glob.escape(D), "*_01.mp4"))
files = vid[:1] + cards[: 10 - len(vid[:1])]
cap = open(os.path.join(D, "캡션.txt"), encoding="utf-8").read().strip() if os.path.exists(os.path.join(D, "캡션.txt")) else ""
if not files: sys.exit("올릴 파일이 없어요")


def log(m): print(time.strftime("%H:%M:%S ") + m, flush=True)


T = UC.Tab("instagram.com", "https://www.instagram.com/")
j = T.js
T.go("https://www.instagram.com/", 8)
who = j("(function(){var x=new XMLHttpRequest();x.open('GET','/api/v1/accounts/edit/web_form_data/',false);x.setRequestHeader('X-IG-App-ID','936619743392459');x.send();try{return JSON.parse(x.responseText).form_data.username}catch(e){return ''}})()")
if not who: sys.exit("인스타 로그인이 안 돼 있어요 — 업로드 크롬에서 한 번 로그인해 주세요")
if WANT and who != WANT: sys.exit("지금 로그인된 계정이 %s 예요(올릴 계정: %s) — 계정 전환 후 다시" % (who, WANT))
log("계정: %s · 파일 %d개%s" % (who, len(files), " [연습]" if DRY else ""))
T.go("https://www.instagram.com/%s/" % who, 8)

DLG = "var d=[...document.querySelectorAll('[role=dialog]')].pop();"
# 새 게시물 — 메뉴 이름이 바뀌어 왔다('새로운 게시물' → '게시물', 2026-11-07)
j("(function(){var s=document.querySelector('svg[aria-label=\"새로운 게시물\"]')||document.querySelector('svg[aria-label=\"만들기\"]')||document.querySelector('svg[aria-label=\"게시물\"]');(s.closest('a,[role=button],div[role=link]')||s.parentElement).click();return 1})()", 2)
j("(function(){var b=[...document.querySelectorAll('a,[role=button],[role=menuitem]')].find(x=>x.innerText.trim()=='게시물');if(b)b.click();return 1})()", 3)
oid = None
for _ in range(10):
    o = T.call("Runtime.evaluate", expression="[...document.querySelectorAll('[role=dialog] input[type=file]')].pop()||null")
    oid = o.get("result", {}).get("objectId")
    if oid: break
    time.sleep(1)
if not oid: sys.exit("파일 넣는 칸을 못 찾았어요")
T.call("DOM.setFileInputFiles", files=[os.path.abspath(f) for f in files], objectId=oid); time.sleep(10)
j("(function(){var b=[...document.querySelectorAll('[role=dialog] button,[role=dialog] [role=button]')].find(x=>x.innerText.trim()=='확인');if(b)b.click();return 1})()", 2)  # '동영상은 릴스로 공유' 안내
j("(function(){" + DLG + "var s=d.querySelector('svg[aria-label=\"자르기 선택\"]');if(s)(s.closest('[role=button],button')||s.parentElement).click();return 1})()", 1.5)
j("(function(){" + DLG + "var o=[...d.querySelectorAll('[role=button],button,div,span')].filter(x=>x.innerText.trim()=='4:5');var el=o[o.length-1];if(el)(el.closest('[role=button],button')||el).click();return 1})()", 1)
for _ in range(6):  # 캡션 칸이 보일 때까지 '다음'
    if j("(function(){" + DLG + "return d&&d.querySelector('div[contenteditable=true],textarea')?'y':'n'})()") == "y": break
    j("(function(){" + DLG + "var b=[...d.querySelectorAll('[role=button],button')].find(x=>x.innerText.trim()=='다음');if(b)b.click();return 1})()", 5)


def click(sel_js):
    r = j("(function(){var b=%s;if(!b)return '';var r=b.getBoundingClientRect();return (r.left+r.width/2)+','+(r.top+r.height/2)})()" % sel_js)
    if not r: return False
    x, y = map(float, r.split(","))
    for t in ("mouseMoved", "mousePressed", "mouseReleased"):
        T.call("Input.dispatchMouseEvent", type=t, x=x, y=y, button="left", clickCount=1)
    return True


ED = "[...document.querySelectorAll('[role=dialog]')].pop().querySelector('div[contenteditable=true],textarea')"
SELALL = "(function(){var e=%s;var r=document.createRange();r.selectNodeContents(e);var s=getSelection();s.removeAllRanges();s.addRange(r);return 1})()" % ED
LEN = "(function(){var e=%s;return e?e.innerText.length:0})()" % ED
if cap:
    click(ED); time.sleep(0.5); j(SELALL)
    T.call("Input.insertText", text=cap); time.sleep(1.5)
    n = int(j(LEN) or 0)
    if not (len(cap) * 0.8 <= n <= len(cap) * 1.3):
        log("캡션 다시 넣기(%d자)" % n); j(SELALL); T.call("Input.insertText", text=cap); time.sleep(1.5); n = int(j(LEN) or 0)
    log("캡션 %d자 (원래 %d자)" % (n, len(cap)))
if DRY:
    j("(function(){var c=[...document.querySelectorAll('svg[aria-label=\"닫기\"]')].pop();if(c)(c.closest('[role=button],button')||c.parentElement).click();return 1})()", 2)
    j("(function(){var b=[...document.querySelectorAll('[role=dialog] button,[role=dialog] [role=button]')].find(x=>x.innerText.trim()=='삭제');if(b)b.click();return 1})()", 2)
    log("연습 끝 — 공유하지 않고 닫음"); sys.exit(0)
if not click("[...[...document.querySelectorAll('[role=dialog]')].pop().querySelectorAll('[role=button],button')].find(x=>x.innerText.trim()=='공유하기')"):
    sys.exit("공유하기 버튼을 못 찾았어요")
ok = False
for _ in range(48):
    time.sleep(5)
    if "공유되었습니다" in j("(function(){" + DLG + "return d?d.innerText:''})()"): ok = True; break
j("(function(){" + DLG + "var b=d&&[...d.querySelectorAll('[role=button],button,svg[aria-label=\"닫기\"]')].find(x=>(x.innerText||'').trim()=='완료'||(x.getAttribute&&x.getAttribute('aria-label')=='닫기'));if(b)(b.closest&&b.closest('[role=button],button')||b).click();return 1})()", 2)
T.go("https://www.instagram.com/%s/" % who, 9)
link = j("(function(){return [...document.querySelectorAll('a[href*=\"/p/\"],a[href*=\"/reel/\"]')].slice(0,1).map(a=>a.href).join('')})()")
print(("올라간 게시물: " + link) if ok else "확인 필요 — '공유되었습니다'를 못 봤어요 (맨 위 게시물: %s)" % link)
sys.exit(0 if ok else 1)
