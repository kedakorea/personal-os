#!/usr/bin/env python3
"""퍼스널 OS — 첫 화면 '사무실' 만들기 (2026-10-18 신문판이 기본, 2026-10-19 화면 템플릿 6종 추가)

설정.json(매니저 이름·호칭·회사·화면)과 부서/부서표.json 으로 부서/00_비서실/화면추가.html 을 만든다.
설정.json 의 "화면" 이 hq·minimal·diary·magazine·village·cyworld 중 하나면 사무실_틀_<화면>.html 을 쓴다.
없거나 비어 있으면 예전 신문판(사무실_틀.html). 화면을 바꾸려면 설정.json "화면" 을 고치고 이 파일 → 적용.py 순서로 돌린다.
적용.py 가 이 파일을 앱 화면(elvin_web.html)에 붙인다 → 설정을 다시 적용해도 사라지지 않는다.
이미 고객 맞춤 화면이 있으면(맨 앞 줄에 '퍼스널 OS 사무실(기본)' 이 없으면) 건드리지 않는다.

    python3 ~/퍼스널OS/.os_키트/사무실화면.py
"""
import json, os

KIT = os.path.dirname(os.path.abspath(__file__))
OS_DIR = os.path.expanduser("~/퍼스널OS")
OUT = os.path.join(OS_DIR, "부서", "00_비서실", "화면추가.html")


CHAR = ("hq", "village", "cyworld")
FONTS = ('<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/orioncactus/pretendard@v1.3.9/dist/web/static/pretendard.min.css">'
         '<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/galmuri@latest/dist/galmuri.css">')


def office_village(key, company, chief, call, names):
    """부서/00_비서실/오피스마을.html — 오피스마을_엔진.js + 오피스마을_스타일.css 에 회사·매니저·부서를 넣어 혼자 열리는 화면으로"""
    css = open(os.path.join(KIT, "오피스마을_스타일.css"), encoding="utf-8").read()
    js = open(os.path.join(KIT, "오피스마을_엔진.js"), encoding="utf-8").read()
    cfg = {"c": key, "company": company, "chief": chief, "call": call, "sec": "비서실",
           "depts": [n for n in names if n != "비서실"]}
    html = ('<!doctype html><html lang="ko"><head><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width, initial-scale=1">'
            '<title>%s 오피스·마을</title>\n<!-- 퍼스널 OS 사무실(기본) — 사무실화면.py 가 만든다. 직접 고치지 말고 .os_키트/오피스마을_*.{js,css} -->\n%s<style>%s</style></head>'
            '<body class="c-%s"><div id="top"></div><div id="stage"><canvas id="cv" width="400" height="236"></canvas><div id="ov"></div></div>'
            '<script>window.OSV=%s;</script><script>%s</script></body></html>'
            % (company, FONTS, css, key, json.dumps(cfg, ensure_ascii=False), js))
    p = os.path.join(OS_DIR, "부서", "00_비서실", "오피스마을.html")
    os.makedirs(os.path.dirname(p), exist_ok=True)
    open(p, "w", encoding="utf-8").write(html)


def main():
    if os.path.exists(OUT) and "퍼스널 OS 사무실(기본)" not in open(OUT, encoding="utf-8").read(300):
        print("맞춤 사무실 화면이 있어 그대로 둡니다")
        return
    c = json.load(open(os.path.join(OS_DIR, "설정.json"), encoding="utf-8"))
    try:
        ds = json.load(open(os.path.join(OS_DIR, "부서", "부서표.json"), encoding="utf-8")).get("부서", [])
    except Exception:
        ds = []
    art = json.load(open(os.path.join(KIT, "사무실_그림.json"), encoding="utf-8"))
    title = (c.get("직함") or "매니저").strip()
    name = (c.get("실장") or "").strip()
    chief = title if not name or name == title else "%s %s" % (name, title)
    call = c.get("호칭") or "대표님"
    company = (c.get("회사") or "").split("·")[0].strip() or "우리 회사"
    names = [(x.get("이름") or x.get("폴더", "")).split(" ", 1)[-1] for x in ds if x.get("폴더") != "00_비서실"] or ["비서실"]
    if any(x.get("폴더") == "00_비서실" for x in ds):
        names = ["비서실"] + names
    names = names[:15]
    desks = "".join(
        '<div class="jo-desk" data-dept="%s" data-nm="%s" style="--i:%d"><span class="jo-bub">작업 중…</span>'
        '<img src="%s" alt=""><span class="jo-plate"><b>%s</b></span><span class="jo-dp">담당 직원</span><em>● 출근</em></div>'
        % (n, n, i, art["staff"][i % len(art["staff"])], n) for i, n in enumerate(names))
    links = [l for l in c.get("링크") or [] if isinstance(l, (list, tuple)) and len(l) >= 2][:4]
    lk = ""
    if links:
        lk = '<div class="jo-links"><div class="h">바로가기</div>' + "".join(
            '<a class="jo-link" href="%s" target="_blank" rel="noopener"><span class="ic">🔗</span><b>%s</b><small>%s</small><i>바로가기 →</i></a>'
            % (l[1], l[0], (l[2] if len(l) > 2 else "")) for l in links if str(l[1]).startswith("http")) + "</div>"
    news = ['%s "%s, 오늘은 무엇부터 할까요?"' % (chief, call)] + [
        "[%s] %s, 오늘도 출근 완료" % (n, n) for n in names[:6]] + [
        '[알림] 아침에는 "브리핑"이라고만 말씀하세요', "[본사] %s 직원 %d명 전원 출근" % (company, len(names))]
    key = (c.get("화면") or "").strip()
    tp = os.path.join(KIT, "사무실_틀_%s.html" % key)
    if key in CHAR:
        # 캐릭터형 3종 — 오피스·마을 전체 화면 (2026-10-28 기본 키트, 시안 오피스마을_시안_261027)
        tp = os.path.join(KIT, "사무실_틀_캐릭터.html")
        office_village(key, company, chief, call, names)
    if not key or not os.path.exists(tp):
        tp = os.path.join(KIT, "사무실_틀.html")
    t = open(tp, encoding="utf-8").read()
    extra = {}
    ap = os.path.join(KIT, "화면_그림_%s.json" % key)
    if key and os.path.exists(ap):
        extra = json.load(open(ap, encoding="utf-8"))
    J = lambda v: json.dumps(v, ensure_ascii=False)
    for k, v in {"{{화면}}": key, "{{신문}}": "%s 본사" % company, "{{회사}}": company, "{{인원}}": str(len(names) + 1),
                 "{{실장그림}}": art["boss"], "{{실장}}": chief, "{{호칭}}": call, "{{직원}}": desks,
                 "{{바로가기}}": lk, "{{기사}}": J(news), "{{부서}}": J(names), "{{그림}}": J(art),
                 "{{링크}}": J([list(l[:3]) for l in links]), "{{템플릿그림}}": J(extra)}.items():
        t = t.replace(k, v)
    if len(names) > 10:                                   # 부서가 많으면 6칸 줄
        t = t.replace("grid-template-columns:repeat(5,minmax(0,1fr));row-gap", "grid-template-columns:repeat(6,minmax(0,1fr));row-gap")
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    open(OUT, "w", encoding="utf-8").write(t)
    print("사무실 화면 — %s · %s · 직원 %d명" % (os.path.basename(tp), chief, len(names)))


if __name__ == "__main__":
    main()
