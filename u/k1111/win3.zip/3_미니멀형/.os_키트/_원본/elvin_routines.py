# -*- coding: utf-8 -*-
"""⚙️ 자동업무 보드 — 앱 '자동' 탭 (퍼스널 OS 설치 키트)
자동 업무가 남기는 로그를 읽어 오늘 상태를 보여 준다. 업무를 붙이려면 ROUTINES 에 함수 하나를 더한다.
상태: done(끝남) · running(진행 중) · wait(아직 시간 전) · fail(실패) · off(꺼짐)
"""
import datetime as dt, io, json, os, re, subprocess

HOME = os.path.expanduser("~")
DATA = os.path.join(HOME, "퍼스널OS", ".os_데이터")


def _read(p, tail=None):
    try:
        t = io.open(p, encoding="utf-8").read()
        return t[-tail:] if tail else t
    except Exception:
        return ""


def _now():
    return dt.datetime.now()


def _loaded(label):
    try:
        return subprocess.run(["launchctl", "list", label], capture_output=True, text=True, timeout=5).returncode == 0
    except Exception:
        return True


def _last_line(p):
    lines = [l for l in _read(p, 20000).splitlines() if l.strip()]
    return lines[-1] if lines else ""


def r_login():
    last = _last_line(os.path.join(DATA, "로그인확인.log"))
    bad = "풀림" in last
    return {"id": "login", "label": "com.personalos.loginwatch", "icon": "🔑", "name": "로그인 확인", "when": "3시간마다",
            "state": "fail" if bad else ("done" if last else "wait"), "time": last[11:16] if last else "",
            "summary": ("로그인이 풀렸어요 — 터미널에서 claude → /login" if bad else "로그인 살아 있음") if last else "아직 기록 없음",
            "links": [], "hist": []}


def r_calcache():
    p = os.path.join(DATA, "캘린더_캐시.json")
    try:
        m = dt.datetime.fromtimestamp(os.path.getmtime(p))
    except Exception:
        m = None
    ok = m and (_now() - m).total_seconds() < 6 * 3600 + 900
    last = _last_line(os.path.join(DATA, "캘린더_캐시.log"))
    summ = ("마지막 갱신 %s" % m.strftime("%m/%d %H:%M")) if m else ("캘린더가 아직 연결되지 않았어요" if "연결 안 됨" in last else "기록 없음")
    return {"id": "calcache", "label": "com.personalos.calendarcache", "icon": "🗓️", "name": "미니달력 갱신", "when": "출근 시간대 하루 3번",
            "state": "done" if ok else ("wait" if _now().hour < 10 else "fail"), "time": m.strftime("%H:%M") if m else "",
            "summary": summ, "links": [], "hist": []}


def r_phone():
    last = _last_line(os.path.join(DATA, "테일스케일_복구.log"))
    return {"id": "phone", "label": "com.personalos.tailscale", "icon": "📱", "name": "휴대폰 연결 지키기", "when": "10분마다",
            "state": "done", "time": last[11:16] if last else "",
            "summary": ("최근 복구: " + last[20:70]) if last else "끊긴 적 없음", "links": [], "hist": []}


ROUTINES = [r_login, r_calcache, r_phone]


def status():
    out = []
    for f in ROUTINES:
        try:
            x = f()
        except Exception as e:
            x = {"id": f.__name__, "name": f.__name__, "icon": "⚠️", "state": "fail", "summary": "상태를 못 읽음: %s" % e, "links": [], "hist": []}
        if x.get("label") and not _loaded(x["label"]):
            x["state"], x["summary"] = "off", "꺼져 있음 — " + x.get("summary", "")
        out.append(x)
    done = sum(1 for x in out if x["state"] == "done")
    return {"now": _now().strftime("%m/%d %H:%M"), "done": done, "total": len(out), "points": 0, "items": out}


RUNNABLE = {"login": "com.personalos.loginwatch", "calcache": "com.personalos.calendarcache", "phone": "com.personalos.tailscale"}


def run(id_):
    lab = RUNNABLE.get(id_)
    if not lab:
        return {"ok": False, "msg": "모르는 업무"}
    r = subprocess.run(["launchctl", "start", lab], capture_output=True, text=True)
    return {"ok": r.returncode == 0, "msg": "다시 돌리기 시작했어요" if r.returncode == 0 else (r.stderr or "실패")}


if __name__ == "__main__":
    print(json.dumps(status(), ensure_ascii=False, indent=1))
