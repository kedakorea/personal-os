# -*- coding: utf-8 -*-
"""{{실장}} 할일 목록 (2026-09-30, {{호칭}} 지시)

칸 구성
  체크리스트  : 오늘 할 일 / 내일 할 일 / 곧 할 일(빠른 시일 내)
  메모        : 앞으로 할 일 — 아직 업무일이 안 정해진 큰 일. 체크하지 않고 기록해 둔다.
                 여기서 작게 쪼갠 업무를 오늘·내일·곧 할 일로 내려보낸다(쪼갠 업무엔 어느 메모에서 왔는지 표시).
  모레 할 일  : 이틀 뒤에 할 일(2026-10-21 {{호칭}} 지시 — '날짜 정한 일'은 헷갈려서 '모레'로). 다음 날 '내일'로, 그날 '오늘'로 저절로 올라온다.
  끝난 일     : 끝낸 날짜·시간이 남는다.

규칙
- 동그라미 체크 = 그날은 그 칸에 ✓ 로 남고(체크한 날짜·시간 기록), 다음 날 끝난 일로 내려간다.
  끝난 일에는 체크한 날짜·시간이 그대로 남는다. 바로 내리려면 `끝난 일로`.
- '내일' 칸은 다음 날이 되면 저절로 '오늘'로 올라온다.
- 못 끝낸 오늘 일은 '오늘'에 남고 '밀림 N일'이 붙는다.
- 마감일이 오늘이면 '오늘'로, 내일이면 '곧 할 일'에서 '내일'로 올라온다. (메모는 자동으로 옮기지 않는다)

{{실장}}이 쓸 때 (터미널):
  python3 ~/퍼스널OS/elvin_todo.py list
  python3 ~/퍼스널OS/elvin_todo.py add "할 일" [--today|--tomorrow|--week|--later] [--due 2026-10-03] [--note "메모"] [--parent "메모 글자 일부"] [--personal] [--link URL [--link-label "버튼 이름"]]
  python3 ~/퍼스널OS/elvin_todo.py link "글자 일부" URL ["버튼 이름"]   ← 할 일에 바로가기 버튼 (응답 시트 · 폼 · 문서 등, 2026-10-07)
  python3 ~/퍼스널OS/elvin_todo.py done "글자 일부"      (체크 — 그 칸에 ✓ 로 남김)
  python3 ~/퍼스널OS/elvin_todo.py finish "글자 일부"    (바로 끝난 일로)
  python3 ~/퍼스널OS/elvin_todo.py move "글자 일부" today|tomorrow|week|later
  python3 ~/퍼스널OS/elvin_todo.py move "글자 일부" dayafter       (모레 할 일로)
  add … --dayafter   (처음부터 모레 할 일로)
  python3 ~/퍼스널OS/elvin_todo.py due "글자 일부" 2026-10-03
  python3 ~/퍼스널OS/elvin_todo.py delete "글자 일부"
  python3 ~/퍼스널OS/elvin_todo.py personal "글자 일부"   (개인 칸으로)
  python3 ~/퍼스널OS/elvin_todo.py under "글자 일부" "부모 글자 일부"   (그 할 일 아래로 묶기 · 부모를 ""로 주면 묶음에서 빼기, 2026-10-20)
  add … --under "부모 글자 일부"   (처음부터 그 할 일 아래에 넣기)
"""
import datetime, fcntl, json, os, sys, time, uuid

ROOT = os.path.dirname(os.path.abspath(__file__))
PATH = os.path.join(ROOT, ".os_데이터", "할일.json")
LOCK = PATH + ".lock"
BUCKETS = ("today", "tomorrow", "sched", "week", "later", "done")
TASKS = ("today", "tomorrow", "sched", "week")
LABEL = {"today": "오늘", "tomorrow": "내일", "sched": "모레", "week": "곧 할 일", "later": "앞으로(메모)", "done": "끝난 일"}


def today():
    return datetime.date.today().isoformat()


def tomorrow():
    return (datetime.date.today() + datetime.timedelta(days=1)).isoformat()


def now():
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M")


def _read():
    try:
        with open(PATH, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"items": [], "reminded": {}}


def _write(state):
    tmp = PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False, indent=1)
    os.replace(tmp, PATH)


def _to_done(it, when=None):
    it["prev"] = it["bucket"]
    it["done_at"] = when or it.get("checked") or now()
    it.pop("checked", None)
    it["bucket"] = "done"
    it["order"] = -time.time()


def normalize(state):
    """날짜가 바뀌었을 때 할 일을 제자리로 옮긴다."""
    t, tm = today(), tomorrow()
    for it in state["items"]:
        b = it["bucket"]
        # 체크한 일은 다음 날 끝난 일로 내려간다(오늘·내일·곧 할 일 모두). 끝난 시각 = 체크한 날짜·시간
        if b in TASKS and it.get("checked") and it["checked"][:10] < t:
            _to_done(it)
            continue
        if b == "tomorrow" and (it.get("day") or tm) <= t:
            it["bucket"] = "today"; it["since"] = it.get("day") or t; it.pop("day", None)
            b = "today"
        if b == "sched":      # 날짜 정한 일: 그날 → 오늘, 전날 → 내일
            on = it.get("on") or t
            if on <= t:
                it["bucket"] = "today"; it["since"] = on; it.pop("on", None); b = "today"
            elif on == tm:
                it["bucket"] = "tomorrow"; it["day"] = tm; it.pop("on", None); b = "tomorrow"
        if b not in TASKS or it.get("checked"):
            continue
        due = it.get("due") or ""
        if due and due <= t and b != "today":
            it["bucket"] = "today"; it["since"] = t; it.pop("day", None)
        elif due == tm and b in ("week", "sched"):
            it["bucket"] = "tomorrow"; it["day"] = tm
    # 끝난 지 오래된 일은 목록에서 내린다(파일에는 archive 로 남김)
    cut = (datetime.date.today() - datetime.timedelta(days=92)).isoformat()   # 월별로 보도록 3달 치 남김(2026-10-20)
    old = [i for i in state["items"] if i["bucket"] == "done" and (i.get("done_at") or "")[:10] < cut]
    if old:
        state.setdefault("archive", []).extend(old)
        state["items"] = [i for i in state["items"] if i not in old]
    return state


def transact(fn):
    """파일을 잠그고 읽고-고치고-쓴다. 앱과 {{실장}}이 동시에 고쳐도 안 꼬이게."""
    os.makedirs(os.path.dirname(PATH), exist_ok=True)
    with open(LOCK, "w") as lk:
        fcntl.flock(lk, fcntl.LOCK_EX)
        state = normalize(_read())
        out = fn(state)
        _write(state)
        return out if out is not None else state


def view():
    return transact(lambda s: None)


def _next_order(state, bucket):
    o = [i.get("order", 0) for i in state["items"] if i["bucket"] == bucket]
    return (max(o) + 1) if o else 0


def _place(state, it, bucket, on=""):
    """칸을 옮길 때 붙는 표시들을 정리한다."""
    it.pop("checked", None)
    it.pop("day", None)
    if bucket == "sched":
        on = on or (datetime.date.today() + datetime.timedelta(days=2)).isoformat()   # 모레
        it["on"] = on
    else:
        it.pop("on", None)
    it["bucket"] = bucket
    it["order"] = _next_order(state, bucket)
    if bucket == "today":
        it["since"] = today()
    elif bucket == "tomorrow":
        it["day"] = tomorrow()


def add(state, text, bucket="today", due="", note="", by="{{호칭}}", parent="", cat="", under="", on=""):
    text = (text or "").strip()
    if not text:
        return None
    if bucket not in BUCKETS or bucket == "done":
        bucket = "today"
    it = {"id": uuid.uuid4().hex[:8], "text": text, "bucket": bucket, "due": due or "",
          "note": note or "", "by": by, "created": now()}
    if cat == "personal":
        it["cat"] = "personal"          # 개인 할 일 — 업무 칸과 따로 보인다
    if parent:
        p = find(state, parent)
        if p:
            it["parent"] = p["id"]
    up = find(state, under) if under else None
    if up and up["bucket"] in TASKS:
        it["under"] = up["id"]; bucket = up["bucket"]          # 묶음 아래로 넣으면 부모 칸으로
        if up.get("parent") and not parent: it["parent"] = up["parent"]
        if up.get("cat") == "personal": it["cat"] = "personal"
    _place(state, it, bucket, on)
    # 새로 넣은 일은 그 칸 맨 위에 (2026-10-02 {{호칭}} 지시)
    o = [i.get("order", 0) for i in state["items"] if i["bucket"] == bucket]
    it["order"] = (min(o) - 1) if o else 0
    state["items"].append(it)
    normalize(state)
    return it


def find(state, key):
    key = (key or "").strip()
    for it in state["items"]:
        if it["id"] == key:
            return it
    hits = [i for i in state["items"] if key and key in i["text"] and i["bucket"] != "done"]
    if not hits:
        hits = [i for i in state["items"] if key and key in i["text"]]
    return hits[0] if hits else None


def edit(state, iid, **f):
    it = find(state, iid)
    if not it:
        return None
    for k in ("text", "due", "note", "link", "link_label"):
        if k in f and f[k] is not None:
            it[k] = f[k].strip() if isinstance(f[k], str) else f[k]
    normalize(state)
    return it


def move(state, iid, bucket, on=""):
    if bucket in ("dayafter", "모레"):
        bucket = "sched"
    if len(bucket or "") == 10 and bucket[4] == "-":     # 날짜를 주면 그날 오늘로 올라오게(모레 칸에 보관)
        bucket, on = "sched", bucket
    it = find(state, iid)
    if not it or bucket not in BUCKETS:
        return it
    if bucket == "done":
        _to_done(it, now())
    else:
        it.pop("done_at", None)
        # 마감일이 오늘인 일을 '내일'·'곧 할 일'로 미루면 normalize 가 다시 '오늘'로 끌어올려
        # 한 칸 아래로만 내려간 것처럼 보였다(2026-10-19). 손으로 미룬 만큼 마감일도 같이 민다.
        due, tm = it.get("due") or "", tomorrow()
        if due and bucket == "tomorrow" and due < tm:
            it["due"] = tm
        elif due and ((bucket in ("week", "later") and due <= tm) or (bucket == "sched" and due < (on or tm))):
            it["due_was"] = due
            it["due"] = ""
        _place(state, it, bucket, on)
        # 묶음(부모)을 옮기면 아래 할 일도 같이 간다 (끝난 것은 그대로)
        for c in descendants(state, it["id"]):
            if c["bucket"] in TASKS and (c["bucket"] != bucket or bucket == "sched") and bucket in TASKS:
                _place(state, c, bucket, it.get("on", ""))
    normalize(state)
    return it


def kids(state, pid):
    return [i for i in state["items"] if i.get("under") == pid]


def descendants(state, pid):
    out, todo = [], [pid]
    while todo:
        k = kids(state, todo.pop())
        out += k; todo += [c["id"] for c in k]
    return out


def nest(state, iid, under):
    """할 일을 다른 할 일 아래로 묶는다(뎁스). under 가 비면 묶음에서 뺀다. 2026-10-20 {{호칭}} 지시"""
    it = find(state, iid)
    if not it:
        return None
    if not under:
        it.pop("under", None); return it
    up = find(state, under)
    if not up or up["id"] == it["id"] or up in descendants(state, it["id"]):
        return it
    it["under"] = up["id"]
    if it["bucket"] != up["bucket"] and up["bucket"] in TASKS and it["bucket"] != "done":
        move(state, it["id"], up["bucket"])
    o = [i.get("order", 0) for i in kids(state, up["id"]) if i is not it]
    it["order"] = (max(o) + 1) if o else 0
    return it


def check(state, iid):
    """동그라미: 체크 ↔ 체크 풀기 (그 칸에 그대로). 끝난 일에서 누르면 원래 칸으로 되돌린다."""
    it = find(state, iid)
    if not it:
        return None
    if it["bucket"] == "done":
        back = it.get("prev") if it.get("prev") in TASKS else "today"
        it.pop("done_at", None)
        _place(state, it, back)
    elif it["bucket"] in TASKS:
        if it.get("checked"):
            it.pop("checked", None)
        else:
            it["checked"] = now()
    return it


def finish(state, iid):
    it = find(state, iid)
    if it and it["bucket"] != "done":
        _to_done(it, it.get("checked") or now())
    return it


def reorder(state, bucket, ids, detach=""):
    if detach:
        d = find(state, detach)
        if d: d.pop("under", None)
    pos = {iid: n for n, iid in enumerate(ids)}
    for it in state["items"]:
        if it["id"] in pos:
            if it["bucket"] != bucket:
                move(state, it["id"], bucket)      # 끌어서 옮겨도 마감일을 같이 민다(2026-10-19)
            it["order"] = pos[it["id"]]
    return True


def delete(state, iid):
    it = find(state, iid)
    if it:
        state["items"].remove(it)
        for c in state["items"]:
            if c.get("parent") == it["id"]:
                c["parent_text"] = it["text"]; c.pop("parent", None)
            if c.get("under") == it["id"]:
                c.pop("under", None)
    return it


def apply_op(body):
    """앱(/api/todo)에서 오는 요청 처리"""
    op = body.get("op")

    def fn(s):
        iid = body.get("id")
        if op == "add":
            add(s, body.get("text"), body.get("bucket") or "today", body.get("due") or "",
                body.get("note") or "", by="{{호칭}}", parent=body.get("parent") or "", cat=body.get("cat") or "", under=body.get("under") or "", on=body.get("on") or "")
        elif op == "cat":        # 업무 ↔ 개인
            it = find(s, iid)
            if it:
                if body.get("cat") == "personal":
                    it["cat"] = "personal"
                else:
                    it.pop("cat", None)
        elif op == "update":
            edit(s, iid, **{k: body[k] for k in ("text", "due", "note", "link", "link_label") if k in body})
            if body.get("bucket"):
                move(s, iid, body["bucket"], body.get("on") or "")
        elif op == "move":
            move(s, iid, body.get("bucket"), body.get("on") or "")
        elif op in ("check", "toggle"):
            check(s, iid)
        elif op == "finish":
            finish(s, iid)
        elif op == "reorder":
            reorder(s, body.get("bucket"), body.get("ids") or [], body.get("detach") or "")
        elif op == "nest":
            nest(s, iid, body.get("under") or "")
        elif op == "delete":
            delete(s, iid)
    return transact(fn)


def due_reminders():
    """아침 알림용: 오늘 마감·내일 마감(끝나지 않은 것). 하루 한 번만 돌려준다."""
    def fn(s):
        t, tm = today(), tomorrow()
        if s.setdefault("reminded", {}).get(t):
            return []
        lines = []
        for i in s["items"]:
            if i["bucket"] == "done" or i.get("checked"):
                continue
            if i.get("due") == t:
                lines.append("오늘 마감 · " + i["text"])
            elif i.get("due") == tm:
                lines.append("내일 마감 · " + i["text"])
        s["reminded"] = {t: True}
        return lines
    return transact(fn)


def _print(state):
    t = today()
    week_ago = (datetime.date.today() - datetime.timedelta(days=7)).isoformat()
    for b in BUCKETS:
        rows = sorted([i for i in state["items"] if i["bucket"] == b], key=lambda i: (i.get("on", ""), i.get("order", 0)))
        if b == "done":
            rows = [i for i in rows if (i.get("done_at") or "")[:10] >= week_ago]
        print("■ %s (%d)" % (LABEL[b], len(rows)))
        ids = {i["id"] for i in rows}
        def depth(i):
            d, seen = 0, set()
            while i.get("under") in ids and i["id"] not in seen:
                seen.add(i["id"]); i = next(x for x in rows if x["id"] == i["under"]); d += 1
            return d
        def walk(lst, out):
            for i in lst:
                out.append(i); walk([c for c in rows if c.get("under") == i["id"]], out)
            return out
        rows = walk([i for i in rows if i.get("under") not in ids], [])
        for i in rows:
            tag = []
            if i.get("on"):
                tag.append("📅 " + i["on"][5:].replace("-", "/") + "(" + "월화수목금토일"[datetime.date.fromisoformat(i["on"]).weekday()] + ")")
            if i.get("due"):
                tag.append("~" + i["due"][5:].replace("-", "/"))
            if b == "today" and (i.get("since") or t) < t:
                tag.append("밀림")
            if i.get("checked"):
                tag.append("✓ " + i["checked"][5:])
            if b == "done":
                tag.append("끝 " + (i.get("done_at") or "")[5:])
            print("  %s- [%s] %s%s%s" % ("    " * depth(i), i["id"], "🏠 " if i.get("cat") == "personal" else "", i["text"], ("  (" + ", ".join(tag) + ")") if tag else ""))


if __name__ == "__main__":
    a = sys.argv[1:]
    if not a or a[0] == "list":
        _print(view()); sys.exit()
    cmd, rest = a[0], a[1:]

    def opt(name, default=""):
        if name in rest:
            i = rest.index(name); v = rest[i + 1]; del rest[i:i + 2]; return v
        return default
    due = opt("--due"); on = opt("--on"); note = opt("--note"); parent = opt("--parent"); under = opt("--under"); link = opt("--link"); link_label = opt("--link-label")
    cat = ""
    if "--personal" in rest:
        rest.remove("--personal"); cat = "personal"
    bucket = "today"
    for f, b in (("--today", "today"), ("--tomorrow", "tomorrow"), ("--dayafter", "sched"), ("--week", "week"), ("--later", "later")):
        if f in rest:
            rest.remove(f); bucket = b
    if on:
        bucket = "sched"
    key = rest[0] if rest else ""
    if cmd == "add":
        def _a(s):
            it = add(s, key, bucket, due, note, by="{{실장}}", parent=parent, cat=cat, under=under, on=on)
            if it and link:
                edit(s, it["id"], link=link, link_label=link_label)
            return [it]
        r = transact(_a)[0]
    elif cmd == "link":
        r = transact(lambda s: [edit(s, key, link=rest[1], link_label=(rest[2] if len(rest) > 2 else ""))])[0]
    elif cmd == "personal":
        def _p(s):
            it = find(s, key)
            if it: it["cat"] = "personal"
            return [it]
        r = transact(_p)[0]
    elif cmd == "done":
        def _d(s):
            it = find(s, key)
            if it and it["bucket"] in TASKS and not it.get("checked"):
                check(s, it["id"])
            elif it and it["bucket"] == "later":
                finish(s, it["id"])
            return [it]
        r = transact(_d)[0]
    elif cmd == "under":
        r = transact(lambda s: [nest(s, key, rest[1] if len(rest) > 1 else "")])[0]
    elif cmd == "finish":
        r = transact(lambda s: [finish(s, key)])[0]
    elif cmd == "move":
        r = transact(lambda s: [move(s, key, rest[1])])[0]
    elif cmd == "due":
        r = transact(lambda s: [edit(s, key, due=rest[1])])[0]
    elif cmd == "delete":
        r = transact(lambda s: [delete(s, key)])[0]
    else:
        print(__doc__); sys.exit(1)
    print(("OK " + r["id"] + " " + r["text"] + " → " + LABEL[r["bucket"]] + (" ✓" if r.get("checked") else "")) if r else "못 찾음: " + key)
