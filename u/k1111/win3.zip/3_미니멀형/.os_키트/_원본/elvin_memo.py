#!/usr/bin/env python3
"""{{실장}} 앱 메모판 (2026-10-02 {{호칭}} 지시)

{{호칭}}이 다른 대화를 하다가도 다시 찾아볼 수 있게 고정해 두는 메모.
앱(서버)과 {{실장}}(터미널)이 같은 파일을 쓴다: .os_데이터/메모판.json

터미널에서:
  python3 ~/퍼스널OS/elvin_memo.py list
  python3 ~/퍼스널OS/elvin_memo.py add "제목" "본문"          # 본문 대신 --file 경로 도 된다
  python3 ~/퍼스널OS/elvin_memo.py show "제목 글자 일부"
"""
import fcntl
import json
import os
import sys
import time
import uuid
from contextlib import contextmanager

ROOT = os.path.dirname(os.path.abspath(__file__))
PATH = os.path.join(ROOT, ".os_데이터", "메모판.json")
TRASH_DAYS = 30          # 지운 메모는 30일 동안 되살릴 수 있다


def _now():
    return time.strftime("%Y-%m-%d %H:%M")


def _load():
    try:
        with open(PATH, encoding="utf-8") as f:
            st = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        st = {}
    st.setdefault("memos", [])
    st.setdefault("trash", [])
    return st


@contextmanager
def _locked():
    os.makedirs(os.path.dirname(PATH), exist_ok=True)
    with open(PATH + ".lock", "w") as lk:
        fcntl.flock(lk, fcntl.LOCK_EX)
        st = _load()
        yield st
        # 오래된 휴지통 비우기
        cut = time.time() - TRASH_DAYS * 86400
        st["trash"] = [m for m in st["trash"] if m.get("deleted_ts", 0) > cut]
        tmp = PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(st, f, ensure_ascii=False, indent=1)
        os.replace(tmp, PATH)


def view():
    st = _load()
    return {"memos": st["memos"], "trash": st["trash"]}


def apply_op(op):
    """앱에서 오는 요청 하나를 처리하고 바뀐 상태를 돌려준다."""
    kind = op.get("op")
    with _locked() as st:
        memos = st["memos"]
        find = lambda i: next((m for m in memos if m["id"] == i), None)
        if kind == "add":
            m = {"id": uuid.uuid4().hex[:8], "title": (op.get("title") or "새 메모").strip()[:80],
                 "body": op.get("body") or "", "src": op.get("src") or "",
                 "created": _now(), "updated": _now()}
            memos.insert(0, m)
        elif kind == "update":
            m = find(op.get("id"))
            if m:
                if "title" in op:
                    m["title"] = (op["title"] or "").strip()[:80] or "제목 없음"
                if "body" in op:
                    m["body"] = op["body"] or ""
                m["updated"] = _now()
        elif kind == "top":
            m = find(op.get("id"))
            if m:
                memos.remove(m)
                memos.insert(0, m)
        elif kind == "delete":
            m = find(op.get("id"))
            if m:
                memos.remove(m)
                m["deleted"] = _now()
                m["deleted_ts"] = time.time()
                st["trash"].insert(0, m)
        elif kind == "restore":
            m = next((t for t in st["trash"] if t["id"] == op.get("id")), None)
            if m:
                st["trash"].remove(m)
                m.pop("deleted", None)
                m.pop("deleted_ts", None)
                memos.insert(0, m)
        out = {"memos": memos, "trash": st["trash"]}
    return out


def _cli(argv):
    if not argv or argv[0] == "list":
        for m in _load()["memos"]:
            print(f"- [{m['id']}] {m['title']}  ({m['updated']})")
        return
    cmd = argv[0]
    if cmd == "add":
        title = argv[1]
        if len(argv) > 3 and argv[2] == "--file":
            with open(argv[3], encoding="utf-8") as f:
                body = f.read()
        else:
            body = argv[2] if len(argv) > 2 else ""
        st = apply_op({"op": "add", "title": title, "body": body, "src": "{{실장}}"})
        print("OK", st["memos"][0]["id"], title)
    elif cmd == "show":
        key = argv[1]
        for m in _load()["memos"]:
            if key in m["title"]:
                print("#", m["title"]); print(m["body"]); return
        print("없음")
    else:
        print(__doc__)


if __name__ == "__main__":
    _cli(sys.argv[1:])
