#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
{{실장}} 비서 데스크 — 브라우저 ↔ 터미널 Claude Code 연결

실행:  python3 elvin_server.py        (본사 폴더 안에서)
정지:  터미널에서 Ctrl+C

- 파이썬에 원래 들어 있는 것만 쓴다. 설치할 것 없음.
- 컴퓨터에서는 http://127.0.0.1:8765
- 같은 와이파이의 휴대폰에서는 서버를 켤 때 터미널에 크게 찍히는 주소로 들어간다.
- 처음 들어오면 비밀번호를 한 번 묻는다. 맞히면 그 기기에서는 다시 묻지 않는다.
- 대화는 .os_데이터/threads 에 저장되고 Claude Code 세션 ID 를 들고 있어
  서버를 껐다 켜도 이어진다. 휴대폰과 컴퓨터가 같은 대화를 함께 본다.
"""

import base64
import binascii
import datetime
import hashlib
import json
import os
import re
import shutil
import socket
import struct
import subprocess
import sys
import threading
import time
import urllib.parse
import unicodedata
import uuid
import zlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

# ──────────────────────────────────────────── 설정 (여기만 고치면 된다)
# 기본은 이 컴퓨터 전용. 휴대폰에서도 쓰려면 아래처럼 켠다:
#     python3 elvin_server.py --phone
PHONE_MODE = ("--phone" in sys.argv) or (os.environ.get("ELVIN_PHONE") == "1")
HOST = "0.0.0.0" if PHONE_MODE else "127.0.0.1"
PORT = 8765
PASSWORD = "{{비밀번호}}"     # 처음 들어올 때 한 번 묻는 비밀번호 (기기마다 한 번만)

# 브라우저 {{실장}}에게 어디까지 맡길지.
#   기본값: 파일 읽기·쓰기·수정, 검색, 웹 조회까지 확인 없이 바로 한다.
#   ALLOW_BASH = True 로 바꾸면 터미널 명령(Bash)까지 실행한다.
#     → 이 화면에 글을 넣을 수 있는 사람이 맥에서 명령을 돌릴 수 있게 되므로,
#       켤 때는 --phone 없이(이 컴퓨터 전용으로) 쓰는 것을 권한다.
ALLOW_BASH = True    # {{호칭}} 지시: 브라우저 {{실장}}도 터미널 명령까지 실행
ALLOWED_TOOLS = "Read Write Edit Grep Glob WebSearch WebFetch TodoWrite"

# 비밀번호를 틀렸을 때
MAX_TRIES = 5             # 이만큼 틀리면
BLOCK_MINUTES = 10        # 이만큼 못 들어온다
CLAUDE_EXTRA = ["--dangerously-skip-permissions"]   # {{호칭}} 지시: 모두 허용
APP_NAME = "{{실장}}"          # 홈 화면에 추가했을 때 보이는 이름
ICON_CANDIDATES = ["os_아이콘.png", "os_아이콘.jpg", "elvin_icon.png"]

ROOT = os.path.dirname(os.path.abspath(__file__))          # 본사 폴더 (CLAUDE.md 가 있는 곳)
WEB = os.path.join(ROOT, "elvin_web.html")                  # 화면 파일
DATA = os.path.join(ROOT, ".os_데이터")
THREADS = os.path.join(DATA, "threads")
UPLOADS = os.path.join(DATA, "uploads")
DEPTS = os.path.join(ROOT, "부서")

os.makedirs(THREADS, exist_ok=True)
sys.path.insert(0, ROOT)
import importlib as _imp_lib   # do_POST 안의 지역 import importlib 와 겹치지 않게
import elvin_todo   # 할일 칸 (2026-09-30)
import elvin_memo   # 메모판 (2026-10-02)
os.makedirs(UPLOADS, exist_ok=True)

# ──────────────────────────────────────────── 부서 배정
# 왼쪽이 부서 폴더, 오른쪽이 그 부서로 보내는 말들.
# 부서 배정 — 설계가 끝나면 부서/부서표.json 에서 읽는다 (퍼스널 OS 설치 키트)
DEPT_RULES, CASE_FILES, DEPT_LABEL = [("00_비서실", [])], {}, {"00_비서실": "00 비서실"}
def _load_depts():
    global DEPT_RULES, CASE_FILES, DEPT_LABEL
    p = os.path.join(DEPTS, "부서표.json")
    try:
        with open(p, encoding="utf-8") as f:
            d = json.load(f)
    except Exception:
        return
    rules = [(x["폴더"], [w.lower() for w in x.get("말", [])]) for x in d.get("부서", [])]
    rules = [r for r in rules if r[0] != "00_비서실"] + [("00_비서실", next((r[1] for r in rules if r[0] == "00_비서실"), []))]
    DEPT_RULES = rules
    CASE_FILES = {x["폴더"]: [(c["말"], c["파일"]) for c in x["건별"]] for x in d.get("부서", []) if x.get("건별")}
    DEPT_LABEL = {x["폴더"]: x.get("이름") or x["폴더"].replace("_", " ", 1) for x in d.get("부서", [])}
    DEPT_LABEL.setdefault("00_비서실", "00 비서실")
_load_depts()


# ──────────────────────────────────────────── 본사 사무실 (2026-10-13 {{호칭}}, 레트로 화면 '부서가 일하는 모습')
# 지금 일하는 건과 오늘 끝난 건. 화면이 /api/office 로 읽어 부서 캐릭터를 움직인다.
OFFICE = {}
OFFICE_DONE = []
OFFICE_LOCK = threading.Lock()
WORKLOG = os.path.join(DEPTS, "00_비서실", "업무일지.md")


def _dept_code(label):
    m = re.match(r"\s*(\d\d|MY)\b", label or "")
    return m.group(1) if m else ""


def office_set(jid, **kw):
    with OFFICE_LOCK:
        if jid in OFFICE:
            OFFICE[jid].update(kw, upd=time.time())


def office_head(jid, txt):
    """답 첫 줄 `📋 01 디자인실 — 맥락` 을 읽어 실제 부서·맥락으로 고친다."""
    m = re.search(r"📋\s*((?:\d\d|MY)\s*[^—\-\n]*?)\s*[—-]\s*([^\n]+)", (txt or "")[:300])
    if m:
        office_set(jid, dept=m.group(1).strip(), ctx=m.group(2).strip()[:60])
    else:
        office_set(jid)


def office_end(jid, answer):
    with OFFICE_LOCK:
        j = OFFICE.pop(jid, None)
        if j:
            OFFICE_DONE.insert(0, {"dept": j["dept"], "text": j.get("ctx") or j["ask"], "ts": time.time()})
            del OFFICE_DONE[40:]


def office_today_log():
    today = datetime.date.today().isoformat()
    out = []
    try:
        with open(WORKLOG, encoding="utf-8") as f:
            for line in f:
                line = line.strip().lstrip("- ").strip()
                if not line.startswith(today):
                    continue
                parts = [x.strip() for x in line.split(" · ", 2)]
                if len(parts) == 3 and _dept_code(parts[1]):
                    out.append({"dept": parts[1], "text": parts[2][:120]})
    except Exception:
        pass
    return out


def office_status():
    now = time.time()
    with OFFICE_LOCK:
        work = [dict(v, secs=int(now - v["began"])) for v in OFFICE.values() if now - v.get("upd", v["began"]) < 1800]
        done = list(OFFICE_DONE)
    for w in work + done:
        w["code"] = _dept_code(w.get("dept"))
    log = office_today_log()
    for l in log:
        l["code"] = _dept_code(l["dept"])
    rout = []
    try:
        import elvin_routines
        _imp_lib.reload(elvin_routines)
        rout = [{"name": x.get("name"), "icon": x.get("icon"), "state": x.get("state"), "time": x.get("time"),
                 "summary": (x.get("summary") or "")[:80]} for x in elvin_routines.status().get("items", [])]
    except Exception:
        pass
    return {"now": now, "working": work, "done": done, "log": log, "routines": rout}


def pick_department(text):
    """{{호칭}} 말씀을 보고 부서 하나를 고른다. 못 고르면 00 비서실."""
    _load_depts()
    low = text.lower()
    best, score = "00_비서실", 0
    for folder, words in DEPT_RULES:
        hit = sum(1 for w in words if w.lower() in low)
        if hit > score:
            best, score = folder, hit
    return best


def pick_guide_file(folder, text):
    """그 부서에서 읽을 지침 파일 하나를 고른다. 전부 읽지 않는다."""
    low = text.lower()
    base = os.path.join(DEPTS, folder)
    if folder in CASE_FILES:
        for words, fname in CASE_FILES[folder]:
            if any(w.lower() in low for w in words):
                p = os.path.join(base, fname)
                if os.path.exists(p):
                    return p
        return None
    p = os.path.join(base, "CLAUDE.md")
    return p if os.path.exists(p) else None


def read_guide(path, limit=40000):
    try:
        with open(path, encoding="utf-8") as f:
            return f.read()[:limit]
    except Exception:
        return ""


# ──────────────────────────────────────────── 대화 저장
_lock = threading.Lock()


def thread_path(tid):
    safe = re.sub(r"[^0-9a-zA-Z\-]", "", tid or "")
    return os.path.join(THREADS, safe + ".json")


def load_thread(tid):
    p = thread_path(tid)
    if not tid or not os.path.exists(p):
        return None
    try:
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def save_thread(t):
    t["updated"] = time.time()
    with _lock:
        with open(thread_path(t["id"]), "w", encoding="utf-8") as f:
            json.dump(t, f, ensure_ascii=False, indent=1)


def _rw(tid, change):
    """디스크에 있는 최신 대화를 다시 읽어 고치고 바로 쓴다.
    요청이 동시에 두 개 돌 때 오래된 사본으로 덮어써서 말이 사라지는 것을 막는다."""
    with _lock:
        p = thread_path(tid)
        try:
            with open(p, encoding="utf-8") as f:
                t = json.load(f)
        except Exception:
            return None
        out = change(t)
        t["updated"] = time.time()
        tmp = p + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(t, f, ensure_ascii=False, indent=1)
        os.replace(tmp, p)
        return out


def append_msg(tid, msg, title_hint=None):
    """말 한 마디를 붙이고 그 자리 번호를 돌려준다."""
    def change(t):
        t.setdefault("messages", []).append(msg)
        if title_hint and t.get("title") == "새 대화":
            t["title"] = title_hint[:22]
        return len(t["messages"]) - 1
    r = _rw(tid, change)
    return -1 if r is None else r


def patch_msg(tid, idx, **fields):
    """이미 붙여 둔 말을 고쳐 쓴다(답이 흘러나오는 동안 계속 덮어쓴다)."""
    if idx is None or idx < 0:
        return
    def change(t):
        ms = t.get("messages") or []
        if 0 <= idx < len(ms):
            ms[idx].update(fields)
    _rw(tid, change)


def patch_session(tid, session_id=None, started=None):
    def change(t):
        if session_id:
            t["session_id"] = session_id
        if started is not None:
            t["started"] = started
    _rw(tid, change)


def new_thread():
    t = {
        "id": str(uuid.uuid4()),
        "session_id": str(uuid.uuid4()),   # Claude Code 세션 ID (기억이 여기 붙는다)
        "started": False,
        "title": "새 대화",
        "created": time.time(),
        "updated": time.time(),
        "messages": [],
    }
    save_thread(t)
    return t


TRASH = os.path.join(DATA, "threads_휴지통")


def trash_thread(tid):
    """대화를 지운다. 실제로는 휴지통 폴더로 옮겨서 되살릴 수 있게 둔다."""
    p = thread_path(tid)
    if not tid or not os.path.exists(p):
        return False
    os.makedirs(TRASH, exist_ok=True)
    with _lock:
        os.replace(p, os.path.join(TRASH, time.strftime("%y%m%d_%H%M%S_") + os.path.basename(p)))
    return True



# ── 사이드바: 최근 만든 파일 · 미니달력 (2026-10-01) ──
RECENT_EXT = {".pdf", ".png", ".jpg", ".jpeg", ".pptx", ".xlsx", ".docx", ".hwp", ".hwpx", ".zip", ".txt", ".mp4", ".mov", ".mp3", ".m4a"}
RECENT_SKIP = ("백업", "이전판", "_old", "임시", "~$", "원본", "인감")
_recent_cache = {"t": 0, "items": []}


def recent_files(limit=12):
    if time.time() - _recent_cache["t"] < 60:
        return _recent_cache["items"][:limit]
    base = os.path.join(ROOT, "부서")
    found = []
    for dp, dns, fns in os.walk(base):
        dns[:] = [d for d in dns if not d.startswith((".", "_")) and not any(k in unicodedata.normalize("NFC", d) for k in RECENT_SKIP)]
        for fn in fns:
            name = unicodedata.normalize("NFC", fn)
            ext = os.path.splitext(name)[1].lower()
            if ext not in RECENT_EXT or name.startswith((".", "_")) or any(k in name for k in RECENT_SKIP):
                continue
            fp = os.path.join(dp, fn)
            try:
                found.append((os.path.getmtime(fp), fp, name))
            except OSError:
                pass
    found.sort(reverse=True)
    items = []
    for mt, fp, name in found[:40]:
        rel = os.path.relpath(fp, ROOT)
        dept = unicodedata.normalize("NFC", rel.split(os.sep)[1]) if rel.count(os.sep) >= 2 else ""
        items.append({"name": name, "path": unicodedata.normalize("NFC", rel), "dept": dept, "mtime": mt})
    _recent_cache.update(t=time.time(), items=items)
    return items[:limit]


def list_dir(rel):
    """자료실 폴더 보기(2026-10-13 레트로 화면). 부서 폴더 안만 보여 준다."""
    base = os.path.realpath(os.path.join(ROOT, "부서"))
    rel = (rel or "부서").strip("/")
    for form in ("NFC", "NFD"):
        fp = os.path.realpath(os.path.join(ROOT, unicodedata.normalize(form, rel)))
        if (fp == base or fp.startswith(base + os.sep)) and os.path.isdir(fp):
            break
    else:
        return None
    dirs, files = [], []
    for n in sorted(os.listdir(fp)):
        name = unicodedata.normalize("NFC", n)
        if name.startswith((".", "~$")) or name in ("CLAUDE.md",):
            continue
        full = os.path.join(fp, n)
        r = unicodedata.normalize("NFC", os.path.relpath(full, ROOT))
        try:
            st = os.stat(full)
        except OSError:
            continue
        if os.path.isdir(full):
            dirs.append({"name": name, "path": r, "dir": True, "mtime": st.st_mtime})
        else:
            files.append({"name": name, "path": r, "dir": False, "mtime": st.st_mtime, "size": st.st_size})
    files.sort(key=lambda x: -x["mtime"])
    return {"path": unicodedata.normalize("NFC", os.path.relpath(fp, ROOT)), "dirs": dirs, "files": files}


def safe_file(rel):
    """부서 폴더 안의 파일만 열어 준다."""
    base = os.path.realpath(os.path.join(ROOT, "부서"))
    for form in ("NFC", "NFD"):
        fp = os.path.realpath(os.path.join(ROOT, unicodedata.normalize(form, rel)))
        if fp.startswith(base + os.sep) and os.path.isfile(fp):
            return fp
    return None



PREVIEW = os.path.join(DATA, "미리보기")
PDF2IMG = os.path.join(ROOT, "부서", "00_비서실", "pdf쪽그림")


def preview_info(rel):
    """앱 안 파일 보기용. PDF 는 쪽마다 그림으로 바꿔 둔다(아이폰 앱에서도 넘겨 보이게)."""
    fp = safe_file(rel)
    if not fp:
        return None
    ext = os.path.splitext(fp)[1].lower()
    raw = "/api/file?p=" + urllib.parse.quote(rel)
    if ext in (".png", ".jpg", ".jpeg", ".gif", ".webp"):
        return {"kind": "img", "src": raw, "raw": raw}
    if ext in (".mp4", ".mov", ".m4v", ".mp3", ".m4a", ".wav"):   # 2026-10-05 앱 안에서 바로 재생
        return {"kind": "video" if ext in (".mp4", ".mov", ".m4v") else "audio", "src": raw, "raw": raw}
    if ext != ".pdf":
        return {"kind": "other", "raw": raw}
    key = hashlib.sha1(("%s|%s|w2200" % (fp, os.path.getmtime(fp))).encode("utf-8")).hexdigest()[:16]
    d = os.path.join(PREVIEW, key)
    if not os.path.isdir(d) or not os.listdir(d):
        os.makedirs(d, exist_ok=True)
        try:
            subprocess.run([PDF2IMG, fp, d, "2200"], timeout=120, capture_output=True)   # 확대해도 선명하게
        except Exception:
            pass
    n = len([f for f in os.listdir(d) if f.endswith(".jpg")])
    if not n:
        return {"kind": "other", "raw": raw}
    return {"kind": "pdf", "raw": raw, "pages": ["/api/previewimg?k=%s&n=%d" % (key, i) for i in range(1, n + 1)]}

CAL_CACHE = os.path.join(DATA, "캘린더_캐시.json")


def calendar_cache():
    try:
        with open(CAL_CACHE, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"updated": "", "events": []}

def list_threads():
    out = []
    for name in os.listdir(THREADS):
        if not name.endswith(".json"):
            continue
        try:
            with open(os.path.join(THREADS, name), encoding="utf-8") as f:
                t = json.load(f)
            if not t.get("messages"):
                continue                      # 한 번도 말 안 한 빈 대화는 목록에 안 보인다
            out.append({"id": t["id"], "title": t.get("title", "새 대화"),
                        "updated": t.get("updated", 0),
                        "count": len(t.get("messages", []))})
        except Exception:
            continue
    out.sort(key=lambda x: x["updated"], reverse=True)
    return out


# ──────────────────────────────────────────── 비밀번호
def make_token():
    seed = (PASSWORD + "{{실장}}" + str(os.path.getctime(ROOT))).encode("utf-8")
    return hashlib.sha256(seed).hexdigest()[:32]


TOKEN = make_token()

# 대화마다 한 번에 하나씩만 돌린다. 뒤에 들어온 일은 앞 일이 끝나면 이어서 처리한다.
_queues = {}
_queues_guard = threading.Lock()


class FifoGate:
    """들어온 순서대로 한 명씩 들여보내는 문 (2026-10-13 대기열). Lock 과 같은 모양으로 쓴다."""
    def __init__(self):
        self.c = threading.Condition()
        self.busy = False
        self.q = []

    def acquire(self, blocking=True, timeout=None):
        with self.c:
            if not self.busy and not self.q:
                self.busy = True
                return True
            if not blocking:
                return False
            me = object()
            self.q.append(me)
            end = None if timeout is None or timeout < 0 else time.time() + timeout
            while self.busy or self.q[0] is not me:
                left = None if end is None else end - time.time()
                if left is not None and left <= 0:
                    self.q.remove(me)
                    self.c.notify_all()
                    return False
                self.c.wait(left)
            self.q.pop(0)
            self.busy = True
            return True

    def release(self):
        with self.c:
            if not self.busy:
                raise RuntimeError("not held")
            self.busy = False
            self.c.notify_all()

    def waiting(self):
        with self.c:
            return len(self.q)


def thread_queue(tid):
    with _queues_guard:
        return _queues.setdefault(tid, FifoGate())


# ── 동시 출동 (2026-10-13 {{호칭}}) ──
# 본 작업이 도는 중에 새 말씀이 오면: 다른 부서의 별개 일 → 곁에서 동시에 처리(최대 2개 더),
# 같은 부서·이어지는 말·자리 없음 → 대기열에 넣었다가 앞 일이 끝나면 이어서 처리.
PAR_MAX = 2
_par = {"n": 0}
_par_guard = threading.Lock()
MAIN_DEPT = {}           # 대화 id → 지금 본 작업 부서
PAR_DEPTS = {}           # 대화 id → 동시 출동 중인 부서들
SIDE_NOTES = {}          # 대화 id → 본 작업이 아직 모르는 동시 출동 결과
FOLLOW_WORDS = ("그리고", "아 ", "아,", "아니", "근데", "그거", "이것도", "이거", "추가로", "또 ", "그럼", "그래서",
                "저거", "방금", "아까", "거기", "여기에", "위에", "그 ", "이어서", "계속")


def is_follow(tid, text, dept):
    t = (text or "").strip()
    return len(t) < 12 or t.startswith(FOLLOW_WORDS) or dept == MAIN_DEPT.get(tid)


def pick_mode(tid, text, dept):
    t = (text or "").strip()
    if len(t) < 12 or t.startswith(FOLLOW_WORDS):
        return "queue"
    busy = {MAIN_DEPT.get(tid)} | set(PAR_DEPTS.get(tid, []))
    if dept in busy:
        return "queue"
    with _par_guard:
        if _par["n"] >= PAR_MAX:
            return "queue"
        _par["n"] += 1
    return "parallel"


def take_notes(tid):
    notes = SIDE_NOTES.pop(tid, [])
    if not notes:
        return ""
    return ("[참고] {{호칭}}이 이 대화에서 본 작업과 동시에 다른 부서에 맡겨 이미 처리한 일:\n"
            + "\n".join(notes) + "\n\n")


def parallel_prompt(thread, text, dept, guide, files):
    recent = []
    for m in thread.get("messages", [])[-8:]:
        who = "{{호칭}}" if m.get("role") == "user" else "{{실장}}"
        recent.append("%s: %s" % (who, (m.get("text") or "")[:400]))
    head = [
        "지금 이 대화에서 **다른 부서의 본 작업이 동시에 돌고 있다**. 너는 그와 별개로 아래 {{호칭}} 말씀을 끝까지 처리한다(동시 출동).",
        "- 짧게 줄이지 말고 평소처럼 일을 끝까지 한다.",
        "- 앞 작업이 고치는 중일 수 있는 파일(같은 화면 파일·같은 문서)은 건드리지 않는다. 꼭 그 파일을 고쳐야 하는 일이면 "
        "고치지 말고 '앞 일이 끝난 뒤 이어서 하겠습니다'라고 답한다.",
        "- 서버 다시 띄우기는 하지 않는다(앞 작업이 끊길 수 있다).",
        "",
        "지금까지 오간 말:",
        "\n".join(recent) if recent else "(없음)",
        "",
    ]
    return "\n".join(head) + build_prompt(text, dept, guide, files)


# 2026-09-28 멈춤 감시 — 본 작업이 아무 일도 안 하고 30분씩 붙잡고 있던 문제를 막는다.
IDLE_LIMIT = 11 * 60     # 이만큼 아무 출력이 없으면 멈춘 것으로 보고 끊는다 (명령 하나 최대 10분)
STALE_MAIN = 3 * 60      # 새 말씀이 왔을 때 본 작업이 이만큼 조용하면 끊고 새 말씀을 본 작업으로 받는다
STOP_WORDS = ("멈춰", "멈추고", "중단", "그만", "취소", "새로 만들어", "다시 해")
_running = {}            # 대화 id → {"proc", "last", "began"}  (본 작업만)
_running_guard = threading.Lock()


def kill_proc(proc):
    """클로드와 그 밑에 딸린 명령까지 한꺼번에 끝낸다."""
    try:
        os.killpg(proc.pid, 15)
    except Exception:
        pass
    try:
        proc.wait(timeout=5)
    except Exception:
        try:
            os.killpg(proc.pid, 9)
        except Exception:
            pass


def stop_main(tid):
    with _running_guard:
        r = _running.get(tid)
    if r:
        r["killed"] = True
        kill_proc(r["proc"])
        return True
    return False


def main_idle(tid):
    with _running_guard:
        r = _running.get(tid)
    return (time.time() - r["last"]) if r else None


# 틀린 횟수와 차단 시각을 기기(주소)별로 기억한다
_tries = {}
_tries_lock = threading.Lock()


def password_problem():
    """{{호칭}}이 정하신 비밀번호가 규칙에 맞는지 본다. 맞으면 None."""
    if PASSWORD.isdigit():
        return "숫자만으로는 안 됩니다"
    if len(PASSWORD) < 8:
        return "여덟 글자보다 짧습니다"
    return None


def blocked_for(ip):
    """남은 차단 시간(초). 0이면 들어올 수 있다."""
    with _tries_lock:
        rec = _tries.get(ip)
        if not rec:
            return 0
        left = rec.get("until", 0) - time.time()
        return int(left) if left > 0 else 0


def note_fail(ip):
    with _tries_lock:
        rec = _tries.setdefault(ip, {"count": 0, "until": 0})
        rec["count"] += 1
        if rec["count"] >= MAX_TRIES:
            rec["until"] = time.time() + BLOCK_MINUTES * 60
            rec["count"] = 0
            return True
        return False


def note_success(ip):
    with _tries_lock:
        _tries.pop(ip, None)


def is_logged_in(handler):
    cookie = handler.headers.get("Cookie") or ""
    return ("elvin_key=" + TOKEN) in cookie


# ──────────────────────────────────────────── 앱 아이콘
def find_icon_file():
    for name in ICON_CANDIDATES:
        p = os.path.join(ROOT, name)
        if os.path.exists(p):
            return p
    return None


def _png(width, pixels):
    """RGB 픽셀 목록을 PNG 바이트로 만든다 (외부 라이브러리 없이)."""
    raw = b""
    for y in range(width):
        raw += b"\x00" + bytes(pixels[y * width * 3:(y + 1) * width * 3])

    def chunk(tag, data):
        return (struct.pack(">I", len(data)) + tag + data
                + struct.pack(">I", binascii.crc32(tag + data) & 0xFFFFFFFF))

    return (b"\x89PNG\r\n\x1a\n"
            + chunk(b"IHDR", struct.pack(">IIBBBBB", width, width, 8, 2, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(raw, 9))
            + chunk(b"IEND", b""))


def default_icon(size=512):
    """기본 아이콘: 남색 바탕 + 파란 원 + 흰 위쪽 화살표."""
    bg, ring, arrow = (26, 26, 32), (59, 116, 242), (255, 255, 255)
    cx = cy = size / 2
    r = size * 0.36
    px = bytearray()
    for y in range(size):
        for x in range(size):
            d = ((x - cx) ** 2 + (y - cy) ** 2) ** 0.5
            c = bg
            if d < r:
                c = ring
                ny = (y - cy) / r
                nx = abs(x - cx) / r
                if -0.55 <= ny <= 0.55 and nx <= 0.42 - 0.0 and ny > -0.1 and nx < 0.16:
                    c = arrow                      # 화살대
                if ny <= -0.1 and nx <= (ny + 0.62) * 0.95 and ny >= -0.62:
                    c = arrow                      # 화살촉
            px += bytes(c)
    return _png(size, px)


_icon_cache = {}


def icon_bytes():
    p = find_icon_file()
    if p:
        key = (p, os.path.getmtime(p))
        if key not in _icon_cache:
            with open(p, "rb") as f:
                _icon_cache.clear()
                _icon_cache[key] = (f.read(),
                                    "image/jpeg" if p.lower().endswith((".jpg", ".jpeg")) else "image/png")
        return _icon_cache[key]
    if "default" not in _icon_cache:
        _icon_cache["default"] = (default_icon(), "image/png")
    return _icon_cache["default"]


# ──────────────────────────────────────────── Claude Code 실행
def build_prompt(text, dept_folder, guide_path, files, brief=False):
    label = DEPT_LABEL.get(dept_folder, dept_folder)
    parts = []
    parts.append("아래 지시는 브라우저 비서 화면에서 들어온 {{호칭}} 말씀이다.")
    parts.append("이 건은 **%s** 가 맡는다. 답의 첫 줄에 `📋 %s — <맥락 한 줄>` 을 적고 시작한다."
                 % (label, label))
    if guide_path and brief:
        # 같은 대화에서 이미 넣은 지침이면 본문을 다시 싣지 않는다 (토큰 절약, 2026-10-28 {{호칭}})
        rel = os.path.relpath(guide_path, ROOT)
        parts.append("이 대화에서 앞서 받은 `%s` 지침을 그대로 따른다. 같은 지침이라 본문은 다시 넣지 않았다. "
                     "다른 부서 지침 파일은 읽지 않는다. 내용이 확실하지 않으면 Read 도구로 그 파일만 다시 연다." % rel)
    elif guide_path:
        rel = os.path.relpath(guide_path, ROOT)
        parts.append("아래는 `%s` 의 내용이다. 이 파일만 참고한다. 다른 부서 지침 파일은 읽지 않는다." % rel)
        parts.append("=== %s 시작 ===\n%s\n=== %s 끝 ===" % (rel, read_guide(guide_path), rel))
    else:
        folder = os.path.join(DEPTS, dept_folder)
        try:
            names = [n for n in os.listdir(folder) if n.endswith(".md")]
        except Exception:
            names = []
        parts.append("이 부서는 건별 파일을 쓰는데 어느 건인지 확실하지 않다. "
                     "폴더에 있는 파일: %s. 어떤 건인지 {{호칭}}께 한 줄로 여쭤보고 기다린다."
                     % (", ".join(names) or "없음"))
    if files:
        lines = ["{{호칭}}이 첨부하신 파일이다. **Read 도구로 반드시 열어 보고** 답한다. "
                 "이름의 01_·02_ 는 {{호칭}}이 고른 순서다 — {{호칭}}이 '1번·2번'이라 하시면 이 순번이다:"]
        for f in files:
            lines.append("- %s" % f)
        parts.append("\n".join(lines))
    parts.append("{{호칭}} 말씀:\n" + (text or "(첨부만 보내셨다)"))
    return "\n\n".join(parts)


# ── 지침 중복 막기 · 긴 대화 이어가기 (2026-10-28 {{호칭}} 지시)
LONG_WEEK = 20        # 이 대화를 쓰는 동안 주간 사용량이 이만큼(%p) 오르면 '새 대화로 이어가기'를 권한다
                      # (2026-11-01 {{호칭}}: 토큰 30만·말씀 60개 기준은 너무 빨리 떠서 주간 20% 기준으로 바꿈)


def week_now():
    try:
        v = (usage_fetch().get("주간") or {}).get("쓴비율")
        return float(v) if v is not None else None
    except Exception:
        return None


def guide_key(guide_path):
    try:
        return "%s@%d" % (os.path.relpath(guide_path, ROOT), int(os.path.getmtime(guide_path)))
    except Exception:
        return ""


def guide_seen(thread, guide_path):
    """이 대화(같은 세션)에 같은 지침을 이미 넣었는가. 지침 파일을 고쳤으면 다시 넣는다."""
    k = guide_key(guide_path) if guide_path else ""
    g = thread.get("guide_sent") or {}
    return bool(k) and bool(thread.get("started")) and g.get("session") == thread.get("session_id") \
        and k in (g.get("keys") or [])


def mark_guide(tid, guide_path):
    k = guide_key(guide_path) if guide_path else ""
    if not k:
        return
    def change(t):
        g = t.get("guide_sent") or {}
        if g.get("session") != t.get("session_id"):
            g = {"session": t.get("session_id"), "keys": []}
        if k not in g["keys"]:
            g["keys"].append(k)
        t["guide_sent"] = g
    _rw(tid, change)


def is_long(t):
    base, now = t.get("week_base"), week_now()
    return base is not None and now is not None and now - base >= LONG_WEEK


def handover_note(t):
    """새 대화로 넘길 인계노트 — 앞 대화의 제목과 최근 주고받은 말."""
    ms = [m for m in t.get("messages", []) if m.get("role") in ("user", "elvin") and (m.get("text") or "").strip()]
    lines = ["[인계노트] {{호칭}}이 길어진 대화 「%s」를 새 대화로 옮겨 이어서 하신다. "
             "아래는 앞 대화의 마지막 부분이다. 이어지는 일이면 이 맥락을 그대로 쓴다." % t.get("title", "")]
    for m in ms[-12:]:
        who = "{{호칭}}" if m["role"] == "user" else "{{실장}}"
        txt = re.sub(r"\s+", " ", m["text"]).strip()
        lines.append("- %s: %s" % (who, txt[:900 if who == "{{실장}}" else 500]))
    log = os.path.join(DEPTS, "00_비서실", "업무일지.md")
    if os.path.exists(log):
        lines.append("더 앞의 맥락이 필요하면 `%s` 의 '진행 중인 일'을 읽는다." % os.path.relpath(log, ROOT))
    return "\n".join(lines)


def continue_thread(old_id):
    old = load_thread(old_id)
    if not old:
        return None
    t = new_thread()
    def change(x):
        x["title"] = ("↪ " + old.get("title", ""))[:22]
        x["carry"] = handover_note(old)
        x["from"] = old_id
    _rw(t["id"], change)
    _rw(old_id, lambda x: x.__setitem__("moved_to", t["id"]))
    return load_thread(t["id"])


def claude_bin():
    """claude 명령의 실제 위치. 자동 시작으로 켜지면 PATH 가 좁아져 못 찾으므로 직접 찾는다."""
    found = shutil.which("claude")
    if found:
        return found
    for p in (os.path.expanduser("~/.local/bin/claude"),
              "/usr/local/bin/claude", "/opt/homebrew/bin/claude",
              os.path.expanduser("~/.npm-global/bin/claude")):
        if os.path.exists(p):
            return p
    return "claude"


def side_thread(thread):
    """앞 작업이 도는 중에 쓰는 임시 대화. 본 대화 세션은 건드리지 않는다."""
    return {"id": thread["id"], "session_id": str(uuid.uuid4()), "started": False}


def side_prompt(thread, text, dept, guide, files):
    """지금까지 오간 말을 붙여 주고, 짧게 답하라고 이른다."""
    recent = []
    for m in thread.get("messages", [])[-8:]:
        who = "{{호칭}}" if m.get("role") == "user" else "{{실장}}"
        recent.append("%s: %s" % (who, (m.get("text") or "")[:400]))
    head = [
        "지금 이 대화에서 **오래 걸리는 작업이 하나 돌고 있다**(강의 재생 등). "
        "그 작업은 그대로 두고, 아래 {{호칭}} 말씀에만 **짧게** 답한다.",
        "- 세 문장 안으로 답한다. 길게 쓰지 않는다.",
        "- 돌고 있는 작업을 중단하거나 같은 일을 또 시작하지 않는다. "
        "{{호칭}}이 중단을 원하시면 방법만 한 줄로 알려드린다.",
        "- 화면 끄기·상태 확인처럼 바로 되는 일은 해드린다.",
        "- '끝나면 보고드리겠습니다' 같은 약속은 하지 않는다. 곁답은 이 한 번으로 끝나고, "
        "본 작업이 끝나면 서버가 아이폰 알림으로 알린다. 본 작업이 3분 넘게 조용하면 "
        "{{호칭}}의 다음 말씀이 그 작업을 끊고 바로 본 작업으로 들어간다는 것만 알려드린다.",
        "",
        "지금까지 오간 말:",
        "\n".join(recent) if recent else "(없음)",
        "",
    ]
    return "\n".join(head) + build_prompt(text, dept, guide, files)


def run_claude(thread, prompt, emit, on_progress=None, main=False):
    """Claude Code 를 돌리며 나오는 글자를 그대로 emit 으로 흘려보낸다."""
    cmd = [claude_bin(), "-p", prompt,
           "--output-format", "stream-json",
           "--include-partial-messages",
           "--verbose"] + CLAUDE_EXTRA
    if thread.get("started"):
        cmd += ["--resume", thread["session_id"]]
    else:
        cmd += ["--session-id", thread["session_id"]]

    emit({"type": "status", "text": "{{실장}}이 생각하는 중"})
    env = dict(os.environ)
    env["PATH"] = ":".join([os.path.expanduser("~/.local/bin"), "/usr/local/bin",
                            "/opt/homebrew/bin", env.get("PATH", "/usr/bin:/bin")])
    # 오래 걸리는 명령을 뒤로 돌려 놓고 답을 끝낸 척하면, 클로드가 그 명령을 기다리며
    # 아무 일도 안 하고 30분씩 살아 있었다. 뒤로 돌리기를 막아 명령이 끝나야 다음으로 가게 한다.
    env["CLAUDE_CODE_DISABLE_BACKGROUND_TASKS"] = "1"
    try:
        # start_new_session=True : 클로드를 서버와 다른 세션으로 띄운다.
        # 서버를 다시 띄우거나 launchd 가 작업을 정리해도 답하던 클로드가 같이 죽지 않는다.
        proc = subprocess.Popen(cmd, cwd=ROOT, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, text=True, bufsize=1, env=env,
                                start_new_session=True)
    except FileNotFoundError:
        msg = "claude 명령을 찾지 못했습니다(%s). 터미널에서 claude 가 실행되는지 확인해 주세요." % cmd[0]
        emit({"type": "error", "text": msg})
        return "[막힌 곳] " + msg

    answer = []
    api_err = ""
    last_flush = 0.0
    ctx = 0             # 이번 답을 쓸 때 대화에 쌓여 있던 양(토큰)
    watch = {"proc": proc, "last": time.time(), "began": time.time(), "killed": False, "idle": False}
    if main:
        with _running_guard:
            _running[thread["id"]] = watch

    def watchdog():
        while proc.poll() is None:
            if time.time() - watch["last"] > IDLE_LIMIT:
                watch["idle"] = True
                say("멈춘 작업 끊음 (%d분 무응답)" % (IDLE_LIMIT // 60), "⛔")
                kill_proc(proc)
                return
            time.sleep(10)
    threading.Thread(target=watchdog, daemon=True).start()

    try:
        for line in proc.stdout:
            watch["last"] = time.time()
            line = line.strip()
            if not line or not line.startswith("{"):
                continue
            try:
                ev = json.loads(line)
            except json.JSONDecodeError:
                continue

            kind = ev.get("type")
            if kind == "system" and ev.get("subtype") == "init":
                sid = ev.get("session_id")
                if sid:
                    thread["session_id"] = sid
                thread["started"] = True
                if "title" in thread:          # 임시(곁) 대화는 저장하지 않는다
                    patch_session(thread["id"], sid, True)
            elif kind == "stream_event":
                e = ev.get("event", {})
                et = e.get("type")
                if et == "content_block_delta":
                    d = e.get("delta", {})
                    if d.get("type") == "text_delta":
                        chunk = d.get("text", "")
                        if chunk:
                            answer.append(chunk)
                            emit({"type": "delta", "text": chunk})
                            # 답이 나오는 대로 대화 파일에도 계속 적어 둔다.
                            # 서버가 꺼지거나 작업이 끊겨도 여기까지는 남는다.
                            now = time.time()
                            if on_progress and now - last_flush > 2:
                                last_flush = now
                                on_progress("".join(answer))
                elif et == "message_start":
                    u = (e.get("message") or {}).get("usage") or {}
                    ctx = (u.get("input_tokens") or 0) + (u.get("cache_read_input_tokens") or 0) \
                        + (u.get("cache_creation_input_tokens") or 0)
                elif et == "content_block_start":
                    blk = e.get("content_block", {})
                    if blk.get("type") == "tool_use":
                        emit({"type": "status", "text": "%s 쓰는 중" % blk.get("name", "도구")})
            elif kind == "system" and ev.get("subtype") == "compact_boundary":
                # 대화가 압축되면 앞서 넣은 지침도 요약돼 사라진다 → 다음 말씀에 다시 넣는다
                thread["_compacted"] = True
                if "title" in thread:
                    _rw(thread["id"], lambda x: x.pop("guide_sent", None))
            elif kind == "system" and ev.get("subtype") == "api_error":
                api_err = json.dumps(ev.get("error", ""), ensure_ascii=False)
            elif kind == "result":
                if ev.get("is_error"):
                    api_err = api_err or str(ev.get("result", ""))
                    emit({"type": "error", "text": str(ev.get("result", "오류"))[:400]})
                # 답이 끝났다. 뒤에 남은 명령이 있어도 기다리지 않고 정리한다.
                try:
                    proc.wait(timeout=5)
                except Exception:
                    kill_proc(proc)
                break
        proc.wait()
    finally:
        if main:
            with _running_guard:
                if _running.get(thread["id"]) is watch:
                    _running.pop(thread["id"], None)
        if watch["idle"] or watch["killed"]:
            why = ("%d분 동안 아무 진행이 없어 작업을 끊었습니다." % (IDLE_LIMIT // 60)
                   if watch["idle"] else "{{호칭}} 새 말씀을 받으려고 앞 작업을 끊었습니다.")
            emit({"type": "error", "text": why})
            answer.append("\n\n[작업 끊김] " + why)
        err = ""
        try:
            err = proc.stderr.read()[:400]
        except Exception:
            pass
        if not answer:
            if "overloaded" in api_err or "529" in api_err:
                msg = "Claude 서버가 지금 붐벼서 답을 못 받았습니다. 1~2분 뒤 같은 말을 다시 보내 주세요."
            else:
                msg = "답이 비어서 돌아왔습니다. %s" % (err or api_err[:300] or "(오류 메시지 없음)")
            emit({"type": "error", "text": msg})
            say(msg[:80], "⚠️")
            return "[막힌 곳] " + msg
    if ctx and "title" in thread:       # 임시(곁) 대화는 저장하지 않는다
        wk = week_now()
        def change(x):
            x["ctx_tokens"] = ctx
            # 주간 사용량 기준점 — 처음 답할 때 잡고, 주간 한도가 초기화돼 내려가면 다시 잡는다
            if wk is not None and (x.get("week_base") is None or wk < x["week_base"]):
                x["week_base"] = wk
        _rw(thread["id"], change)
    return "".join(answer)


# ──────────────────────────────────────────── 웹 서버
def lan_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except Exception:
        return "127.0.0.1"
    finally:
        s.close()


LAN_URL = "http://%s:%d" % (lan_ip(), PORT)


def tailscale_url():
    """테일스케일이 켜져 있으면 밖에서 쓸 주소. 없으면 빈 문자열."""
    # 1) 테일스케일 자신에게 물어본다
    for exe in ("/Applications/Tailscale.app/Contents/MacOS/Tailscale", "tailscale"):
        try:
            out = subprocess.run([exe, "ip", "-4"], capture_output=True, text=True, timeout=5)
            ip = (out.stdout or "").strip().split("\n")[0].strip()
            if ip.startswith("100."):
                return "http://%s:%d" % (ip, PORT)
        except Exception:
            continue
    # 2) 자동 시작으로 켜질 때는 위 방법이 막히므로, 랜카드 목록에서 직접 찾는다
    try:
        out = subprocess.run(["/sbin/ifconfig"], capture_output=True, text=True, timeout=5)
        for m in re.finditer(r"inet (100\.(?:6[4-9]|[7-9]\d|1[01]\d|12[0-7])\.\d+\.\d+)",
                             out.stdout or ""):
            return "http://%s:%d" % (m.group(1), PORT)
    except Exception:
        pass
    return ""


TS_URL = tailscale_url()

# ──────────────────────────────────────────── 터미널 화면
COLOR = sys.stdout.isatty()          # 창에서 돌 때만 색을 쓴다


def paint(text, code):
    return "\033[%sm%s\033[0m" % (code, text) if COLOR else text


def say(text, icon="·", tail=""):
    """서버 창에 한 줄 남긴다."""
    stamp = paint(time.strftime("%H:%M"), "2;37")
    line = "  %s  %s %s" % (stamp, icon, text)
    if tail:
        line += paint("  ·  %s" % tail, "2;37")
    sys.stdout.write(line + "\n")
    sys.stdout.flush()


def wide(text):
    """한글은 두 칸을 차지하므로 실제 보이는 너비를 센다."""
    return sum(2 if unicodedata.east_asian_width(c) in "WF" else 1 for c in text)


def fit(text, width):
    return text + " " * max(0, width - wide(text))


def banner():
    rows = [("집에서", LAN_URL if PHONE_MODE else "http://127.0.0.1:%d" % PORT)]
    if PHONE_MODE and TS_URL:
        rows.append(("밖에서", TS_URL))
    rows.append(("비밀번호", PASSWORD))
    bodies = ["  %s   %s" % (fit(label, 8), value) for label, value in rows]
    width = max([wide(b) for b in bodies] + [wide("  {{실장}} 비서 데스크")]) + 3
    edge = "38;5;110"
    print("")
    print(paint("  ╭" + "─" * width + "╮", edge))
    print(paint("  │", edge) + paint(fit("  {{실장}} 비서 데스크", width), "1") + paint("│", edge))
    print(paint("  │" + " " * width + "│", edge))
    for body in bodies:
        print(paint("  │", edge) + fit(body, width) + paint("│", edge))
    print(paint("  ╰" + "─" * width + "╯", edge))
    bits = ["권한 모두 허용" if "--dangerously-skip-permissions" in CLAUDE_EXTRA
            else ("터미널 명령 켜짐" if ALLOW_BASH else "파일·검색만"),
            "%d회 실패 시 %d분 차단" % (MAX_TRIES, BLOCK_MINUTES)]
    if PHONE_MODE and not TS_URL:
        bits.append("테일스케일 꺼짐 — 밖에서는 안 열립니다")
    print(paint("   " + "  ·  ".join(bits), "2;37"))
    print(paint("   멈추려면 Ctrl+C  ·  창을 닫아도 되게 하려면  {{실장}}앱끄기 / 자동시작 설정", "2;37"))
    print("")




# ──────────────────────────────────────────── 클로드 사용량
# {{호칭}} 플랜(맥스 5x)의 남은 한도를 {{실장}} 화면 위에 계속 띄워 준다.
# 토큰은 맥 키체인에 있는 것을 그때그때 읽는다(자동 갱신되므로 파일로 복사해 두지 않는다).
_usage_cache = {"t": 0, "v": None}

def usage_token():
    try:
        out = subprocess.run(["security", "find-generic-password",
                              "-s", "Claude Code-credentials", "-w"],
                             capture_output=True, text=True, timeout=10).stdout.strip()
        d = json.loads(out)
        return (d.get("claudeAiOauth") or d).get("accessToken")
    except Exception:
        pass
    # 윈도우(퍼스널 OS 고객)는 키체인이 없고 ~/.claude/.credentials.json 에 있다 (2026-11-01)
    try:
        with open(os.path.join(os.path.expanduser("~"), ".claude", ".credentials.json"), encoding="utf-8") as f:
            d = json.load(f)
        return (d.get("claudeAiOauth") or d).get("accessToken")
    except Exception:
        return None

def usage_fetch():
    """5시간 한도 · 주간 한도 사용률을 가져온다. 60초 동안은 그대로 쓴다."""
    now = time.time()
    if _usage_cache["v"] and now - _usage_cache["t"] < 60:
        return _usage_cache["v"]
    tok = usage_token()
    if not tok:
        return {"error": "토큰 없음"}
    import urllib.request
    req = urllib.request.Request(
        "https://api.anthropic.com/api/oauth/usage",
        headers={"Authorization": "Bearer " + tok,
                 "anthropic-beta": "oauth-2025-04-20",
                 "Content-Type": "application/json",
                 "User-Agent": "claude-cli/1.0"})
    try:
        d = json.loads(urllib.request.urlopen(req, timeout=15).read().decode())
    except Exception as e:
        return {"error": str(e)[:80]}
    def part(k):
        v = d.get(k) or {}
        return {"쓴비율": v.get("utilization"), "초기화": v.get("resets_at")}
    out = {"세션": part("five_hour"), "주간": part("seven_day"), "받은시각": now}
    _usage_cache["t"] = now
    _usage_cache["v"] = out
    return out

# ──────────────────────────────────────────── 아이폰 알림 (웹푸시)
# 홈 화면에 추가한 {{실장}} 앱으로 알림을 보낸다. 새 앱을 깔 필요가 없다.
PUSH_CONF = os.path.join(DATA, "웹푸시.json")
PUSH_SUBS = os.path.join(DATA, "웹푸시_구독.json")

def push_conf():
    try:
        with open(PUSH_CONF, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def push_load():
    try:
        with open(PUSH_SUBS, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []

def push_save(subs):
    tmp = PUSH_SUBS + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(subs, f, ensure_ascii=False, indent=1)
    os.replace(tmp, PUSH_SUBS)

def push_add(sub):
    subs = push_load()
    if not any(x.get("endpoint") == sub.get("endpoint") for x in subs):
        subs.append(sub)
        push_save(subs)
    return len(subs)

def push_remove(endpoint):
    subs = push_load()
    keep = [x for x in subs if x.get("endpoint") != endpoint]
    if len(keep) != len(subs):
        push_save(keep)
    return len(keep)

NOTICE_LOG = os.path.join(DATA, "알림기록.json")


def notice_log(title, body, url):
    """보낸 알림을 남겨 둔다 — 아이폰에서 알림을 눌러 사라져도 앱 🔔 에서 다시 본다 (2026-10-05)"""
    try:
        with open(NOTICE_LOG, encoding="utf-8") as f:
            arr = json.load(f)
    except Exception:
        arr = []
    arr.insert(0, {"t": datetime.datetime.now().strftime("%Y-%m-%d %H:%M"), "title": title, "body": body, "url": url})
    with open(NOTICE_LOG, "w", encoding="utf-8") as f:
        json.dump(arr[:300], f, ensure_ascii=False, indent=1)


def push_send(title, body, url="/"):
    """등록된 기기 전부에 알림을 보낸다. (보낸 수, 실패 수)"""
    if url == "/":
        url = "/#notice"
    try:
        notice_log(title, body, url)
    except Exception as e:
        say("알림 기록 실패: %s" % e, "⚠️")
    conf = push_conf()
    subs = push_load()
    priv = conf.get("비밀키")
    if not priv or not subs:
        return 0, 0
    try:
        from pywebpush import webpush, WebPushException
        from py_vapid import Vapid02
    except Exception as e:
        say("알림 라이브러리 없음: %s" % e, "⚠️")
        return 0, 0
    vapid = Vapid02.from_raw(priv.encode())
    payload = json.dumps({"title": title, "body": body, "url": url}, ensure_ascii=False)
    ok = bad = 0
    keep = []
    for sub in subs:
        try:
            webpush(subscription_info=sub, data=payload,
                    vapid_private_key=vapid,
                    vapid_claims={"sub": conf.get("메일", "mailto:{{메일}}")})
            ok += 1
            keep.append(sub)
        except Exception as e:
            code = getattr(getattr(e, "response", None), "status_code", None)
            if code in (404, 410):      # 기기가 구독을 버렸다 — 목록에서 뺀다
                bad += 1
            else:
                bad += 1
                keep.append(sub)
            say("알림 실패(%s): %s" % (code, e), "⚠️")
    if len(keep) != len(subs):
        push_save(keep)
    return ok, bad

SW_JS = """
self.addEventListener('push', function (e) {
  var d = {};
  try { d = e.data ? e.data.json() : {}; } catch (err) { d = { body: e.data ? e.data.text() : '' }; }
  e.waitUntil(self.registration.showNotification(d.title || '{{실장}}', {
    body: d.body || '', icon: '/icon.png', badge: '/icon.png',
    data: { url: d.url || '/' }, tag: 'elvin'
  }));
});
self.addEventListener('notificationclick', function (e) {
  e.notification.close();
  var u = (e.notification.data && e.notification.data.url) || '/';
  e.waitUntil(clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function (ws) {
    for (var i = 0; i < ws.length; i++) { if ('focus' in ws[i]) { try { ws[i].postMessage({ notice: 1 }); } catch (x) {} return ws[i].focus(); } }
    if (clients.openWindow) return clients.openWindow(u);
  }));
});
"""

# ═══ 09 감사실 — 감사실장 리바이 (2026-10-19 {{호칭}}) ═══
# "리바이, 검토해" 처럼 '리바이'로 시작하면 클로드 대신 ~/감사실/리바이.py(제미나이)가 {{실장}}의 마지막 답을 검토한다.
LEVI_DIR = os.path.expanduser("~/감사실")
LEVI_ON = os.path.isfile(os.path.join(LEVI_DIR, "리바이.py"))   # 감사실이 깔린 컴퓨터에서만 리바이를 쓴다(퍼스널 OS 고객 키트엔 없음, 2026-10-27)
LEVI_RE = re.compile(r"^\s*@?리바이")
TEXT_EXT = (".md", ".txt", ".html", ".py", ".csv", ".json", ".sh")


def levi_review(thread, note):
    ms = [m for m in (thread.get("messages") or []) if (m.get("text") or "").strip()]
    ans_i = next((i for i in range(len(ms) - 1, -1, -1) if ms[i].get("role") == "elvin"), None)
    if ans_i is None:
        return "검토할 {{실장}}의 답이 아직 없다. 먼저 일을 시키고 나서 불러라."
    answer = ms[ans_i]["text"]
    ask = next((ms[i]["text"] for i in range(ans_i - 1, -1, -1) if ms[i].get("role") == "user" and not LEVI_RE.match(ms[i]["text"])), "")
    files, seen = [], set()
    for m in re.finditer(r"(?:~/퍼스널OS/|/Users/[^/\s]+/본사/)?((?:부서|\.os_데이터)/[^\s`'\")\]]+)", answer):
        rel = m.group(1).rstrip(".,·")
        pth = os.path.join(ROOT, rel)
        if rel in seen or not rel.lower().endswith(TEXT_EXT) or not os.path.isfile(pth):
            continue
        seen.add(rel)
        try:
            with open(pth, encoding="utf-8") as f:
                files.append([rel, f.read()[:20000]])
        except Exception:
            pass
    note = LEVI_RE.sub("", note).strip(" ,.:!")
    if note in ("검토해", "검토해줘", "검토해 줘", "검토", "봐줘", "봐 줘"):
        note = ""
    try:
        r = subprocess.run([sys.executable, os.path.join(LEVI_DIR, "리바이.py")], input=json.dumps({"ask": ask, "answer": answer, "files": files[:6], "note": note}, ensure_ascii=False),
                           capture_output=True, text=True, timeout=200, cwd=LEVI_DIR)
        out = (r.stdout or "").strip()
        return out or ("감사실 연결이 안 된다 — " + (r.stderr or "")[-300:])
    except Exception as e:
        return "감사실 연결이 안 된다 — %s" % e


DUO_RE = re.compile(r"둘이서|둘이 같이|둘이 의논|둘이 상의")
LEVI_PASS = re.compile(r"판정[^\n]{0,8}통과")


AUTO_SKIP = re.compile(r"^\s*(굿|좋아|좋다|ㅇㅋ|오케이|ok|ㅇㅇ|응|고마워|감사|ㄳ|ㅋ+|ㅎ+|넵|네)[!.~ㅋㅎ\s]*$", re.I)
AUTO_HIT = re.compile(r"\.(pdf|pptx|xlsx|docx|hwp|hwpx|md|html|png|jpg|zip)\b|견적|계약|금액|부가세|\d[\d,]{2,}\s*원|메일|임시보관함|메시지 초안|보낼 문구|일정|캘린더|마감|발주|주문|결제|배포|업로드|올렸|설치|\d{1,2}/\d{1,2}|\d{1,2}월 \d{1,2}일|요일")


def needs_review(text, answer):
    """{{호칭}}이 따로 부르지 않아도 리바이가 알아서 볼 답인지 (2026-10-19 {{호칭}}: 단순 대화 말고 검토가 필요한 것만)"""
    if not os.path.exists(os.path.join(LEVI_DIR, "리바이.py")):   # 감사실이 없는 컴퓨터(고객 퍼스널 OS)에서는 끈다 (2026-10-25)
        return False
    if not answer or len(answer) < 350 or AUTO_SKIP.match(text or ""):
        return False
    if LEVI_RE.match(text or "") or DUO_RE.search(text or ""):
        return False
    return len(AUTO_HIT.findall(answer)) >= 2


def last_dept(tid):
    th = load_thread(tid) or {}
    for m in reversed(th.get("messages") or []):
        if m.get("role") == "elvin" and m.get("dept"):
            return next((k for k, v in DEPT_LABEL.items() if v == m["dept"]), "00_비서실")
    return "00_비서실"


def elvin_answer_levi(tid, review):
    """리바이가 {{실장}}에게 지적하면 {{실장}}이 알아서 답한다 — 맞는 건 고치고, 아닌 건 근거 (2026-10-19 {{호칭}}). 통과면 답하지 않는다. 한 번만 답한다(핑퐁 없음)"""
    r = review or ""
    if "감사실 연결이 안 된다" in r or "제미나이 쪽이 붐비거나" in r:
        return
    # 통과여도 '{{실장}}에게' 할 말(고칠 것)이 있으면 답한다. 통과 + 구멍 없음 + {{실장}}에게 없음이면 조용히 둔다
    asks = re.search(r"{{실장}}에게\**\s*[—:-]?\s*\n?\s*(\S.{4,})", r)
    no_hole = re.search(r"구멍\**\s*[—:-]?\s*\n?\s*\(?없음", r)
    if LEVI_PASS.search(r) and (not asks or no_hole):
        return
    dept = last_dept(tid)
    gate = thread_queue(tid)
    gate.acquire()
    eidx = append_msg(tid, {"role": "elvin", "text": "", "partial": True, "dept": DEPT_LABEL.get(dept, dept), "ts": time.time()})
    MAIN_DEPT[tid] = dept
    try:
        prompt = ("감사실장 리바이(제미나이)가 방금 네 답을 검토해 너에게 말했다. 아래가 리바이의 검토다.\n\n" + review +
                  "\n\n리바이 지적 중 맞는 것은 실제로 고쳐 반영하고(파일이면 파일을 고친다), 동의하지 않는 것은 근거를 대라. "
                  "{{호칭}}이 읽는 답으로 짧게 쓴다. 첫 줄은 '🗡️ 리바이 지적 — <반영/유지 요약>'. 본문: 반영한 것 / 유지한 것(근거).")
        ans = run_claude(load_thread(tid), prompt, lambda o: None, lambda t: patch_msg(tid, eidx, text=t), main=True)
    except Exception as e:
        ans = "리바이 지적에 답하다 막혔습니다: %s" % e
    finally:
        MAIN_DEPT.pop(tid, None)
        try:
            gate.release()
        except RuntimeError:
            pass
    patch_msg(tid, eidx, text=ans, partial=False, ts=time.time())
    say("{{실장}}이 리바이 지적에 답함", "🗡️")


def auto_levi(tid):
    try:
        th = load_thread(tid)
        if not th:
            return
        review = levi_review(th, "")
        append_msg(tid, {"role": "levi", "text": review, "ts": time.time(), "dept": "09 감사실", "auto": True})
        say("리바이 자동 검토 — %s" % ("통과" if LEVI_PASS.search(review) else "지적 있음"), "🗡️")
        elvin_answer_levi(tid, review)
    except Exception as e:
        say("리바이 자동 검토 오류: %s" % e, "⚠️")


def duo_loop(tid, dept, rounds=2):
    """'둘이서 해봐' — {{실장}}이 처리한 답을 리바이가 검토하고, 지적이 있으면 {{실장}}이 고쳐 답한다(최대 2번 왕복). 2026-10-19 {{호칭}}"""
    try:
        for r in range(rounds):
            th = load_thread(tid)
            if not th:
                return
            review = levi_review(th, "")
            append_msg(tid, {"role": "levi", "text": review, "ts": time.time(), "dept": "09 감사실"})
            say("리바이 검토 %d차 — %s" % (r + 1, "통과" if LEVI_PASS.search(review) else "지적"), "🗡️")
            if LEVI_PASS.search(review):
                push_send("{{실장}}·리바이 협의 끝 ✅", "리바이 통과 — " + re.sub(r"\s+", " ", review)[:120])
                return
            gate = thread_queue(tid)
            gate.acquire()
            eidx = append_msg(tid, {"role": "elvin", "text": "", "partial": True, "dept": DEPT_LABEL.get(dept, dept), "ts": time.time()})
            MAIN_DEPT[tid] = dept
            try:
                prompt = ("감사실장 리바이(제미나이)가 방금 네 답을 검토했다. 아래가 리바이의 검토다.\n\n" + review +
                          "\n\n{{호칭}}이 '둘이서 해봐'라고 하셨으니 둘이 협의해 끝까지 처리한다. 리바이 지적 중 맞는 것은 실제로 고쳐 반영하고(파일이면 파일을 고친다), "
                          "동의하지 않는 것은 근거를 대라. 리바이에게 하는 말이 아니라 {{호칭}}이 읽는 답으로 쓴다. 첫 줄은 '🗡️ 리바이 지적 반영 — <요약>'. "
                          "본문: 반영한 것 / 유지한 것(근거) / 최종 결과.")
                ans = run_claude(load_thread(tid), prompt, lambda o: None, lambda t: patch_msg(tid, eidx, text=t), main=True)
            finally:
                MAIN_DEPT.pop(tid, None)
                try:
                    gate.release()
                except RuntimeError:
                    pass
            patch_msg(tid, eidx, text=ans, partial=False, ts=time.time())
        th = load_thread(tid)
        if th:
            review = levi_review(th, "")
            append_msg(tid, {"role": "levi", "text": review, "ts": time.time(), "dept": "09 감사실"})
        push_send("{{실장}}·리바이 협의 끝", re.sub(r"\s+", " ", review)[:140])
    except Exception as e:
        say("둘이서 협의 오류: %s" % e, "⚠️")


class Handler(BaseHTTPRequestHandler):
    server_version = "ElvinDesk/2.0"

    # 화면이 3초마다 확인하는 기록은 찍지 않는다.
    # 로그인·오류처럼 {{호칭}}이 알아야 할 일만 남긴다. (메시지는 handle_send 가 찍는다)
    def log_message(self, fmt, *args):
        line = fmt % args
        if "/api/login" in line:
            say("로그인 성공" if " 200" in line else "로그인 실패",
                "🔓" if " 200" in line else "⛔", self.client_address[0])
        elif " 500 " in line or " 404 " in line:
            say(line.strip(), "⚠️")

    def _json(self, obj, code=200, cookie=None):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        if cookie:
            self.send_header("Set-Cookie", cookie)
        self.end_headers()
        self.wfile.write(body)

    def _bytes(self, body, ctype, cache="no-cache"):
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        self.end_headers()
        self.wfile.write(body)

    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if not n:
            return {}
        try:
            return json.loads(self.rfile.read(n).decode("utf-8"))
        except Exception:
            return {}

    def _guard(self):
        if is_logged_in(self):
            return True
        self._json({"error": "locked"}, 401)
        return False

    def do_GET(self):
        path = self.path.split("?")[0]
        if path in ("/", "/index.html"):
            try:
                with open(WEB, "rb") as f:
                    self._bytes(f.read(), "text/html; charset=utf-8",
                                cache="no-store, no-cache, must-revalidate, max-age=0")
            except FileNotFoundError:
                self.send_error(500, "elvin_web.html 이 없습니다")
        elif path in ("/interview", "/interview/"):
            # 퍼스널 OS AI 인터뷰 화면 (2026-10-17) — 화면·로직은 elvin_interview.html/.py, 요청마다 새로 읽는다
            try:
                with open(os.path.join(ROOT, "elvin_interview.html"), "rb") as f:
                    self._bytes(f.read(), "text/html; charset=utf-8", cache="no-store")
            except FileNotFoundError:
                self.send_error(404)
        elif path.startswith("/api/iv/"):
            if self._guard():
                import importlib, elvin_interview
                importlib.reload(elvin_interview)
                q = urllib.parse.parse_qs(self.path.split("?", 1)[1] if "?" in self.path else "")
                r = elvin_interview.get(path, q)
                if isinstance(r, tuple):
                    self._bytes(r[1], r[2], cache="no-store")
                else:
                    self._json(r)
        elif path == "/icon.png":
            data, ctype = icon_bytes()
            self._bytes(data, ctype, cache="max-age=86400")
        elif path == "/manifest.webmanifest":
            man = {
                "name": APP_NAME, "short_name": APP_NAME,
                "start_url": "/", "display": "standalone",
                "background_color": "#0f0f12", "theme_color": "#0f0f12",
                "icons": [{"src": "/icon.png", "sizes": "512x512", "type": icon_bytes()[1],
                           "purpose": "any maskable"}],
            }
            self._bytes(json.dumps(man, ensure_ascii=False).encode("utf-8"),
                        "application/manifest+json; charset=utf-8")
        elif path == "/sw.js":
            self._bytes(SW_JS.encode("utf-8"), "application/javascript; charset=utf-8")
        elif path == "/api/usage":
            if self._guard():
                self._json(usage_fetch())
        elif path == "/api/routines":
            # ⚙️ 자동업무 보드 (2026-10-07) — 매번 elvin_routines.py 를 새로 읽어 서버 재시작 없이 업무 추가 가능
            if self._guard():
                try:
                    import importlib, elvin_routines
                    importlib.reload(elvin_routines)
                    self._json(elvin_routines.status())
                except Exception as e:
                    self._json({"items": [], "error": str(e)})
        elif path == "/api/notices":
            if self._guard():
                try:
                    with open(NOTICE_LOG, encoding="utf-8") as f:
                        self._json({"items": json.load(f)[:150]})
                except Exception:
                    self._json({"items": []})
        elif path == "/api/push/key":
            self._json({"key": push_conf().get("공개키", ""), "기기수": len(push_load())})
        elif path == "/api/hello":
            self._json({"locked": not is_logged_in(self), "lan": LAN_URL, "app": APP_NAME})
        elif path == "/api/todo":
            if self._guard():
                st = elvin_todo.view()
                self._json({"items": st["items"], "today": elvin_todo.today()})
        elif path == "/api/threads":
            if self._guard():
                self._json({"threads": list_threads()})
        elif path.startswith("/api/thread/"):
            if self._guard():
                t = load_thread(path.rsplit("/", 1)[-1])
                if t:
                    t["long"] = is_long(t)
                    t.pop("carry", None)
                self._json(t or {"error": "없는 대화"}, 200 if t else 404)
        elif path == "/api/memos":
            if self._guard():
                self._json(elvin_memo.view())
        elif path == "/api/devlog":
            # 퍼스널 OS 개발일지 (2026-11-01) — 고쳐도 서버 재시작 없이 반영되게 매번 다시 읽음
            if self._guard():
                import importlib, elvin_devlog
                importlib.reload(elvin_devlog)
                self._json(elvin_devlog.view())
        elif path == "/api/recent":
            if self._guard():
                self._json({"files": recent_files()})
        elif path == "/api/office":
            if self._guard():
                self._json(office_status())
        elif path == "/api/ls":
            if self._guard():
                q = urllib.parse.parse_qs(self.path.split("?", 1)[1] if "?" in self.path else "")
                d = list_dir(q.get("p", ["부서"])[0])
                self._json(d or {"error": "없는 폴더"}, 200 if d else 404)
        elif path == "/api/calendar":
            if self._guard():
                self._json(calendar_cache())
        elif path == "/api/preview":
            if self._guard():
                q = urllib.parse.parse_qs(self.path.split("?", 1)[1] if "?" in self.path else "")
                info = preview_info(q.get("p", [""])[0])
                self._json(info or {"error": "없는 파일"}, 200 if info else 404)
        elif path == "/api/previewimg":
            if not is_logged_in(self):
                self.send_error(403)
                return
            q = urllib.parse.parse_qs(self.path.split("?", 1)[1] if "?" in self.path else "")
            k, n = q.get("k", [""])[0], q.get("n", [""])[0]
            fp = os.path.join(PREVIEW, k, n + ".jpg")
            if not (re.fullmatch(r"[0-9a-f]{16}", k) and n.isdigit() and os.path.isfile(fp)):
                self.send_error(404)
                return
            with open(fp, "rb") as f:
                self._bytes(f.read(), "image/jpeg", cache="max-age=86400")
        elif path == "/api/file":
            if not is_logged_in(self):
                self.send_error(403)
                return
            q = urllib.parse.parse_qs(self.path.split("?", 1)[1] if "?" in self.path else "")
            fp = safe_file(q.get("p", [""])[0])
            if not fp:
                self.send_error(404)
                return
            import mimetypes
            ctype = mimetypes.guess_type(fp)[0] or "application/octet-stream"
            if ctype.startswith("text/"):
                ctype += "; charset=utf-8"
            with open(fp, "rb") as f:
                data = f.read()
            # 2026-10-05 영상 보기 — 아이폰 사파리는 Range(부분 요청)를 받아야 영상을 재생한다
            m = re.match(r"bytes=(\d*)-(\d*)", self.headers.get("Range", "") or "")
            if m and (m.group(1) or m.group(2)):
                n = len(data)
                if m.group(1):
                    a = int(m.group(1)); b = min(int(m.group(2)) if m.group(2) else n - 1, n - 1)
                else:
                    a = max(0, n - int(m.group(2))); b = n - 1
                self.send_response(206)
                self.send_header("Content-Type", ctype)
                self.send_header("Accept-Ranges", "bytes")
                self.send_header("Content-Range", "bytes %d-%d/%d" % (a, b, n))
                self.send_header("Content-Length", str(b - a + 1))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(data[a:b + 1])
                return
            self.send_response(200)
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Content-Disposition", "inline; filename*=UTF-8''" + urllib.parse.quote(os.path.basename(fp)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(data)
        elif path.startswith("/upload/"):
            if not is_logged_in(self):
                self.send_error(403)
                return
            name = os.path.basename(urllib.parse.unquote(path.rsplit("/", 1)[-1]))
            p = os.path.join(UPLOADS, name)
            if not os.path.exists(p):
                self.send_error(404)
                return
            ext = os.path.splitext(name)[1].lower()
            ctype = {"jpg": "image/jpeg", "jpeg": "image/jpeg", "png": "image/png",
                     "gif": "image/gif", "webp": "image/webp",
                     "heic": "image/heic"}.get(ext.lstrip("."), "application/octet-stream")
            with open(p, "rb") as f:
                self._bytes(f.read(), ctype, cache="max-age=3600")
        else:
            self.send_error(404)

    def do_POST(self):
        path = self.path.split("?")[0]
        if path.startswith("/api/iv/"):
            if self._guard():
                import importlib, elvin_interview
                importlib.reload(elvin_interview)
                try:
                    self._json(elvin_interview.post(path, self._body()))
                except Exception as e:
                    self._json({"ok": False, "error": str(e)[:300]}, 500)
            return
        if path == "/api/login":
            ip = self.client_address[0]
            left = blocked_for(ip)
            if left:
                self._json({"ok": False,
                            "error": "너무 여러 번 틀렸습니다. %d분 뒤에 다시 시도해 주세요."
                                     % max(1, round(left / 60))}, 429)
                return
            given = str(self._body().get("password", ""))
            if given == PASSWORD:
                note_success(ip)
                self._json({"ok": True},
                           cookie="elvin_key=%s; Path=/; Max-Age=31536000; SameSite=Lax" % TOKEN)
            else:
                time.sleep(0.6)
                if note_fail(ip):
                    self._json({"ok": False,
                                "error": "%d번 틀렸습니다. %d분 동안 잠깁니다."
                                         % (MAX_TRIES, BLOCK_MINUTES)}, 429)
                else:
                    self._json({"ok": False, "error": "비밀번호가 다릅니다"}, 401)
            return
        if path == "/api/push/send":
            # 이 컴퓨터 안에서만 부를 수 있다 (알림.sh 가 쓴다)
            if self.client_address[0] not in ("127.0.0.1", "::1"):
                self.send_error(403)
                return
            b = self._body()
            ok, bad = push_send(b.get("title") or "{{실장}}",
                                b.get("body") or "", b.get("url") or "/")
            self._json({"보냄": ok, "실패": bad, "기기수": len(push_load())})
            return
        if not self._guard():
            return
        if path == "/api/push/subscribe":
            sub = self._body().get("sub") or {}
            if not sub.get("endpoint"):
                self._json({"ok": False, "error": "구독 정보 없음"}, 400)
                return
            n = push_add(sub)
            say("알림 기기 등록 (%d대)" % n, "🔔")
            self._json({"ok": True, "기기수": n})
            return
        if path == "/api/push/unsubscribe":
            ep = self._body().get("endpoint") or ""
            n = push_remove(ep)
            say("알림 끔 (남은 기기 %d대)" % n, "🔕")
            self._json({"ok": True, "기기수": n})
            return
        if path == "/api/routines/run":
            if not is_logged_in(self):
                self.send_error(403); return
            try:
                import importlib, elvin_routines
                importlib.reload(elvin_routines)
                self._json(elvin_routines.run(str(self._body().get("id", ""))))
            except Exception as e:
                self._json({"ok": False, "msg": str(e)})
            return
        if path == "/api/memos":
            self._json(elvin_memo.apply_op(self._body()))
            return
        if path == "/api/devlog":
            import importlib, elvin_devlog
            importlib.reload(elvin_devlog)
            self._json(elvin_devlog.apply_op(self._body()))
            return
        if path == "/api/todo":
            _imp_lib.reload(elvin_todo)   # 할일 기능을 고쳐도 서버 재시작 없이 반영 (2026-10-07)
            st = elvin_todo.apply_op(self._body())
            self._json({"items": st["items"], "today": elvin_todo.today()})
            return
        if path == "/api/new":
            self._json(new_thread())
        elif path == "/api/continue":
            # 길어진 대화를 인계노트와 함께 새 대화로 옮긴다 (2026-10-28 {{호칭}} 지시)
            t = continue_thread(str(self._body().get("thread_id", "")))
            self._json(t or {"error": "없는 대화"}, 200 if t else 404)
        elif path == "/api/delete":
            ok = trash_thread(str(self._body().get("thread_id", "")))
            self._json({"ok": ok}, 200 if ok else 404)
        elif path == "/api/send":
            self.handle_send()
        else:
            self.send_error(404)

    # 답이 나오는 대로 한 줄씩 흘려보낸다 (Server-Sent Events)
    def handle_send(self):
        data = self._body()
        text = (data.get("text") or "").strip()
        thread = load_thread(data.get("thread_id")) or new_thread()

        saved, shown = [], []
        for f in data.get("files", []) or []:
            name = re.sub(r"[/\\]", "_", f.get("name") or "첨부")
            try:
                raw = base64.b64decode((f.get("data") or "").split(",")[-1])
            except Exception:
                continue
            fname = time.strftime("%y%m%d_%H%M%S_") + name
            p = os.path.join(UPLOADS, fname)
            with open(p, "wb") as fh:
                fh.write(raw)
            saved.append(p)
            shown.append(fname)

        if not text and not saved:
            self._json({"error": "빈 메시지"}, 400)
            return

        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()

        def emit(obj):
            try:
                self.wfile.write(("data: " + json.dumps(obj, ensure_ascii=False) + "\n\n").encode("utf-8"))
                self.wfile.flush()
            except (BrokenPipeError, ValueError, OSError):
                pass

        if LEVI_ON and LEVI_RE.match(text or ""):
            tid = thread["id"]
            emit({"type": "thread", "id": tid})
            emit({"type": "dept", "text": "09 감사실"})
            emit({"type": "status", "text": "감사실장 리바이가 {{실장}}의 답을 검토하는 중… (30초~1분)"})
            append_msg(tid, {"role": "user", "text": text, "ts": time.time(), "files": shown}, title_hint=text)
            say("09 감사실 — 리바이 검토", "🗡️", self.client_address[0])
            review = levi_review(load_thread(tid) or thread, text)
            append_msg(tid, {"role": "levi", "text": review, "ts": time.time(), "dept": "09 감사실"})
            emit({"type": "done", "text": review, "who": "levi"})
            threading.Thread(target=elvin_answer_levi, args=(tid, review), daemon=True).start()
            return

        dept = pick_department(text)
        guide = pick_guide_file(dept, text)
        emit({"type": "thread", "id": thread["id"]})
        emit({"type": "status", "text": "%s 로 보냄 · %s 읽는 중"
              % (DEPT_LABEL.get(dept, dept),
                 os.path.basename(guide) if guide else "건 확인 필요")})
        emit({"type": "dept", "text": DEPT_LABEL.get(dept, dept)})

        say("%s — %s" % (DEPT_LABEL.get(dept, dept), (text or "(사진만)")[:34]), "💬",
            self.client_address[0])
        began = time.time()

        jid = "%x" % int(began * 1000)
        with OFFICE_LOCK:
            OFFICE[jid] = {"dept": DEPT_LABEL.get(dept, dept), "ask": (text or "(사진만)")[:60], "ctx": "",
                           "now": "읽는 중", "began": began, "upd": began}
        _emit0 = emit

        def emit(obj):
            if obj.get("type") == "status":
                office_set(jid, now=str(obj.get("text", ""))[:50])
            _emit0(obj)

        tid = thread["id"]
        append_msg(tid, {"role": "user", "text": text, "ts": time.time(), "files": shown},
                   title_hint=text or None)
        thread = load_thread(tid) or thread     # 다른 요청이 남긴 말까지 합쳐서 다시 읽는다

        # 답할 자리를 먼저 만들어 둔다. 흘러나오는 대로 이 자리에 계속 적는다.
        eidx = append_msg(tid, {"role": "elvin", "text": "", "partial": True,
                                "dept": DEPT_LABEL.get(dept, dept), "ts": time.time()})

        def progress(txt):
            patch_msg(tid, eidx, text=txt)
            office_head(jid, txt)

        gate = thread_queue(thread["id"])
        idle = main_idle(thread["id"])
        stop_now = any(w in text for w in STOP_WORDS)
        stale = idle is not None and idle > STALE_MAIN and is_follow(tid, text, dept)   # 이어지는 말인데 앞 일이 멈춰 있으면
        if idle is not None and (stop_now or stale):
            say("앞 작업 끊고 새 말씀을 본 작업으로 받음 (%d초 무응답)" % idle, "⛔")
            emit({"type": "status", "text": "멈춰 있던 앞 작업을 끊고 이 말씀을 바로 처리합니다"})
            stop_main(thread["id"])
            gate.acquire(timeout=15)
            gate_ok = True
        else:
            gate_ok = gate.acquire(blocking=False)
        mode = "main" if gate_ok else pick_mode(tid, text, dept)
        if mode == "queue":
            pos = gate.waiting() + 1
            emit({"type": "mode", "text": "📥 대기 %d번 — 앞 일이 끝나면 바로 이어서 합니다" % pos})
            say("대기열 %d번 — %s" % (pos, (text or "")[:30]), "📥")
            office_set(jid, now="대기 %d번" % pos)
            gate.acquire()
            gate_ok = True
            emit({"type": "mode", "text": ""})
        if gate_ok:
            # 본 작업 — 대화를 이어서 답한다 (대기열에서 차례가 온 일도 여기로)
            MAIN_DEPT[tid] = dept
            try:
                thread = load_thread(tid) or thread
                carry = ""
                if thread.get("carry") and not thread.get("started"):
                    carry = thread["carry"] + "\n\n"
                brief = guide_seen(thread, guide)
                answer = run_claude(thread, take_notes(tid) + carry + build_prompt(text, dept, guide, saved, brief=brief),
                                    emit, progress, main=True)
                if not answer.startswith("[막힌 곳]"):
                    if guide and not thread.get("_compacted"):
                        mark_guide(tid, guide)
                    if carry:
                        _rw(tid, lambda x: x.pop("carry", None))
            finally:
                MAIN_DEPT.pop(tid, None)
                try:
                    gate.release()
                except RuntimeError:
                    pass
            # 2분 넘게 걸린 일은 끝나면 아이폰으로 알린다 (창을 다시 열어 보실 필요 없게)
            if time.time() - began > 120:
                head = re.sub(r"\s+", " ", answer.split("\n", 1)[0])[:60]
                body = re.sub(r"\s+", " ", answer)[:140]
                threading.Thread(target=push_send, args=("{{실장}} · 작업 끝 " + head[:30], body),
                                 daemon=True).start()
        else:
            # 동시 출동 — 다른 부서 일을 곁에서 끝까지 처리한다
            label = DEPT_LABEL.get(dept, dept)
            emit({"type": "mode", "text": "⚡ 동시 출동 — %s" % label})
            say("동시 출동 %s (앞 작업 진행 중)" % label, "⚡")
            PAR_DEPTS.setdefault(tid, []).append(dept)
            try:
                answer = run_claude(side_thread(thread), parallel_prompt(thread, text, dept, guide, saved),
                                    emit, progress)
            finally:
                try:
                    PAR_DEPTS.get(tid, []).remove(dept)
                except ValueError:
                    pass
                with _par_guard:
                    _par["n"] = max(0, _par["n"] - 1)
            SIDE_NOTES.setdefault(tid, []).append("- {{호칭}}: %s\n  → %s 처리: %s" % (
                (text or "")[:200], label, re.sub(r"\s+", " ", answer)[:500]))
            if time.time() - began > 120:
                head = re.sub(r"\s+", " ", answer.split("\n", 1)[0])[:60]
                threading.Thread(target=push_send, args=("{{실장}} · 동시 출동 끝 " + head[:30], re.sub(r"\s+", " ", answer)[:140]),
                                 daemon=True).start()
        office_head(jid, answer)
        office_end(jid, answer)
        patch_msg(tid, eidx, text=answer, partial=False, ts=time.time())
        say("답변 완료 (%d초, %d자)" % (time.time() - began, len(answer)), "✅")
        emit({"type": "done", "text": answer})
        if LEVI_ON and needs_review(text, answer):
            # 검토가 필요한 답이면 리바이가 알아서 본다 (화면은 3초마다 새 말을 불러옴)
            threading.Thread(target=auto_levi, args=(tid,), daemon=True).start()
        if LEVI_ON and DUO_RE.search(text or ""):
            # 둘이서 해봐 — {{실장}} 답이 끝나면 리바이 검토 → {{실장}} 반영을 뒤에서 이어 간다 (화면은 3초마다 새 말을 불러옴)
            threading.Thread(target=duo_loop, args=(tid, dept), daemon=True).start()


def main():
    bad = password_problem()
    if bad:
        print("")
        print("비밀번호를 다시 정해 주세요 — %s." % bad)
        print("여덟 글자 이상이면서 숫자만은 아니어야 합니다. (예: brand2026)")
        print("%s 파일 위쪽 PASSWORD = \"...\" 를 고치고 다시 켜 주세요." % os.path.basename(__file__))
        print("")
        sys.exit(1)

    def todo_morning():
        """매일 아침 9시 이후 한 번: 오늘·내일 마감인 할 일을 아이폰으로 알린다."""
        while True:
            try:
                if datetime.datetime.now().hour >= 9:
                    lines = elvin_todo.due_reminders()
                    if lines:
                        push_send("📋 마감 알림", "\n".join(lines[:6]), "/")
            except Exception as e:
                say("할일 알림 오류: %s" % e, "⚠️")
            time.sleep(600)
    threading.Thread(target=todo_morning, daemon=True).start()

    srv = ThreadingHTTPServer((HOST, PORT), Handler)
    banner()
    say("{{실장}} 대기 중", "🟢")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("")
        say("{{실장}} 비서 데스크를 닫았습니다.", "🌙")
        print("")


if __name__ == "__main__":
    main()
