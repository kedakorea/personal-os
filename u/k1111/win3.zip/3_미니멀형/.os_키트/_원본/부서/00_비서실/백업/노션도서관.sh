#!/bin/bash
# 노션 '퍼스널 OS 도서관' 백업 (2026-11-08 대표님: 고객 컴퓨터에만 있으면 날아갈 수 있으니 노션을 도서관처럼, 기본 포함)
# 한 시간마다 깨어나 '오늘 백업을 했는지'만 본다 → 22:30 이후 한 번 실행. 22:30에 컴퓨터가 꺼져 있었으면
# 다음에 켜진 때(다음 날 아침 포함) 밀린 날을 바로 백업한다.
cd ~/퍼스널OS
D=~/퍼스널OS/.os_데이터; LAST="$D/노션도서관_마지막.txt"; LOG="$D/노션도서관.log"
today=$(date +%F); yday=$(date -v-1d +%F 2>/dev/null || date -d yesterday +%F); now=$(date +%H%M)
last=$(cat "$LAST" 2>/dev/null)
if [ "$last" = "$today" ]; then exit 0; fi                       # 오늘 이미 함
if [ "$now" -lt 2230 ] && [ "$last" = "$yday" ]; then exit 0; fi  # 어제까지 했고 아직 밤 10:30 전
/usr/bin/python3 부서/00_비서실/백업/대화원본.py >/dev/null 2>&1
{ echo "=== $(date '+%F %T') (마지막 백업: ${last:-없음})"
  perl -e 'alarm 1500; exec @ARGV' ~/.local/bin/claude -p "$(cat 부서/00_비서실/백업/노션도서관_지시.md)

이번 백업 범위: 마지막 백업일(${last:-처음}) 다음 날부터 오늘(${today})까지." --dangerously-skip-permissions 2>&1 | tail -20
} >> "$LOG"
grep -q "노션 도서관 백업 —" ~/퍼스널OS/부서/00_비서실/업무일지.md && tail -3 ~/퍼스널OS/부서/00_비서실/업무일지.md | grep -q "$today · 00 비서실 · 노션 도서관 백업" && echo "$today" > "$LAST"
