#!/usr/bin/env python3
"""압축 뒤 새 세션 시작 때(SessionStart compact 훅) 최신 인계노트를 맥락으로 넣어 준다 (3일 넘은 노트는 무시)."""
import os, time
p = os.path.expanduser("~/퍼스널OS/.os_데이터/인계노트/최신.md")
if os.path.exists(p) and time.time() - os.path.getmtime(p) < 3 * 86400:
    print("[{{실장}} 작업 인계노트 — 압축 직전 상황. 이어서 일할 때 참고하고, 부족하면 부서/00_비서실/업무일지.md 를 읽는다]\n")
    print(open(p, encoding="utf-8").read()[:12000])
