// PDF 쪽마다 PNG 로 그린다 — 퍼스널 OS 앱 파일 미리보기용 (2026-10-03)
// 사용: swift pdf쪽그림.swift 파일.pdf 출력폴더 [가로픽셀]
import PDFKit
import AppKit
let a = CommandLine.arguments
let doc = PDFDocument(url: URL(fileURLWithPath: a[1]))!
let out = a[2]
let W = a.count > 3 ? Double(a[3])! : 1400
for i in 0..<doc.pageCount {
  let p = doc.page(at: i)!
  let r = p.bounds(for: .mediaBox)
  let s = W / Double(r.width)
  let img = p.thumbnail(of: NSSize(width: W, height: Double(r.height) * s), for: .mediaBox)
  let rep = NSBitmapImageRep(data: img.tiffRepresentation!)!
  try! rep.representation(using: .jpeg, properties: [.compressionFactor: 0.85])!.write(to: URL(fileURLWithPath: "\(out)/\(i + 1).jpg"))
}
print(doc.pageCount)
