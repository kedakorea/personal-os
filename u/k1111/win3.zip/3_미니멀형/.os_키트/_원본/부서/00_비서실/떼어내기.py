#!/usr/bin/env python3
"""주어진 명령을 떼어내서(자기 세션으로) 돌린다. 답하던 대화가 끊겨도 같이 죽지 않는다.
사용: 떼어내기.py <스크립트> [인자...]"""
import os, sys
if len(sys.argv) < 2:
    sys.exit("사용법: 떼어내기.py <명령> [인자...]")
log = os.path.expanduser("~/퍼스널OS/.os_데이터/떼어낸작업.log")
if os.fork() > 0:
    os._exit(0)
os.setsid()
if os.fork() > 0:
    os._exit(0)
fd = os.open(log, os.O_WRONLY | os.O_CREAT | os.O_APPEND)
os.dup2(fd, 1); os.dup2(fd, 2)
os.close(os.open(os.devnull, os.O_RDONLY))
os.execv("/bin/bash", ["/bin/bash"] + sys.argv[1:])
