#!/usr/bin/env python3
"""대화 원본 백업 (퍼스널 OS 기본 백업) — 퍼스널 OS 앱 대화·{{실장}} 기억·감사실장 감사기록을 옵시디언 금고(~/퍼스널OS_금고)에 원본 그대로 md 로 남긴다.
{{실장}}과 감사실장는 폴더를 나눈다(안 섞이게):
  ~/퍼스널OS_금고/매니저/대화원본/YYYY-MM/YYMMDD_제목_id.md   — 앱 대화({{호칭}}·{{실장}}·감사실장 말풍선 그대로, 시간 포함)
  ~/퍼스널OS_금고/매니저/기억/                               — {{실장}} 메모리(memory/*.md) + 클로드 세션 기록({{호칭}} 말·{{실장}} 답만, 도구 출력 제외)
  ~/퍼스널OS_금고/매니저/업무일지.md · 할일.json 사본
  ~/퍼스널OS_금고/감사실장/                                  — 감사실장 규칙·감사기록 사본
바뀐 것만 다시 쓴다. 매일 23:40 launchd(com.personalos.vaultbackup)."""
import datetime as dt, glob, json, os, re, shutil
HOME = os.path.expanduser("~")
BON = os.path.join(HOME, "퍼스널OS"); DATA = os.path.join(BON, ".os_데이터")
V = os.path.join(HOME, "퍼스널OS_금고")
CLAUDE_PROJ = os.path.join(HOME, ".claude", "projects", re.sub(r"[^A-Za-z0-9]", "-", BON))   # 클로드가 폴더 경로로 만드는 이름
LEVI = os.path.join(HOME, "감사실")
WHO = {"user": "{{호칭}}", "elvin": "매니저", "levi": "감사실장"}

def safe(s): return re.sub(r'[\\/:*?"<>|\n]+', " ", s or "").strip()[:40] or "대화"
MASK = [re.compile(r"ghp_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|AIza[0-9A-Za-z_-]{30,}|sk-ant-[A-Za-z0-9_-]{10,}|sk-[A-Za-z0-9]{30,}|xox[bp]-[A-Za-z0-9-]{10,}|eyJhbGciOi[A-Za-z0-9._-]{20,}"),
        re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----.*?-----END [A-Z ]*PRIVATE KEY-----", re.S),
        re.compile(r'((?:"|\b)(?:password|passwd|pw|비밀번호|app_password|secret|token|api_key)"?\s*[:=]\s*"?)([^"\s,}]{4,})', re.I)]
def mask(t):
    for i, m in enumerate(MASK):
        t = m.sub((lambda x: x.group(1) + "●●●") if i == 2 else "●●●(가림)", t)
    return t

def wr(p, text):
    text = mask(text)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    try:
        if open(p, encoding="utf-8").read() == text: return 0
    except Exception: pass
    open(p, "w", encoding="utf-8").write(text); return 1

def threads():
    n = 0
    for f in glob.glob(os.path.join(DATA, "threads", "*.json")):
        try: t = json.load(open(f, encoding="utf-8"))
        except Exception: continue
        ms = t.get("messages") or []
        if not ms: continue
        c = dt.datetime.fromtimestamp(t.get("created") or ms[0].get("ts") or os.path.getmtime(f))
        out = ["# %s" % (t.get("title") or "대화"), "", "- 시작: %s · 대화 id: `%s` · 원본: `.os_데이터/threads/%s`" % (c.strftime("%Y-%m-%d %H:%M"), t["id"], os.path.basename(f)), ""]
        for m in ms:
            when = dt.datetime.fromtimestamp(m["ts"]).strftime("%m-%d %H:%M") if m.get("ts") else ""
            out += ["---", "### %s %s%s" % (WHO.get(m.get("role"), m.get("role")), when, (" · " + m["dept"]) if m.get("dept") else ""), ""]
            if m.get("files"): out.append("첨부: " + ", ".join(m["files"]) + "\n")
            out += [m.get("text") or "", ""]
        p = os.path.join(V, "매니저", "대화원본", c.strftime("%Y-%m"), "%s_%s_%s.md" % (c.strftime("%y%m%d"), safe(t.get("title")), t["id"][:8]))
        n += wr(p, "\n".join(out))
    return n

def memory():
    n = 0
    for f in glob.glob(os.path.join(CLAUDE_PROJ, "memory", "*.md")):
        n += wr(os.path.join(V, "매니저", "기억", "메모리", os.path.basename(f)), open(f, encoding="utf-8").read())
    for f in glob.glob(os.path.join(CLAUDE_PROJ, "*.jsonl")):
        p = os.path.join(V, "매니저", "기억", "세션기록", os.path.basename(f)[:-6] + ".md")
        if os.path.exists(p) and os.path.getmtime(p) >= os.path.getmtime(f): continue
        lines = ["# 클로드 세션 %s" % os.path.basename(f)[:-6], "({{호칭}} 말 · {{실장}} 답만 — 도구 실행 내용 제외)", ""]
        try:
            for raw in open(f, encoding="utf-8", errors="ignore"):
                try: d = json.loads(raw)
                except Exception: continue
                m = d.get("message") or {}; role = m.get("role"); c = m.get("content")
                if role not in ("user", "assistant"): continue
                txt = c if isinstance(c, str) else "\n".join(x.get("text", "") for x in (c or []) if isinstance(x, dict) and x.get("type") == "text")
                txt = (txt or "").strip()
                if not txt or (role == "user" and txt.startswith("<")): continue
                lines += ["### %s %s" % ("{{호칭}}" if role == "user" else "매니저", (d.get("timestamp") or "")[:16].replace("T", " ")), txt[:20000], ""]
        except Exception: continue
        n += wr(p, "\n".join(lines))
    for name in ("업무일지.md",):
        src = os.path.join(BON, "부서", "00_비서실", name)
        if os.path.exists(src): n += wr(os.path.join(V, "매니저", name), open(src, encoding="utf-8").read())
    for name in ("CLAUDE.md",):
        n += wr(os.path.join(V, "매니저", "지침", name), open(os.path.join(BON, name), encoding="utf-8").read())
    return n

def levi():
    n = 0
    if not os.path.isdir(LEVI): return 0
    for f in glob.glob(os.path.join(LEVI, "*.md")) + glob.glob(os.path.join(LEVI, "감사기록", "*.md")):
        rel = os.path.relpath(f, LEVI)
        n += wr(os.path.join(V, "감사실장", rel), open(f, encoding="utf-8").read())
    return n

if __name__ == "__main__":
    a, b, c = threads(), memory(), levi()
    msg = "%s 금고 백업 — 대화 %d · {{실장}} 기억 %d · 감사실장 %d 파일 갱신" % (dt.datetime.now().strftime("%Y-%m-%d %H:%M"), a, b, c)
    open(os.path.join(DATA, "금고백업.log"), "a", encoding="utf-8").write(msg + "\n"); print(msg)
