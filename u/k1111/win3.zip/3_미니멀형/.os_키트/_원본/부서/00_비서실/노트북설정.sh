#!/bin/bash
# 노트북용 잠자기 설정 — 전원이 꽂혀 있으면 화면만 꺼지고 컴퓨터는 잠들지 않는다.
# (덮개를 닫거나 배터리로만 쓸 때는 평소대로 잠든다 = OS 퇴근)
echo "맥 로그인 비밀번호를 한 번 넣어 주세요 (화면에 글자가 안 보여도 정상입니다)."
sudo pmset -c sleep 0 displaysleep 10 disksleep 0
pmset -g custom | sed -n '/AC Power/,$p' | grep -E " sleep|displaysleep"
echo "완료 — 전원 연결 중에는 컴퓨터가 잠들지 않습니다."
