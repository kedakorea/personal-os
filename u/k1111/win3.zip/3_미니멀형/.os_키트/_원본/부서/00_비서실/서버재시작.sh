#!/bin/bash
# {{앱이름}} 서버만 다시 띄운다. 반드시 떼어내서 돌린다:
#   python3 ~/퍼스널OS/부서/00_비서실/떼어내기.py ~/퍼스널OS/부서/00_비서실/서버재시작.sh
# 답하는 중이면 끝날 때까지(최대 10분) 기다렸다가 띄운다.
LOG="$HOME/퍼스널OS/.os_데이터/서버재시작.log"
say() { echo "$(date '+%F %T') $*" >> "$LOG"; }
sleep 25
W=0
while pgrep -f "claude -p" >/dev/null 2>&1; do
  [ "$W" -ge 600 ] && { say "10분 넘게 답하는 중 — 그냥 진행"; break; }
  sleep 10; W=$((W + 10))
done
PIDS=$(pgrep -f "퍼스널OS/elvin_server.py")
[ -n "$PIDS" ] && kill -TERM $PIDS 2>/dev/null
sleep 5
curl -s -o /dev/null --max-time 4 http://127.0.0.1:8765/api/hello || launchctl kickstart -k "gui/$(id -u)/com.personalos.server" 2>/dev/null
/Applications/Tailscale.app/Contents/MacOS/Tailscale serve --bg --https=443 http://127.0.0.1:8765 >/dev/null 2>&1
say "재시작 $(curl -s -m 8 -o /dev/null -w '%{http_code}' http://127.0.0.1:8765/api/hello)"
