#!/usr/bin/env python3
"""작업 인계노트 (퍼스널 OS 기본 백업) — 대화가 압축되기 직전(PreCompact 훅) 지금까지 한 일을 따로 적어 둔다.
압축 뒤 새 세션이 시작되면(SessionStart compact 훅) 인계노트_읽기.py 가 이 노트를 다시 읽혀 일이 이어지게 한다.
저장: .os_데이터/인계노트/인계_YYMMDD_HHMM.md + 최신.md"""
import datetime as dt, json, os, re, sys
H = os.path.expanduser("~/퍼스널OS"); D = os.path.join(H, ".os_데이터", "인계노트"); os.makedirs(D, exist_ok=True)
try: ev = json.load(sys.stdin)
except Exception: ev = {}
tp = ev.get("transcript_path") or ""
asks, answers, files = [], [], []
if tp and os.path.exists(tp):
    for raw in open(tp, encoding="utf-8", errors="ignore"):
        try: d = json.loads(raw)
        except Exception: continue
        m = d.get("message") or {}; c = m.get("content"); role = m.get("role")
        if role == "user":
            t = c if isinstance(c, str) else "\n".join(x.get("text", "") for x in (c or []) if isinstance(x, dict) and x.get("type") == "text")
            t = (t or "").strip()
            if t and not t.startswith("<"):
                if "{{호칭}} 말씀:" in t: t = t.split("{{호칭}} 말씀:")[-1].strip()
                if t.startswith("[Image:"): continue
                t = re.sub(r"=== 부서/.*?=== 부서/[^\n]*끝 ===", "[부서 지침 생략]", t, flags=re.S)
                asks.append(t[-1500:])
        elif role == "assistant" and isinstance(c, list):
            for x in c:
                if x.get("type") == "text" and x.get("text", "").strip(): answers.append(x["text"].strip())
                if x.get("type") == "tool_use":
                    inp = x.get("input") or {}
                    for k in ("file_path", "path"):
                        if isinstance(inp.get(k), str): files.append(inp[k])
def section(path, start, n=60):
    try: s = open(path, encoding="utf-8").read()
    except Exception: return ""
    i = s.find(start); return s[i:i + 6000] if i >= 0 else ""
now = dt.datetime.now()
note = ["# 작업 인계노트 — %s (%s)" % (now.strftime("%Y-%m-%d %H:%M"), ev.get("trigger", "")),
        "대화가 압축되기 직전에 자동으로 남긴 노트. 새 세션은 이것과 업무일지를 읽고 이어서 일한다.", "",
        "## 최근 {{호칭}} 말씀 (오래된 → 최근)"] + ["%d. %s" % (i + 1, re.sub(r"\s+", " ", a)[:500]) for i, a in enumerate(asks[-12:])] + [
        "", "## {{실장}}의 마지막 답 3개"] + ["---\n" + a[:2500] for a in answers[-3:]] + [
        "", "## 최근 손댄 파일"] + ["- " + f for f in list(dict.fromkeys(reversed(files)))[:25]] + [
        "", "## 업무일지 — 진행 중인 일 (앞부분)", section(os.path.join(H, "부서", "00_비서실", "업무일지.md"), "## 진행 중인 일")[:4000]]
txt = "\n".join(note)
open(os.path.join(D, "인계_%s.md" % now.strftime("%y%m%d_%H%M")), "w", encoding="utf-8").write(txt)
open(os.path.join(D, "최신.md"), "w", encoding="utf-8").write(txt)
