#!/usr/bin/env python3
"""매일 새벽 깃허브 백업 (퍼스널 OS 기본 백업) — {{실장}}·감사실장를 각각 다른 비공개 저장소에 (안 섞이게)
  personal-os-backup : 퍼스널OS 글·설정·데이터·스크립트 + 작은 문서(2MB 이하) + 옵시디언 금고 {{실장}} 폴더(대화 원본·기억)
  personal-os-audit-backup  : ~/감사실(키 제외) + 금고 감사실장 폴더
- 비밀키·토큰·비밀번호 파일은 절대 올리지 않는다(아래 SECRET). 저장소는 반드시 비공개인지 매번 확인 후 올린다.
- 사진·영상·큰 PPT·PDF(2MB 초과)는 깃허브 용량 한계로 올리지 않고 목록(큰파일_목록.md)만 남긴다.
- 매일 04:00 launchd(com.personalos.gitbackup). 로그 .os_데이터/깃백업.log"""
import datetime as dt, json, os, re, shutil, subprocess, sys, urllib.request, urllib.error
HOME = os.path.expanduser("~"); BON = os.path.join(HOME, "퍼스널OS"); DATA = os.path.join(BON, ".os_데이터")
STAGE = os.path.join(HOME, ".백업깃")
try:
    TOK = json.load(open(os.path.join(DATA, "깃허브.json")))
except Exception:
    print("깃허브 연결 전 — 건너뜀 (매니저에게 '깃허브 백업 연결해 줘')"); raise SystemExit(0)
TOKEN = TOK["token"]
USER = TOK.get("계정") or json.load(urllib.request.urlopen(urllib.request.Request("https://api.github.com/user", headers={"Authorization": "token " + TOKEN})))["login"]
EXD = re.compile(r"^(크롬_.*|미리보기|node_modules|\.git|__pycache__|출력|\.venv|\.Trash)$")
TXT = re.compile(r"\.(md|txt|json|py|sh|html|css|js|csv|gs|swift|plist|svg|command|ts|sql|ya?ml|toml|ini|jsonl)$", re.I)
DOC = re.compile(r"\.(pdf|xlsx|docx|hwp|hwpx|pptx|key|numbers|png|jpe?g)$", re.I)
SECRET = re.compile(r"(키|토큰|token|secret|password|비밀|credential|나노바나나|깃허브|폼공장|웹푸시|네이버캘린더|수파베이스|노션API|\.env$|id_rsa|\.pem$|\.p12$)", re.I)
LOG = os.path.join(DATA, "깃백업.log")

def log(m):
    open(LOG, "a", encoding="utf-8").write("%s %s\n" % (dt.datetime.now().strftime("%Y-%m-%d %H:%M"), m)); print(m)

def ensure_repo(repo):
    try:
        urllib.request.urlopen(urllib.request.Request("https://api.github.com/repos/%s/%s" % (USER, repo), headers={"Authorization": "token " + TOKEN}))
    except urllib.error.HTTPError:
        urllib.request.urlopen(urllib.request.Request("https://api.github.com/user/repos", json.dumps({"name": repo, "private": True}).encode(), {"Authorization": "token " + TOKEN, "Content-Type": "application/json"}, method="POST"))

def is_private(repo):
    ensure_repo(repo)
    r = json.load(urllib.request.urlopen(urllib.request.Request("https://api.github.com/repos/%s/%s" % (USER, repo), headers={"Authorization": "token " + TOKEN})))
    return r.get("private") is True

# .os_데이터 는 계정·비밀번호 파일이 많아 '허용 목록'만 올린다 (2026-10-19 — 이름 규칙만으로 거르다 로그인 정보가 섞여 올라간 사고 뒤)
DATA_OK_DIRS = {"threads", "uploads", "인계노트"}
DATA_OK_FILES = {"할일.json", "메모판.json", "캘린더_캐시.json", "노션백업_기록.json", "알림기록.json", "할일_캘린더연동.json", "네이버예약_연동.json", "상담신청_확인.json"}
CRED_KEY = re.compile(r'"(password|passwd|pw|비밀번호|token|access_token|refresh_token|secret|api_key|apikey|key|client_secret|app_password|cookie)"\s*:', re.I)
CRED_VAL = re.compile(r"ghp_[A-Za-z0-9]{20}|github_pat_|AIza[0-9A-Za-z_-]{30}|sk-ant-|sk-[A-Za-z0-9]{30}|BEGIN [A-Z ]*PRIVATE KEY|xox[bp]-")

def data_allowed(rel):
    parts = rel.split(os.sep)
    if ".os_데이터" not in parts: return True
    i = parts.index(".os_데이터"); rest = parts[i + 1:]
    if not rest: return False
    if len(rest) == 1: return rest[0] in DATA_OK_FILES or rest[0].endswith(".log")
    return rest[0] in DATA_OK_DIRS

def has_cred(p, f):
    if not re.search(r"\.(json|js|py|sh|txt|md|env|ini|toml|ya?ml|csv|command|plist)$", f, re.I): return False
    try: t = open(p, encoding="utf-8", errors="ignore").read()
    except OSError: return False
    return bool(CRED_VAL.search(t) or (f.lower().endswith(".json") and CRED_KEY.search(t)))

def copy_tree(src, dst, big, rel0=""):
    for root, ds, fs in os.walk(src):
        ds[:] = [d for d in ds if not EXD.match(d)]
        for f in fs:
            p = os.path.join(root, f); rel = os.path.join(rel0, os.path.relpath(p, src))
            if SECRET.search(f) or not data_allowed(rel) or has_cred(p, f): continue
            try: s = os.path.getsize(p)
            except OSError: continue
            ok = (TXT.search(f) and s <= 20e6) or (DOC.search(f) and s <= (5e5 if re.search(r"\.(png|jpe?g)$", f, re.I) else 2e6))
            if not ok:
                if s > 2e6: big.append((s, rel))
                continue
            q = os.path.join(dst, rel); os.makedirs(os.path.dirname(q), exist_ok=True)
            try:
                if not (os.path.exists(q) and os.path.getsize(q) == s and os.path.getmtime(q) >= os.path.getmtime(p)): shutil.copy2(p, q)
            except OSError: pass

def sync(repo, sources):
    w = os.path.join(STAGE, repo)
    if not is_private(repo): log("⛔ %s 가 비공개가 아니라 올리지 않음" % repo); return False
    os.makedirs(w, exist_ok=True)
    git = lambda *a: subprocess.run(["git", "-C", w] + list(a), capture_output=True, text=True)
    if not os.path.isdir(os.path.join(w, ".git")):
        git("init", "-b", "main"); git("config", "user.name", "personal-os-backup"); git("config", "user.email", "backup@local"); git("config", "http.postBuffer", "524288000")
    git("remote", "remove", "origin"); git("remote", "add", "origin", "https://%s:%s@github.com/%s/%s.git" % (USER, TOKEN, USER, repo))
    # 지운 파일도 반영되게: .git 만 두고 비운 뒤 다시 채운다
    for x in os.listdir(w):
        if x != ".git": (shutil.rmtree if os.path.isdir(os.path.join(w, x)) else os.remove)(os.path.join(w, x))
    big = []
    for src, rel in sources:
        if os.path.isdir(src): copy_tree(src, w, big, rel)
    open(os.path.join(w, "큰파일_목록.md"), "w", encoding="utf-8").write("# 깃허브에 안 올린 큰 파일 (%s)\n용량 한계로 제외. 원본은 아이맥에 있음.\n\n" % dt.date.today() + "\n".join("- %.1fMB `%s`" % (s / 1e6, r) for s, r in sorted(big, reverse=True)))
    open(os.path.join(w, "README.md"), "w", encoding="utf-8").write("# %s\n자동 백업 (비공개). 매일 04:00. 비밀키·토큰 파일은 포함하지 않음.\n" % repo)
    git("add", "-A")
    c = git("commit", "-q", "-m", "백업 %s" % dt.datetime.now().strftime("%Y-%m-%d %H:%M"))
    p = git("push", "-q", "-u", *(["--force"] if os.environ.get("BACKUP_FORCE") else []), "origin", "main")
    if p.returncode: log("⚠️ %s 올리기 실패: %s" % (repo, p.stderr[-300:].replace(TOKEN, "***"))); return False
    log("✅ %s 올림 (%s)" % (repo, "변경 없음" if "nothing to commit" in c.stdout + c.stderr else "새 백업")); return True

if __name__ == "__main__":
    a = sync("personal-os-backup", [(BON, "퍼스널OS"), (os.path.join(HOME, "퍼스널OS_금고", "매니저"), "금고_매니저"), (os.path.join(HOME, "퍼스널OS_금고", "노션"), "금고_노션")])
    b = True if not os.path.isdir(os.path.join(HOME, "감사실")) else sync("personal-os-audit-backup", [(os.path.join(HOME, "감사실"), "감사실"), (os.path.join(HOME, "퍼스널OS_금고", "감사실장"), "금고_감사실장")])
    if not (a and b):
        subprocess.run([os.path.join(BON, "부서", "00_비서실", "알림.sh"), "-t", "깃허브 백업 실패", "{{실장}} 깃백업.log 확인 필요"])
