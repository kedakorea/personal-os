#!/bin/bash
# 미니달력용 구글 캘린더 캐시 갱신 — 출근 시간대 하루 3번
cd ~/퍼스널OS
LOG=~/퍼스널OS/.os_데이터/캘린더_캐시.log
{ echo "=== $(date '+%F %T')"; perl -e 'alarm 600; exec @ARGV' ~/.local/bin/claude -p "$(cat 부서/00_비서실/자동/캘린더_캐시_지시.md)" --dangerously-skip-permissions 2>&1 | tail -5; } >> "$LOG"
