#!/bin/bash
# 테일스케일이 꺼져 있으면 켜고, 휴대폰 접속 주소(보안주소)를 되살린다. 로그인할 때 + 10분마다.
TS=/Applications/Tailscale.app/Contents/MacOS/Tailscale
LOG="$HOME/퍼스널OS/.os_데이터/테일스케일_복구.log"
say() { echo "$(date '+%F %T') $*" >> "$LOG"; }
[ -x "$TS" ] || exit 0
if ! "$TS" status >/dev/null 2>&1; then
  say "테일스케일 꺼져 있음 — 켬"; open -a Tailscale 2>/dev/null; sleep 8; "$TS" up >/dev/null 2>&1; sleep 3
fi
URL="{{보안주소}}"
[ -z "$URL" ] && exit 0
CODE=$(curl -s -m 8 -o /dev/null -w "%{http_code}" "$URL/api/hello" 2>/dev/null)
if [ "$CODE" != "200" ]; then
  say "보안주소 응답 $CODE — 다시 걸기"
  "$TS" serve --bg --https=443 http://127.0.0.1:8765 >/dev/null 2>&1; sleep 4
  say "복구 뒤 응답 $(curl -s -m 8 -o /dev/null -w '%{http_code}' "$URL/api/hello")"
fi
