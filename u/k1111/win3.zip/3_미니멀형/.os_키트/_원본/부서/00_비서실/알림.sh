#!/bin/bash
# {{실장}} 알림 — {{호칭}} 휴대폰 홈 화면의 {{앱이름}} 앱으로 알림을 보낸다.
# 사용법: 알림.sh "내용"  /  알림.sh -t "제목" "내용"
TITLE="{{앱이름}}"
if [ "$1" = "-t" ]; then TITLE="$2"; shift 2; fi
MSG="$*"
[ -z "$MSG" ] && { echo "보낼 내용이 없습니다"; exit 2; }
R=$(/usr/bin/python3 - "$TITLE" "$MSG" <<'PY'
import json, sys, urllib.request
body = json.dumps({"title": sys.argv[1], "body": sys.argv[2]}).encode()
req = urllib.request.Request("http://127.0.0.1:8765/api/push/send", body, {"Content-Type": "application/json"})
try:
    print(urllib.request.urlopen(req, timeout=20).read().decode())
except Exception as e:
    print("ERR %s" % e)
PY
)
echo "$R" | grep -q '"보냄": *[1-9]' && echo "보냄" || echo "미전송 — $R"
