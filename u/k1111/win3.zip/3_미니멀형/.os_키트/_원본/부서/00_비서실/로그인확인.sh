#!/bin/bash
# 클로드 로그인({{실장}} 두뇌)이 살아 있는지 확인한다. 풀렸으면 {{호칭}} 아이폰으로 알린다.
# 2026-10-14 {{호칭}} 지시 — 앱이 멈춘 뒤에 발견하지 말고 미리 알 수 있게.
# 3시간마다 돈다. 같은 알림은 6시간에 한 번만 보낸다.
# 토큰 값은 절대 로그나 화면에 적지 않는다.

DATA="$HOME/퍼스널OS/.os_데이터"
LOG="$DATA/로그인확인.log"
STATE="$DATA/로그인확인_상태.txt"
ALARM="$HOME/퍼스널OS/부서/00_비서실/알림.sh"
say() { echo "$(date '+%F %T') $*" >> "$LOG"; }

# 6시간 안에 이미 알렸으면 또 알리지 않는다
recently_told() {
  [ -f "$STATE" ] || return 1
  local last now
  last=$(cat "$STATE" 2>/dev/null)
  now=$(date +%s)
  [ -n "$last" ] && [ $((now - last)) -lt 21600 ]
}
mark_told() { date +%s > "$STATE"; }

CRED=$(security find-generic-password -s "Claude Code-credentials" -w 2>/dev/null)
if [ -z "$CRED" ]; then
  say "로그인 정보 자체가 없음"
  recently_told || { "$ALARM" -t "{{실장}} 로그인 풀림" "터미널에서 claude → /login 해주세요. 지금은 {{실장}}이(가) 답할 수 없습니다."; mark_told; }
  exit 0
fi

# 남은 시간(분)과 토큰을 따로 꺼낸다 (토큰은 변수로만 쓰고 기록하지 않는다)
LEFT=$(printf '%s' "$CRED" | python3 -c "
import sys, json, time
try:
    o = json.load(sys.stdin); o = o.get('claudeAiOauth', o)
    print(int((o.get('expiresAt', 0)/1000 - time.time())//60))
except Exception:
    print(-999)
")
TOKEN=$(printf '%s' "$CRED" | python3 -c "
import sys, json
try:
    o = json.load(sys.stdin); o = o.get('claudeAiOauth', o)
    print(o.get('accessToken',''))
except Exception:
    print('')
")

CODE=$(curl -s -m 15 -o /dev/null -w "%{http_code}" \
  -H "Authorization: Bearer $TOKEN" \
  -H "anthropic-beta: oauth-2025-04-20" \
  https://api.anthropic.com/api/oauth/usage 2>/dev/null)

say "남은시간 ${LEFT}분 · 응답 $CODE"

# 8시간짜리 토큰이 그냥 시간이 지나 끝난 것뿐이면, 클로드를 한 번 깨워 스스로 갱신하게 한다.
# (2026-10-16 오경보: 저녁에 안 쓰는 동안 토큰이 끝나 401 → 실제로는 다음 말씀에 자동 갱신됨)
if { [ "$CODE" = "401" ] || [ "$CODE" = "403" ]; } && [ "$LEFT" -le 0 ]; then
  "$HOME/.local/bin/claude" -p "ok" --max-turns 1 >/dev/null 2>&1
  CRED=$(security find-generic-password -s "Claude Code-credentials" -w 2>/dev/null)
  TOKEN=$(printf '%s' "$CRED" | python3 -c "
import sys, json
try:
    o = json.load(sys.stdin); o = o.get('claudeAiOauth', o)
    print(o.get('accessToken',''))
except Exception:
    print('')
")
  CODE=$(curl -s -m 15 -o /dev/null -w "%{http_code}" \
    -H "Authorization: Bearer $TOKEN" \
    -H "anthropic-beta: oauth-2025-04-20" \
    https://api.anthropic.com/api/oauth/usage 2>/dev/null)
  say "토큰 시간 끝 → 갱신 시도 후 응답 $CODE"
fi

case "$CODE" in
  200)
    rm -f "$STATE" 2>/dev/null      # 정상으로 돌아오면 알림 기록을 지운다
    ;;
  401|403)
    say "로그인 풀림(응답 $CODE)"
    recently_told || { "$ALARM" -t "{{실장}} 로그인 풀림" "{{실장}}이(가) 답하지 못하는 상태입니다. 컴퓨터 터미널에서 claude → /login 해주세요."; mark_told; }
    ;;
  000)
    say "인터넷이 안 되거나 응답 없음 — 다음 차례에 다시 본다"
    ;;
  *)
    say "예상 못한 응답 $CODE"
    ;;
esac
