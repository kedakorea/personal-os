#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""☀️ 아침 브리핑 — {{실장}}이 먼저 말을 건다 (2026-10-24)
근무 시작 시각(설정.json '근무시간', 예: 평일 09:30~18:30)에 맞춰 하루 한 번:
업무일지·할일·캘린더를 보고 오늘 브리핑을 만들어 앱에 '☀️ 아침 브리핑' 대화로 넣고 휴대폰으로 알린다.
그 대화에 답장하면 {{실장}}이 브리핑 내용을 기억한 채 이어서 일한다(같은 세션).
자동 실행이 10분마다 부르고, 이 파일이 '오늘 이미 했는지·시간이 됐는지·평일인지'를 판단한다."""
import datetime, json, os, re, shutil, subprocess, sys, time, uuid

OS_DIR = os.environ.get("PERSONALOS_DIR") or os.path.join(os.path.expanduser("~"), "퍼스널OS")   # 시험할 때만 다른 폴더
DATA = os.path.join(OS_DIR, ".os_데이터")
ST = os.path.join(DATA, "아침브리핑.json")
LOG = os.path.join(DATA, "아침브리핑.log")


def log(m):
    open(LOG, "a", encoding="utf-8").write("%s %s\n" % (datetime.datetime.now().strftime("%m-%d %H:%M"), m))


def claude_bin():
    for p in (shutil.which("claude"), os.path.expanduser("~/.local/bin/claude"), os.path.expanduser("~/.local/bin/claude.exe"),
              "/usr/local/bin/claude", "/opt/homebrew/bin/claude"):
        if p and os.path.exists(p):
            return p
    return "claude"


def main():
    force = "--지금" in sys.argv or "--now" in sys.argv
    c = json.load(open(os.path.join(OS_DIR, "설정.json"), encoding="utf-8"))
    if c.get("아침브리핑") is False:
        return
    hours = c.get("근무시간", "평일 09:30~18:30")
    m = re.search(r"(\d{1,2}):(\d{2})", hours)
    start = datetime.time(int(m.group(1)), int(m.group(2))) if m else datetime.time(9, 30)
    now = datetime.datetime.now()
    st = json.load(open(ST, encoding="utf-8")) if os.path.exists(ST) else {}
    today = now.strftime("%Y-%m-%d")
    if not force:
        if st.get("마지막") == today:
            return
        if "평일" in hours and now.weekday() >= 5:
            return
        if now.time() < start or now.hour >= 14:          # 근무 시작 ~ 오후 2시 사이에만(늦게 켜면 켤 때 한 번)
            return
    sid = str(uuid.uuid4())
    prompt = ("브리핑. 아침 인사로 먼저 말을 거는 거야. 업무일지·할일 목록·오늘과 이번 주 일정을 보고 "
              "① 오늘 할 일·마감 ② 밀린 일 ③ 이번 주 다가오는 일정 ④ 결정해 주셔야 할 것을 짧게 정리해. "
              "맨 끝은 '어떤 일부터 할까요?'로 끝내. 파일을 고치거나 메일을 보내지는 마.")
    t0 = time.time()
    try:
        r = subprocess.run([claude_bin(), "-p", prompt, "--session-id", sid, "--dangerously-skip-permissions"],
                           cwd=OS_DIR, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=600)
        text = (r.stdout or "").strip()
    except Exception as e:
        text = ""
        log("실패 %s" % e)
    if not text:
        log("브리핑을 만들지 못함 (로그인 확인 필요)"); return
    th = os.path.join(DATA, "threads")
    os.makedirs(th, exist_ok=True)
    ts = time.time()
    t = {"id": str(uuid.uuid4()), "session_id": sid, "started": True, "title": "☀️ 아침 브리핑 %s" % now.strftime("%m/%d"),
         "created": ts, "updated": ts, "messages": [{"role": "elvin", "text": text, "dept": "00 비서실", "ts": ts}]}
    json.dump(t, open(os.path.join(th, t["id"] + ".json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    first = re.sub(r"[#*`>|]", "", text).strip().split("\n")
    body = next((l.strip() for l in first if len(l.strip()) > 8), "오늘 브리핑이 도착했어요")[:110]
    try:
        if os.environ.get("PERSONALOS_NOPUSH"):
            raise RuntimeError("시험 — 알림 생략")
        import urllib.request
        req = urllib.request.Request("http://127.0.0.1:8765/api/push/send",
                                     json.dumps({"title": "☀️ 아침 브리핑", "body": body}).encode(), {"Content-Type": "application/json"})
        urllib.request.urlopen(req, timeout=20)
    except Exception as e:
        log("알림 실패 %s" % e)
    st["마지막"] = today
    json.dump(st, open(ST, "w", encoding="utf-8"), ensure_ascii=False)
    log("보냄 (%.0f초) %s" % (time.time() - t0, body))


if __name__ == "__main__":
    main()
