#!/bin/bash
# 옵시디언 설치 + 금고(~/퍼스널OS_금고) 등록 — 매니저가 "옵시디언 깔아 줘" 때 돌린다 (관리자 비밀번호 필요 없음)
set -e
V="$HOME/퍼스널OS_금고"; mkdir -p "$V/.obsidian" "$V/매니저" "$V/노션"
if [ ! -d /Applications/Obsidian.app ]; then
  URL=$(/usr/bin/python3 -c "import json,urllib.request;r=json.load(urllib.request.urlopen('https://api.github.com/repos/obsidianmd/obsidian-releases/releases/latest'));print([a['browser_download_url'] for a in r['assets'] if a['name'].endswith('.dmg') and 'arm' not in a['name'].lower()][0])")
  T=$(mktemp -d); curl -sL -o "$T/o.dmg" "$URL"; hdiutil attach -nobrowse -quiet "$T/o.dmg" -mountpoint "$T/m"
  cp -R "$T/m/Obsidian.app" /Applications/ || cp -R "$T/m/Obsidian.app" "$HOME/Applications/"; hdiutil detach -quiet "$T/m"; rm -rf "$T"
fi
/usr/bin/python3 - <<'P'
import json,os,time,uuid
d=os.path.expanduser('~/Library/Application Support/obsidian'); os.makedirs(d,exist_ok=True); p=os.path.join(d,'obsidian.json')
try: c=json.load(open(p))
except Exception: c={}
v=os.path.expanduser('~/퍼스널OS_금고'); c.setdefault('vaults',{})
if not any(x.get('path')==v for x in c['vaults'].values()): c['vaults'][uuid.uuid4().hex[:16]]={'path':v,'ts':int(time.time()*1000),'open':True}
json.dump(c,open(p,'w'))
P
/bin/bash "$HOME/퍼스널OS/부서/00_비서실/백업/금고백업.sh" >/dev/null 2>&1 || true
echo "옵시디언 준비 완료 — 금고: $V"
