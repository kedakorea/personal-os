#!/usr/bin/env python3
"""노션 → 옵시디언 (2026-10-19 {{호칭}}: 노션 내용이 없어지면 안 됨)
노션 공식 API(내부 통합 토큰)로 'keda 데이터 도서관' 아래 모든 페이지·데이터베이스를 마크다운으로 받아 ~/퍼스널OS_금고/노션/ 에 쌓는다.
노션에 올린 파일(노션 저장 파일)도 함께 내려받는다. 바뀐 페이지만 다시 받는다(기록 .os_데이터/노션옵시디언.json).
토큰: .os_데이터/노션API.json {"token": "ntn_…", "root": "<도서관 페이지 id>"} — {{호칭}}이 통합을 만들어 도서관에 연결해 주셔야 한다.
매일 23:40 launchd(com.personalos.vaultbackup) 에서 대화원본.py 와 함께 돈다."""
import datetime as dt, json, os, re, time, urllib.request, urllib.error
HOME = os.path.expanduser("~"); DATA = os.path.join(HOME, "퍼스널OS", ".os_데이터")
OUT = os.path.join(HOME, "퍼스널OS_금고", "노션"); REC = os.path.join(DATA, "노션옵시디언.json"); LOG = os.path.join(DATA, "금고백업.log")
CONF = os.path.join(DATA, "노션API.json")

def log(m): open(LOG, "a", encoding="utf-8").write("%s 노션→옵시디언 %s\n" % (dt.datetime.now().strftime("%Y-%m-%d %H:%M"), m)); print(m)

if not os.path.exists(CONF):
    log("토큰 없음 — {{호칭}}이 노션 통합 연결 후 시작"); raise SystemExit(0)
C = json.load(open(CONF)); TOKEN = C["token"]; ROOT = C.get("root", "all")
try: REC_D = json.load(open(REC))
except Exception: REC_D = {}

def api(path, body=None, method=None):
    for i in range(10):
        time.sleep(0.4)   # 노션 API 한도: 초당 약 3번
        req = urllib.request.Request("https://api.notion.com/v1/" + path, json.dumps(body).encode() if body is not None else None,
                                     {"Authorization": "Bearer " + TOKEN, "Notion-Version": "2022-06-28", "Content-Type": "application/json"}, method=method or ("POST" if body is not None else "GET"))
        try: return json.load(urllib.request.urlopen(req, timeout=60))
        except urllib.error.HTTPError as e:
            if e.code == 429: time.sleep(float(e.headers.get("Retry-After") or 0) or (3 + i * 3)); continue
            if e.code >= 500: time.sleep(3 + i * 2); continue
            raise
    raise RuntimeError("429 반복")

def children(bid):
    out, cur = [], None
    while True:
        r = api("blocks/%s/children?page_size=100%s" % (bid, "&start_cursor=" + cur if cur else ""))
        out += r["results"]
        if not r.get("has_more"): return out
        cur = r["next_cursor"]

def rt(arr):
    s = ""
    for t in arr or []:
        x = t.get("plain_text", ""); a = t.get("annotations", {})
        if t.get("href"): x = "[%s](%s)" % (x, t["href"])
        if a.get("code"): x = "`%s`" % x
        if a.get("bold"): x = "**%s**" % x
        if a.get("italic"): x = "*%s*" % x
        if a.get("strikethrough"): x = "~~%s~~" % x
        s += x
    return s

def safe(s): return re.sub(r'[\\/:*?"<>|\n]+', " ", s or "제목없음").strip()[:60] or "제목없음"

def dl(url, folder, name):
    os.makedirs(folder, exist_ok=True); p = os.path.join(folder, safe(name))
    if not os.path.exists(p):
        try: open(p, "wb").write(urllib.request.urlopen(url, timeout=120).read())
        except Exception as e: return None
    return os.path.relpath(p, OUT)

def blocks_md(bid, folder, depth=0):
    lines = []; ind = "  " * depth
    for b in children(bid):
        t = b["type"]; v = b.get(t, {})
        if t == "child_page":
            sub = page(b["id"], folder, v.get("title")); lines.append(ind + "- 📄 [[%s]]" % sub); continue
        if t == "child_database":
            sub = database(b["id"], folder, v.get("title")); lines.append(ind + "- 🗂 [[%s]]" % sub); continue
        txt = rt(v.get("rich_text"))
        if t.startswith("heading_"): lines.append("#" * int(t[-1]) + " " + txt)
        elif t == "paragraph": lines.append(ind + txt)
        elif t == "bulleted_list_item": lines.append(ind + "- " + txt)
        elif t == "numbered_list_item": lines.append(ind + "1. " + txt)
        elif t == "to_do": lines.append(ind + "- [%s] %s" % ("x" if v.get("checked") else " ", txt))
        elif t == "quote": lines.append("> " + txt)
        elif t == "callout": lines.append("> %s %s" % ((v.get("icon") or {}).get("emoji", "💡"), txt))
        elif t == "code": lines.append("```%s\n%s\n```" % (v.get("language", ""), rt(v.get("rich_text"))))
        elif t == "divider": lines.append("---")
        elif t == "toggle": lines.append(ind + "- ▸ " + txt)
        elif t in ("image", "file", "pdf", "video", "audio"):
            src = v.get("file", {}).get("url") or v.get("external", {}).get("url"); nm = v.get("name") or (src or "").split("?")[0].split("/")[-1]
            if v.get("type") == "file" and src:
                rel = dl(src, os.path.join(folder, "_첨부"), nm); lines.append(ind + ("![[%s]]" % os.path.basename(rel) if rel else "(첨부 받기 실패: %s)" % nm))
            elif src: lines.append(ind + "[%s](%s)" % (nm, src))
        elif t == "bookmark" or t == "link_preview" or t == "embed": lines.append(ind + "<%s>" % v.get("url", ""))
        elif t == "table_row": lines.append("| " + " | ".join(rt(c) for c in v.get("cells", [])) + " |")
        elif t == "equation": lines.append("$$%s$$" % v.get("expression", ""))
        if b.get("has_children") and t not in ("child_page", "child_database"):
            lines += blocks_md(b["id"], folder, depth + 1)
    return lines

def page(pid, folder, title=None):
    p = api("pages/" + pid)
    if not title:
        for v in p.get("properties", {}).values():
            if v.get("type") == "title": title = rt(v.get("title"))
    name = safe(title); path = os.path.join(folder, name + ".md"); sub = os.path.join(folder, name)
    if REC_D.get(pid) != p["last_edited_time"] or not os.path.exists(path):
        os.makedirs(folder, exist_ok=True)
        body = blocks_md(pid, sub)
        open(path, "w", encoding="utf-8").write("---\nnotion_id: %s\nlast_edited: %s\nurl: %s\n---\n# %s\n\n%s\n" % (pid, p["last_edited_time"], p.get("url", ""), title or name, "\n".join(body)))
        REC_D[pid] = p["last_edited_time"]; STAT["pages"] += 1
    else:
        # 하위 페이지가 바뀌었을 수 있어 아래만 훑는다
        for b in children(pid):
            if b["type"] == "child_page": page(b["id"], sub, b["child_page"].get("title"))
            elif b["type"] == "child_database": database(b["id"], sub, b["child_database"].get("title"))
    return os.path.relpath(path, OUT)[:-3]

def database(did, folder, title):
    name = safe(title); sub = os.path.join(folder, name); cur = None
    while True:
        r = api("databases/%s/query" % did, {"page_size": 100, **({"start_cursor": cur} if cur else {})})
        for row in r["results"]: page(row["id"], sub)
        if not r.get("has_more"): break
        cur = r["next_cursor"]
    return name

STAT = {"pages": 0}
if __name__ == "__main__":
    try:
        if ROOT in ("", "all"):
            # 연결이 볼 수 있는 노션 전체 — 맨 위 페이지·데이터베이스부터 차례로 (2026-10-19: 노션 전체를 지킨다)
            cur, tops = None, []
            while True:
                r = api("search", {"page_size": 100, **({"start_cursor": cur} if cur else {})})
                tops += [x for x in r["results"] if (x.get("parent") or {}).get("type") in ("workspace", "teamspace_id", "teamspace")]
                if not r.get("has_more"): break
                cur = r["next_cursor"]
            for x in tops:
                if x["object"] == "page": page(x["id"], OUT)
                else: database(x["id"], OUT, rt(x.get("title")))
        else:
            page(ROOT, OUT)
        json.dump(REC_D, open(REC, "w"))
        log("완료 — 새로 받은 페이지 %d" % STAT["pages"])
    except Exception as e:
        json.dump(REC_D, open(REC, "w")); log("오류 %s" % e)
