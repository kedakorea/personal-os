#!/usr/bin/env python3
"""업로드 전용 크롬 — 인스타·유튜브·네이버 블로그에 올릴 때만 쓰는 크롬 창 (2026-11-07, 본사 브랜디움크롬.py 를 고객 키트용으로)
평소 쓰는 크롬과 섞이지 않게 따로 띄운다: 프로필 ~/퍼스널OS/.os_데이터/크롬_업로드, 조작 포트 9336.
처음 한 번 고객이 이 창에서 각 채널에 직접 로그인하면 이후로는 로그인이 유지된다(비밀번호는 매니저가 받지 않는다).
  python3 업로드크롬.py start            — 띄우기
  python3 업로드크롬.py login            — 인스타·유튜브·네이버 로그인 탭을 열어 둔다(설치 날 한 번)
  python3 업로드크롬.py stop             — 닫기
"""
import json, os, platform, subprocess, sys, time, urllib.request

PORT = 9336
DIR = os.path.expanduser("~/퍼스널OS/.os_데이터/크롬_업로드")
CHROME = ("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" if platform.system() == "Darwin"
          else os.path.expandvars(r"%ProgramFiles%\Google\Chrome\Application\chrome.exe"))


def up():
    try: return json.load(urllib.request.urlopen("http://127.0.0.1:%d/json/version" % PORT, timeout=2))
    except Exception: return None


def start():
    if up(): return
    os.makedirs(DIR, exist_ok=True)
    subprocess.Popen([CHROME, "--user-data-dir=" + DIR, "--remote-debugging-port=%d" % PORT, "--no-first-run", "--no-default-browser-check",
                      "--hide-crash-restore-bubble", "--window-size=1300,950",
                      "--disable-background-timer-throttling", "--disable-renderer-backgrounding", "--disable-backgrounding-occluded-windows", "about:blank"],
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    for _ in range(40):
        time.sleep(0.5)
        if up(): return
    raise SystemExit("업로드 크롬이 안 뜸")


def new_tab(url):
    start()
    return json.load(urllib.request.urlopen(urllib.request.Request("http://127.0.0.1:%d/json/new?%s" % (PORT, url), method="PUT")))


class Tab:
    """탭 하나를 잡고 자바스크립트를 돌린다(match 가 주소에 들어 있는 탭, 없으면 새 탭)"""
    def __init__(self, match, url):
        import websocket
        start()
        pages = [t for t in json.load(urllib.request.urlopen("http://127.0.0.1:%d/json/list" % PORT)) if t["type"] == "page"]
        t = next((t for t in pages if match in t["url"]), None) or new_tab(url)
        self.ws = websocket.create_connection(t["webSocketDebuggerUrl"], suppress_origin=True, timeout=300)
        self.n = 0
        self.call("Page.bringToFront"); self.call("Emulation.setFocusEmulationEnabled", enabled=True)
        if match not in t["url"]: self.go(url)

    def call(self, m, **p):
        self.n += 1; me = self.n
        self.ws.send(json.dumps({"id": me, "method": m, "params": p}))
        while True:
            r = json.loads(self.ws.recv())
            if r.get("id") == me: return r.get("result", {})

    def js(self, code, wait=0):
        r = self.call("Runtime.evaluate", expression=code, returnByValue=True, awaitPromise=True, userGesture=True)
        if wait: time.sleep(wait)
        v = r.get("result", {}).get("value")
        return "" if v is None else str(v)

    def go(self, url, wait=9):
        self.call("Page.navigate", url=url); time.sleep(wait)

    def url(self):
        return self.js("location.href")


if __name__ == "__main__":
    a = sys.argv[1] if len(sys.argv) > 1 else "start"
    if a == "start": start(); print("떠 있음")
    elif a == "login":
        for u in ["https://www.instagram.com/accounts/login/", "https://accounts.google.com/ServiceLogin?service=youtube&continue=https://studio.youtube.com/",
                  "https://nid.naver.com/nidlogin.login?url=https://blog.naver.com/MyBlog.naver"]:
            new_tab(u)
        print("로그인 탭 3개를 열었습니다 — 고르신 채널만 로그인하시면 됩니다")
    elif a == "stop":
        v = up()
        if v:
            import websocket
            ws = websocket.create_connection(v["webSocketDebuggerUrl"], suppress_origin=True); ws.send(json.dumps({"id": 1, "method": "Browser.close"})); time.sleep(2)
        print("닫음")
