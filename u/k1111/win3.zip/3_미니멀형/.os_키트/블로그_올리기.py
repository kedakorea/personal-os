#!/usr/bin/env python3
"""네이버 블로그에 바로 올리기 — 업로드 전용 크롬(업로드크롬.py) 안에서 스마트에디터를 직접 조작 (2026-11-07)
네이버 API·승인 없이 된다.
사용: python3 블로그_올리기.py <결과 폴더> [--임시저장]
  폴더의 01.jpg… 카드 + 캡션.txt(첫 줄 = 제목 후보, #해시태그 = 태그) + 설치기념_01.mp4(있으면 영상도)
  블로그 주소(아이디)는 로그인된 계정에서 알아낸다. 카테고리는 기본(전체)로.
  --임시저장: 발행하지 않고 임시저장까지만. 시험·실습 때는 고객에게 "임시저장할까요, 바로 발행할까요?" 물어 고른 대로.
처음 한 번: 업로드 크롬에서 네이버 로그인(사람이 한 단계).
"""
import base64, glob, html, json, os, re, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import 업로드크롬 as UC

D = os.path.abspath(sys.argv[1]); DRAFT = "--임시저장" in sys.argv
cards = sorted(glob.glob(os.path.join(glob.escape(D), "[0-9][0-9].jpg")))
cap = open(os.path.join(D, "캡션.txt"), encoding="utf-8").read().strip() if os.path.exists(os.path.join(D, "캡션.txt")) else ""
vid = (glob.glob(os.path.join(glob.escape(D), "*_01.mp4")) or [None])[0]
tf = os.path.join(D, "블로그_제목.txt")
TITLE = open(tf, encoding="utf-8").read().strip() if os.path.exists(tf) else "오늘, 내 컴퓨터에 회사가 생겼어요"
TAGS = [t.lstrip("#") for t in re.findall(r"#\S+", cap)][:10]
BODY = re.sub(r"\s*#\S+", "", cap).strip()

# 앞서 쓰던 블로그 탭(글쓰기 화면 등)은 멈춰 있을 수 있어 닫고 새 탭으로 연다(2026-11-08 맥북 시험에서 탭이 응답 없음)
import urllib.request as _u
UC.start()
for _t in json.load(_u.urlopen("http://127.0.0.1:%d/json/list" % UC.PORT)):
    if "blog.naver.com" in _t.get("url", ""):
        try: _u.urlopen("http://127.0.0.1:%d/json/close/%s" % (UC.PORT, _t["id"]))
        except Exception: pass
T = UC.Tab("blog.naver.com", "https://blog.naver.com/MyBlog.naver")
T.go("https://blog.naver.com/MyBlog.naver", 8)
u = T.url()
if "nid.naver.com" in u:
    sys.exit("네이버 로그인이 안 돼 있어요 — 업로드 크롬에서 한 번 로그인해 주세요")
m = re.search(r"blog\.naver\.com/([A-Za-z0-9_\-]+)", u)
BID = m.group(1) if m and m.group(1) not in ("MyBlog.naver", "PostList.naver") else ""
if not BID:
    BID = T.js("(function(){var m=(document.querySelector('iframe#mainFrame')||{}).src||'';m=m.match(/blogId=([^&]+)/);return m?m[1]:''})()")
if not BID:
    sys.exit("블로그 주소를 못 찾았어요(%s)" % u)
print("블로그:", "https://blog.naver.com/" + BID)

PRE = "var w=document.getElementById('mainFrame').contentWindow,d=w.document;"
js = T.js


def comps():
    return js("(function(){" + PRE + "return [...d.querySelectorAll('.se-component')].map(c=>c.className.split(' ')[1]).join(',')})()")


def paste_html(h):
    js("(function(){" + PRE + "var bd=[...d.querySelectorAll('iframe')].find(i=>/input_buffer/.test(i.id)).contentDocument.body;"
       "var dt=new w.DataTransfer();dt.setData('text/html',%s);dt.setData('text/plain','.');"
       "bd.dispatchEvent(new w.ClipboardEvent('paste',{clipboardData:dt,bubbles:true,cancelable:true}));return 1})()" % json.dumps(h, ensure_ascii=False), 1.5)


def upload_image(path, name):
    b = base64.b64encode(open(path, "rb").read()).decode()
    code = ("(function(){" + PRE + "var x=d.querySelector('input[type=file]#hidden-file');if(!x){var b=[...d.querySelectorAll('button')].find(z=>/^사진/.test(z.innerText.trim()));"
            "var oc=w.HTMLInputElement.prototype.click;w.HTMLInputElement.prototype.click=function(){if(this.type=='file')return;return oc.apply(this,arguments)};b.click();w.HTMLInputElement.prototype.click=oc;x=d.querySelector('input[type=file]#hidden-file');}"
            "var s=atob('%s'),u=new Uint8Array(s.length);for(var i=0;i<s.length;i++)u[i]=s.charCodeAt(i);var dt=new w.DataTransfer();dt.items.add(new w.File([u],%s,{type:'image/jpeg'}));"
            "x.files=dt.files;x.dispatchEvent(new w.Event('change',{bubbles:true}));return 'img'})()") % (b, json.dumps(name))
    n0 = comps().count("se-image")
    js(code)
    for _ in range(30):
        time.sleep(1)
        if comps().count("se-image") > n0: break
    time.sleep(1.2)


def upload_video(path, name, vtitle):
    b = base64.b64encode(open(path, "rb").read()).decode()
    js("(function(){" + PRE + "[...d.querySelectorAll('button')].find(x=>/^동영상/.test(x.innerText.trim())).click();return 1})()", 2.5)
    js(("(function(){" + PRE + "var oc=w.HTMLInputElement.prototype.click;var got=null;w.HTMLInputElement.prototype.click=function(){if(this.type=='file'){got=this;return;}return oc.apply(this,arguments)};"
        "var pop=[...d.querySelectorAll('[class*=se-popup-video-uplo]')].filter(e=>e.offsetParent).pop();var add=[...pop.querySelectorAll('button,label,a')].find(x=>/동영상 추가/.test(x.innerText));add.click();"
        "setTimeout(function(){w.HTMLInputElement.prototype.click=oc;var x=got||pop.querySelector('input[type=file]')||[...d.querySelectorAll('input[type=file]')].find(i=>/mp4/.test(i.accept));"
        "var s=atob('%s'),u=new Uint8Array(s.length);for(var i=0;i<s.length;i++)u[i]=s.charCodeAt(i);"
        "var dt=new w.DataTransfer();dt.items.add(new w.File([u],%s,{type:'video/mp4'}));x.files=dt.files;x.dispatchEvent(new w.Event('change',{bubbles:true}));},1500);return 'vid'})()") % (b, json.dumps(name)))
    for _ in range(120):
        time.sleep(2)
        t = js("(function(){" + PRE + "var p=[...d.querySelectorAll('[class*=se-popup-video-uplo]')].filter(e=>e.offsetParent).pop();return p?p.innerText.replace(/\\s+/g,' '):'none'})()")
        if "업로드 완료" in t: break
    js("(function(){" + PRE + "var pop=[...d.querySelectorAll('[class*=se-popup-video-uplo]')].filter(e=>e.offsetParent).pop();var t=[...pop.querySelectorAll('input[type=text],textarea')].filter(x=>x.offsetParent)[0];"
       "var proto=t.tagName=='TEXTAREA'?w.HTMLTextAreaElement.prototype:w.HTMLInputElement.prototype;Object.getOwnPropertyDescriptor(proto,'value').set.call(t,%s);"
       "t.dispatchEvent(new w.Event('input',{bubbles:true}));t.dispatchEvent(new w.Event('change',{bubbles:true}));"
       "[...pop.querySelectorAll('button')].filter(x=>x.innerText.trim()=='완료').pop().click();return 1})()" % json.dumps(vtitle[:40], ensure_ascii=False), 4)


def caret(sel):
    js("(function(){" + PRE + "w.focus();d.querySelector('[contenteditable=true]').focus();var els=d.querySelectorAll(%s);var el=els[els.length-1];var r=el.getBoundingClientRect();"
       "var o={bubbles:true,cancelable:true,clientX:r.left+20,clientY:r.top+r.height/2,button:0,buttons:1,view:w,detail:1};var tg=d.elementFromPoint(o.clientX,o.clientY)||el;"
       "tg.dispatchEvent(new w.PointerEvent('pointerdown',o));tg.dispatchEvent(new w.MouseEvent('mousedown',o));"
       "var rg=d.createRange();rg.selectNodeContents(el);rg.collapse(false);var s=w.getSelection();s.removeAllRanges();s.addRange(rg);"
       "tg.dispatchEvent(new w.PointerEvent('pointerup',o));tg.dispatchEvent(new w.MouseEvent('mouseup',o));tg.dispatchEvent(new w.MouseEvent('click',o));return 1})()" % json.dumps(sel), 0.6)


# 1) 글쓰기 화면 — 떠날 때 '저장 안 된 글' 확인창이 크롬을 멈추지 않게 미리 끈다
js("(function(){window.onbeforeunload=null;window.alert=function(){};window.confirm=function(){return true};return 1})()")
T.go("https://blog.naver.com/%s?Redirect=Write&" % BID, 12)
js("(function(){" + PRE + "w.onbeforeunload=null;w.alert=function(){};w.confirm=function(){return true};return 1})()")
js("(function(){" + PRE + "var b=[...d.querySelectorAll('button')].filter(x=>x.offsetParent&&x.innerText.trim()=='취소');if(b.length)b[0].click();return 1})()", 1.5)  # 이어쓰기 물음 → 새로
js("(function(){" + PRE + "var h=[...d.querySelectorAll('button')].filter(x=>x.offsetParent&&/닫기/.test(x.innerText+x.className)&&/help/.test(x.className));h.forEach(x=>x.click());return h.length})()", 1)

# 2) 본문 — 블로그_본문.json 이 있으면 사진 → 설명 → 사진 → 설명 (2026-11-08 대표님: 항상 이 순서, 카드 글자만 옮기지 말고 풀어 쓰기)
def P(lines):
    paste_html("".join("<p>%s</p>" % html.escape(l) if l.strip() else "<p><br></p>" for l in lines) + "<p><br></p>")


BJ = os.path.join(D, "블로그_본문.json")
if os.path.exists(BJ):
    B = json.load(open(BJ, encoding="utf-8"))
    TITLE = B.get("제목") or TITLE
    TAGS = B.get("태그") or TAGS
    for c in B["카드"]:
        upload_image(os.path.join(D, c["사진"]), c["사진"])
        if c.get("글"): P(c["글"])
    if vid:
        if B.get("영상글"): P(B["영상글"])
        upload_video(vid, os.path.basename(vid), TITLE)
else:  # 예전 방식: 인사 글 → 카드 → 영상
    P(BODY.splitlines())
    for i, c in enumerate(cards, 1):
        upload_image(c, "%02d.jpg" % i)
    if vid:
        upload_video(vid, os.path.basename(vid), TITLE)

# 3) 제목(본문 뒤에 넣어야 본문으로 안 섞인다)
for _ in range(3):
    caret(".se-documentTitle .se-text-paragraph")
    js("(function(){" + PRE + "var bd=[...d.querySelectorAll('iframe')].find(i=>/input_buffer/.test(i.id)).contentDocument.body;var dt=new w.DataTransfer();dt.setData('text/plain',%s);"
       "bd.dispatchEvent(new w.ClipboardEvent('paste',{clipboardData:dt,bubbles:true,cancelable:true}));return 1})()" % json.dumps(TITLE, ensure_ascii=False), 4)
    if js("(function(){" + PRE + "return d.querySelector('.se-documentTitle').innerText.trim()})()") != "제목": break
print("제목:", js("(function(){" + PRE + "return d.querySelector('.se-documentTitle').innerText.trim()})()"))
print("구성:", comps())

if DRAFT:
    js("(function(){" + PRE + "[...d.querySelectorAll('button')].find(x=>x.innerText.trim()=='저장'&&x.offsetParent).click();return 1})()", 3)
    print("임시저장까지 했어요(발행 안 함)"); sys.exit(0)

# 4) 발행 — 태그만 넣고 카테고리는 기본
CLK = "var o={bubbles:true,cancelable:true,view:w,button:0};['pointerdown','mousedown','pointerup','mouseup','click'].forEach(t=>EL.dispatchEvent(new (t.startsWith('pointer')?w.PointerEvent:w.MouseEvent)(t,o)));"
js("(function(){" + PRE + "var EL=[...d.querySelectorAll('button')].find(x=>x.textContent.trim()=='발행'&&!/confirm/.test(x.className));" + CLK + "return 1})()", 3)
js("(function(){" + PRE + "var L=d.querySelector('[class*=layer_publish]');var i=[...L.querySelectorAll('input')].find(x=>/태그 입력/.test(x.placeholder||''));if(!i)return 0;var tags=%s;"
   "tags.forEach(function(t){i.focus();Object.getOwnPropertyDescriptor(w.HTMLInputElement.prototype,'value').set.call(i,t);i.dispatchEvent(new w.Event('input',{bubbles:true}));"
   "['keydown','keypress','keyup'].forEach(k=>i.dispatchEvent(new w.KeyboardEvent(k,{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true})));});return tags.length})()" % json.dumps(TAGS, ensure_ascii=False), 1.5)
js("(function(){" + PRE + "var EL=d.querySelector('[class*=layer_publish] [class*=confirm_btn]');" + CLK + "return 1})()")
post = ""
for _ in range(15):
    time.sleep(6)
    mm = re.search(r"https://blog\.naver\.com/%s/\d+" % re.escape(BID), T.url())
    if mm: post = mm.group(0); break
print("올라간 글:", post or "주소 확인 실패 — 블로그에서 확인")
