# -*- coding: utf-8 -*-
"""퍼스널 OS 앱 서버 다시 띄우기 — 윈도우판 (2026-10-24)
매니저가 답하는 중이면 끝날 때까지(최대 10분) 기다렸다가, 서버만 끄고 시작 프로그램의 vbs 로 다시 켠다.
'python3 ~/퍼스널OS/.os_키트/윈도우_서버재시작.py' 로 부르면 25초 뒤 따로 떨어져서 실행된다(대화가 먼저 저장되게)."""
import os, sys, subprocess, time, json, urllib.request

NO_WINDOW, DETACHED = 0x08000000, 0x00000008
if "--now" not in sys.argv:
    subprocess.Popen([sys.executable, os.path.abspath(__file__), "--now"], creationflags=DETACHED | NO_WINDOW, close_fds=True)
    print("25초 뒤 서버를 다시 띄웁니다(답하는 중이면 끝난 뒤).")
    sys.exit(0)

time.sleep(25)
busy = ("@(Get-CimInstance Win32_Process | Where-Object { $_.Name -like 'claude*' -and $_.CommandLine -like '* -p *' }).Count")
for _ in range(60):                                     # 최대 10분: 매니저(클로드)가 답하는 중이면 기다림
    n = subprocess.run(["powershell", "-NoProfile", "-Command", busy], capture_output=True, text=True, creationflags=NO_WINDOW).stdout.strip()
    if n in ("", "0"):
        break
    time.sleep(10)
ps = ("Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*윈도우_서버.py*' } | "
      "ForEach-Object { Stop-Process -Id $_.ProcessId -Force }")
subprocess.run(["powershell", "-NoProfile", "-Command", ps], creationflags=NO_WINDOW)
time.sleep(2)
startup = subprocess.run(["powershell", "-NoProfile", "-Command", "[Environment]::GetFolderPath('Startup')"],
                         capture_output=True, text=True, encoding="utf-8", creationflags=NO_WINDOW).stdout.strip()
subprocess.Popen(["wscript", os.path.join(startup, "퍼스널OS_서버.vbs")], creationflags=NO_WINDOW)
