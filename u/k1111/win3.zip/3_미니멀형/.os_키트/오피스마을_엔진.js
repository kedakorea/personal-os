/* 퍼스널 OS — 캐릭터형(본사형·동물의숲형·싸이월드형) 오피스·마을 화면 (시안 2026-10-27 → 키트 2026-10-28)
   사무실화면.py 가 window.OSV(회사·매니저·호칭·부서) 를 넣어 부서/00_비서실/오피스마을.html 로 만든다.
   앱 화면 안의 iframe 으로 뜬다. 실제 시각·할 일·메모·일하는 부서(/api/office)·마지막 대화를 읽어 그린다.
   주소에 ?t=20 처럼 붙이면 그 시각으로 그린다(시험용). */
(function(){
const CFG=window.OSV||{};
const Q=new URLSearchParams(location.search);
let T,NIGHT,DEEP,TIME,DATE;
function clock(){
  const n=new Date(),qt=Q.get('t');
  T=qt?parseFloat(qt):n.getHours()+n.getMinutes()/60;
  NIGHT=(T>=18||T<6);DEEP=(T>=23||T<6);
  TIME=String(Math.floor(T)).padStart(2,'0')+':'+String(qt?Math.round((T%1)*60):n.getMinutes()).padStart(2,'0');
  DATE=(n.getMonth()+1)+'/'+n.getDate()+' '+'일월화수목금토'[n.getDay()]+'요일';
  document.body.classList.toggle('night',NIGHT);
}
const COMPANY=CFG.company||'우리 회사',CHIEF=CFG.chief||'매니저',CALL=CFG.call||'대표님';
const cv=document.getElementById('cv'),g=cv.getContext('2d'),ov=document.getElementById('ov');
const SC=4,INK='#2b2220';
const ESC=s=>String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const EM=n=>n?`<em>${n>9?'9+':n}</em>`:'';

/* ── 그리기 도구 ── */
function R(x,y,w,h,c){g.fillStyle=c;g.fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h));}
/* 휴대폰 배치(2026-11-01): 캔버스를 세로로 길게 쓰고, 그림 묶음을 옮기고(OX,OY) 키워(K) 그린다. 라벨·상자도 같은 변환을 따른다 */
let MOB=false,PX=1,MH=236,OX=0,OY=0,K=1;
function xf(ox,oy,k){OX=ox;OY=oy;K=k;g.setTransform(PX*k,0,0,PX*k,PX*ox,PX*oy);}
const LZ=()=>MOB?2.8:1;
function L(x,y,html,cls,al,col){const d=document.createElement('div'),z=LZ();d.className='lb '+(cls||'');d.innerHTML=html;d.style.left=((x*K+OX)*SC/z)+'px';d.style.top=((y*K+OY)*SC/z)+'px';if(z!==1)d.style.zoom=z;if(al!=='l')d.style.transform=al==='r'?'translateX(-100%)':'translateX(-50%)';if(col)d.style.setProperty('--c',col);ov.appendChild(d);return d;}
function BOX(x,y,w,h,html,cls){const d=document.createElement('div'),z=MOB?(/clk/.test(cls)?2:3):1;d.className='bx '+(cls||'');d.innerHTML=html;Object.assign(d.style,{left:(x*K+OX)*SC/z+'px',top:(y*K+OY)*SC/z+'px',width:w*K*SC/z+'px',height:h*K*SC/z+'px'});if(z!==1)d.style.zoom=z;ov.appendChild(d);return d;}
function rows(y0,y1,f,c){for(let y=y0;y<y1;y++){const r=f(y);if(r&&r[1]>r[0])R(r[0],y,r[1]-r[0],1,c);}}
function ell(cx,cy,rx,ry,c){rows(Math.floor(cy-ry),Math.ceil(cy+ry),y=>{const t=1-((y+.5-cy)/ry)**2;if(t<=0)return null;const d=rx*Math.sqrt(t);return[Math.round(cx-d),Math.round(cx+d)];},c);}
function poly(P,c){let y0=1e9,y1=-1e9;P.forEach(p=>{y0=Math.min(y0,p[1]);y1=Math.max(y1,p[1]);});rows(Math.floor(y0),Math.ceil(y1),y=>{const yy=y+.5;let a=1e9,b=-1e9;for(let i=0;i<P.length;i++){const p=P[i],q=P[(i+1)%P.length];if((p[1]<=yy&&q[1]>yy)||(q[1]<=yy&&p[1]>yy)){const x=p[0]+(yy-p[1])*(q[0]-p[0])/(q[1]-p[1]);a=Math.min(a,x);b=Math.max(b,x);}}return a<b?[Math.round(a),Math.round(b)]:null;},c);}
function rr(x0,y0,x1,y1,r,c){rows(y0,y1,y=>{let d=0;const yy=y+.5;if(yy<y0+r)d=r-Math.sqrt(Math.max(0,r*r-(y0+r-yy)**2));else if(yy>y1-r)d=r-Math.sqrt(Math.max(0,r*r-(yy-(y1-r))**2));return[Math.round(x0+d),Math.round(x1-d)];},c);}
function spr(x,y,parts,ol,k){ol=ol||INK;k=k||1;parts.forEach(p=>{if(p[5]!==0)R(x+p[0]*k-1,y+p[1]*k-1,p[2]*k+2,p[3]*k+2,ol);});parts.forEach(p=>R(x+p[0]*k,y+p[1]*k,p[2]*k,p[3]*k,p[4]));}
function glow(cx,cy,r,c,a){g.save();g.globalCompositeOperation='lighter';const gr=g.createRadialGradient(cx,cy,0,cx,cy,r);gr.addColorStop(0,c);gr.addColorStop(1,'rgba(0,0,0,0)');g.globalAlpha=a;g.fillStyle=gr;g.fillRect(cx-r,cy-r,2*r,2*r);g.restore();}
const LATE=[];function lit(f){const t=[OX,OY,K];LATE.push(()=>{xf(t[0],t[1],t[2]);f();});}
function above(yc,f){g.save();g.beginPath();g.rect(-4000,-4000,8000,yc+4000);g.clip();f();g.restore();}
function nightPass(col,a,clip){if(!NIGHT)return;g.save();g.setTransform(PX,0,0,PX,0,0);if(clip&&!MOB){g.beginPath();g.rect(clip[0],clip[1],clip[2],clip[3]);g.clip();}g.globalAlpha=a;g.fillStyle=col;g.fillRect(0,0,400,MH);g.restore();LATE.forEach(f=>f());xf(0,0,1);}
function heart(x,y,c){[[1,0,2,1],[4,0,2,1],[0,1,7,2],[1,3,5,1],[2,4,3,1],[3,5,1,1]].forEach(p=>R(x+p[0],y+p[1],p[2],p[3],c));}
function tree(x,y,s,dk,lt,fruit){s=s||1;R(x-2,y+6*s,4,6*s,'#7a4a28');ell(x,y,9*s,8*s,dk||'#2f6b34');ell(x-1,y-1,7*s,6*s,lt||'#3f8a43');if(fruit){R(x-4,y-2,2,2,fruit);R(x+3,y+1,2,2,fruit);R(x-1,y+3,2,2,fruit);}}
function plant(x,y,pot){R(x+1,y+8,8,7,pot||'#c8693f');R(x,y+8,10,2,'#a8532f');ell(x+5,y+4,6,6,'#2f7a3a');ell(x+4,y+3,4,4,'#45a052');}

/* ── 캐릭터 ── */
function person(x,y,o,k){
  const H=o.hair,S=o.skin||'#f3cfb0',C=o.shirt,P=o.pants||'#3a3f52';
  const p=[[1,1,8,3,H],[2,0,6,1,H],[2,3,6,5,S],[1,8,8,5,C],[3,13,2,2,P],[5,13,2,2,P],[2,15,3,1,INK],[5,15,3,1,INK]];
  if(o.style==='long')p.push([1,3,1,7,H],[8,3,1,7,H]);else p.push([1,3,1,2,H],[8,3,1,2,H]);
  if(o.style==='bun')p.push([3,-2,4,2,H]);
  p.push([2,3,6,1,H,0],[3,5,1,1,INK,0],[6,5,1,1,INK,0],[2,6,1,1,'#f2a1a1',0],[7,6,1,1,'#f2a1a1',0],[1,12,1,1,S,0],[8,12,1,1,S,0],[2,9,1,3,'rgba(0,0,0,.18)',0],[7,9,1,3,'rgba(0,0,0,.18)',0]);
  if(o.tie)p.push([4,8,2,4,o.tie,0]);else p.push([3,8,1,1,'#fff',0],[6,8,1,1,'#fff',0]);
  if(o.glasses)p.push([2,5,2,1,INK,0],[6,5,2,1,INK,0],[4,5,2,1,INK,0]);
  spr(x,y,p,INK,k);
}
function animal(x,y,o,k){
  const F=o.fur,M=o.mz,E=o.ear||F,C=o.shirt,P=o.pants||'#6b5440',K=o.kind,PK='#f4a3a3';
  const p=[];
  if(K==='rabbit')p.push([2,-4,2,6,F],[6,-4,2,6,F]);
  if(K==='cat')p.push([1,0,2,3,F],[7,0,2,3,F]);
  if(K==='fox')p.push([1,-1,2,4,F],[7,-1,2,4,F]);
  if(K==='bear'||K==='panda'||K==='hamster')p.push([1,1,2,2,K==='panda'?INK:F],[7,1,2,2,K==='panda'?INK:F]);
  p.push([1,2,8,6,F],[1,8,8,5,C],[3,13,2,2,P],[5,13,2,2,P],[2,15,3,1,F],[5,15,3,1,F]);
  if(K==='dog')p.push([-1,3,2,5,E],[8,3,2,5,E]);
  p.push([3,5,4,3,M,0],[3,4,1,1,INK,0],[6,4,1,1,INK,0],[4,5,2,1,INK,0],[2,6,1,1,PK,0],[7,6,1,1,PK,0],[1,12,1,1,F,0],[8,12,1,1,F,0],[3,8,4,1,'rgba(255,255,255,.35)',0]);
  if(K==='rabbit')p.push([3,-3,1,4,PK,0],[6,-3,1,4,PK,0]);
  if(K==='cat')p.push([2,1,1,1,PK,0],[7,1,1,1,PK,0],[1,3,8,1,'rgba(0,0,0,.08)',0]);
  if(K==='fox')p.push([1,-1,2,1,INK,0],[7,-1,2,1,INK,0]);
  if(K==='panda')p.push([2,4,2,2,INK,0],[6,4,2,2,INK,0],[3,4,1,1,'#fff',0],[6,4,1,1,'#fff',0]);
  if(K==='hamster')p.push([1,5,2,2,'#f6c39a',0],[7,5,2,2,'#f6c39a',0]);
  spr(x,y,p,'#3a2a20',k);
}
function minimi(x,y,o,k){
  const H=o.hair,S=o.skin||'#fde2cc',C=o.shirt,P=o.pants||'#4a5a8a';
  const p=[[1,0,12,4,H],[0,2,14,4,H],[2,3,10,7,S],[4,10,6,5,C],[3,11,1,3,C],[10,11,1,3,C],[5,15,2,2,P],[7,15,2,2,P],[4,17,3,1,INK],[7,17,3,1,INK]];
  if(o.style==='long')p.push([0,4,2,9,H],[12,4,2,9,H]);else p.push([0,4,2,3,H],[12,4,2,3,H]);
  if(o.style==='bun')p.push([5,-3,4,3,H]);
  p.push([2,3,10,1,H,0],[2,4,4,1,H,0],[9,4,3,1,H,0],[4,6,1,2,INK,0],[9,6,1,2,INK,0],[6,8,2,1,'#d0605a',0],[3,8,1,1,'#f6a6b2',0],[10,8,1,1,'#f6a6b2',0],[3,14,1,1,S,0],[10,14,1,1,S,0],[6,10,2,1,'#fff',0]);
  if(o.glasses)p.push([3,5,3,3,INK,0],[4,6,1,1,'#cfe8ff',0],[8,5,3,3,INK,0],[9,6,1,1,'#cfe8ff',0],[6,6,2,1,INK,0]);
  if(o.ribbon)p.push([10,-1,3,2,o.ribbon,0],[11,1,1,1,o.ribbon,0]);
  spr(x,y,p,'#3a3550',k);
}

/* ── 회사·부서 예시 데이터 ── */
const D=[
 {k:'sec',name:'비서실',col:'#1e31ef',late:false,who:{hq:'매니저',village:'강아지 매니저',cyworld:'매니저'},
  p:{hair:'#3a2a22',style:'bun',shirt:'#2b3a7a',skin:'#f3cfb0'},a:{kind:'dog',fur:'#d9a066',mz:'#f6e2c4',ear:'#8a5a30',shirt:'#2b3a7a'},m:{hair:'#3a2a22',style:'bun',shirt:'#2b3a7a',ribbon:'#ff5c8a'},st:'작업 중'},
 {k:'des',name:'디자인실',col:'#e2525c',late:true,who:{hq:'디자이너',village:'토끼',cyworld:'디자이너'},
  p:{hair:'#6b3b2a',style:'long',shirt:'#e2525c',skin:'#f6d6bc'},a:{kind:'rabbit',fur:'#f7f4ee',mz:'#ffffff',shirt:'#e2525c'},m:{hair:'#7a3f2a',style:'long',shirt:'#e2525c'},st:'작업 중'},
 {k:'ch',name:'채널운영팀',col:'#8a4fd0',late:false,who:{hq:'운영자',village:'고양이',cyworld:'운영자'},
  p:{hair:'#1d1d26',style:'short',shirt:'#8a4fd0',glasses:1,skin:'#eac09c'},a:{kind:'cat',fur:'#f2c76e',mz:'#fff3dc',shirt:'#8a4fd0'},m:{hair:'#1d1d26',style:'short',shirt:'#8a4fd0',glasses:1},st:'작업 중'},
 {k:'plan',name:'기획실',col:'#e8892f',late:true,who:{hq:'기획자',village:'곰',cyworld:'기획자'},
  p:{hair:'#a8743a',style:'short',shirt:'#e8892f',skin:'#f3cfb0'},a:{kind:'bear',fur:'#9a6a44',mz:'#d9b48a',shirt:'#e8892f'},m:{hair:'#a8743a',style:'short',shirt:'#e8892f'},st:'작업 중'},
 {k:'adm',name:'총무팀',col:'#2f9a6a',late:false,who:{hq:'총무',village:'여우',cyworld:'총무'},
  p:{hair:'#3a2a20',style:'long',shirt:'#2f9a6a',skin:'#d9a57e'},a:{kind:'fox',fur:'#ef8a3a',mz:'#fff3dc',shirt:'#2f9a6a'},m:{hair:'#3a2a20',style:'long',shirt:'#2f9a6a',skin:'#f6d2b4'},st:'완료'},
 {k:'sch',name:'일정관리팀',col:'#2aa3b8',late:false,who:{hq:'일정 담당',village:'판다',cyworld:'일정 담당'},
  p:{hair:'#141414',style:'bun',shirt:'#2aa3b8',skin:'#f6d6bc'},a:{kind:'panda',fur:'#ffffff',mz:'#ffffff',shirt:'#2aa3b8'},m:{hair:'#141414',style:'short',shirt:'#2aa3b8'},st:'대기'},
 {k:'sup',name:'지원팀',col:'#c9a227',late:false,who:{hq:'리서처',village:'햄스터',cyworld:'리서처'},
  p:{hair:'#7a6a60',style:'short',shirt:'#c9a227',skin:'#eac09c'},a:{kind:'hamster',fur:'#e9b47a',mz:'#fff3dc',shirt:'#c9a227'},m:{hair:'#c48a5a',style:'long',shirt:'#c9a227'},st:'작업 중'},
];
const C=CFG.c||window.C||'hq';
let S=(location.hash==='#village'||(!location.hash&&localStorage.getItem('osvScene')==='village'))?'village':'office';
/* 실제 부서 넣기 — 0번 자리는 매니저(비서실), 1~6번은 부서표 순서. 모자라면 빈 자리, 넘치면 '+N' */
(function(){
  const names=(CFG.depts||[]).slice(0,6);
  D[0].name=CFG.sec||'비서실';D[0].who={hq:CHIEF,village:CHIEF,cyworld:CHIEF};
  for(let i=1;i<7;i++){const d=D[i],n=names[i-1];
    if(n){d.name=n;d.who={hq:'',village:d.who.village,cyworld:''};}else{d.name='빈 자리';d.vacant=true;}}
})();
const EXTRA=Math.max(0,(CFG.depts||[]).length-6), STAFF=D.filter(d=>!d.vacant).length+EXTRA;
let BUSY=new Map(),DONE=new Set(),CARDS=[],CARDN=0,MEMON=0,NOTEN=0,TODAYN=0,TOTALN=0,LAST=null;
function who(d){return d.who[C];}
function nw(d){return `<span>${ESC(d.name)}</span>`+(who(d)?' · '+ESC(who(d)):'');}
function busy(d){return !d.vacant&&(BUSY.has(d.name)||(d===D[0]&&BUSY.size>0));}
function state(d){if(d.vacant)return 'home';if(!NIGHT)return 'work';return busy(d)?'late':'home';}
function homeMode(d,i){if(DEEP)return 'zz';return i%2?'zz':'front';}
function drawChar(d,x,y){if(C==='village')animal(x,y,d.a);else if(C==='cyworld')minimi(x,y,d.m);else person(x,y,d.p);}
let LATE_N=0,BUB={},LATEBUB={};
const cut=(s,n)=>{s=String(s||'').replace(/\s+/g,' ').trim();return s.length>n?s.slice(0,n-1)+'…':s;};
function recompute(){
  BUB={};LATEBUB={};
  D.forEach(d=>{
    const b=busy(d),w=BUSY.get(d.name);
    d.st=d.vacant?'':b?'작업 중':DONE.has(d.name)?'완료':(d===D[0]?'대기 중':'출근');
    if(b&&d!==D[0]){BUB[d.k]='✍ '+cut(w&&(w.now||w.ask)||'작업 중',MOB?10:16);LATEBUB[d.k]='🌙 야근 · '+cut(w&&(w.now||w.ask)||'작업 중',MOB?8:13);}
    else if(!b&&DONE.has(d.name)&&d!==D[0])BUB[d.k]='✓ 완료!';
  });
  BUB.sec=BUSY.size?`${CALL} 지시 처리 중이에요`:(TODAYN?`오늘 할 일 ${TODAYN}개 챙기는 중`:`${CALL}, 무엇부터 할까요?`);
  LATE_N=D.filter(d=>state(d)==='late').length;
}
const BUCK={today:['오늘','#e2525c'],tomorrow:['내일','#1e31ef'],sched:['모레','#8a4fd0'],week:['곧 할 일','#2f9a6a']};
function colOf(n){const b=Object.values(BUCK).find(x=>x[0]===n);return b?b[1]:(D.find(d=>d.name===n)||{}).col||'#888';}
function boardHTML(){
  const cards=CARDS.slice(0,CARDN>6?5:6);
  const more=CARDN-cards.length;
  return `<div class="bh">📌 진행 중 보드 <small>할 일 ${CARDN}개${TODAYN?` · 오늘 ${TODAYN}`:''}</small></div><div class="bg">`+
   (cards.length?cards.map(c=>`<div class="cd" style="--c:${colOf(c[0])}"><i>${ESC(c[0])}</i><b>${ESC(c[1])}</b><s>${ESC(c[2])}</s></div>`).join(''):
    `<div class="cd more" style="grid-column:1/-1"><b>할 일이 비어 있어요</b><s>${ESC(CALL)}, 할 일을 말씀만 하세요</s></div>`)+
   (more>0?`<div class="cd more"><b>+${more}개 더</b><s>할일 칸에서 보기</s></div>`:'')+`</div>`;
}
function clockHTML(){return `<b>${TIME}</b><span>${DATE}</span>`;}
function dialog(x,y,w,h){
  let nm,tx;
  if(BUSY.size){const w0=[...BUSY.values()][0];nm=`${CHIEF} ▶`;tx=`${CALL}, ${[...BUSY.keys()].filter(n=>n!==D[0].name).join('·')||D[0].name}에서 처리하고 있어요 — ${w0.now||w0.ask||'작업 중'}`;}
  else if(LAST){nm=`${LAST.who} ▶`;tx=LAST.text;}
  else{nm=`${CHIEF} ▶`;tx=NIGHT?`${CALL}, 6시가 지나 다들 퇴근했어요. 일을 시키시면 그 부서만 나와서 야근해요 🌙`:`${CALL}, 오늘은 무엇부터 할까요?`;}
  const d=BOX(x,y,w,h,`<div class="nm">${ESC(nm)}</div><div class="tx">${ESC(cut(tx,96))}${C==='cyworld'?`<small>${DATE} ${TIME}</small>`:''}</div>`+
    `<form class="say" autocomplete="off"><input placeholder="${ESC(CHIEF)}에게 지시하기 — 적고 엔터" aria-label="지시하기"><button type="submit">보내기</button></form>`,'dlg');
  d.querySelector('form').onsubmit=e=>{e.preventDefault();const i=e.target.querySelector('input'),v=i.value.trim();if(!v)return;
    if(window.parent&&parent.OSV_send&&parent.OSV_send(v)){i.value='';i.placeholder='보냈어요 — 해당 부서가 일하는 모습이 보여요';}};
}
function plateHTML(d,stx){return nw(d)+(stx?' · '+stx:'');}
function seatLabels(d,cx,plateY,bub,tagY){
  if(d.vacant){L(cx,plateY,'빈 자리','plate off','c','#9aa3b1');return;}
  const st=state(d);
  const stx=st==='work'?d.st:st==='late'?'🌙 야근 중':'퇴근';
  L(cx,plateY,plateHTML(d,stx),'plate'+(st==='home'?' off':''),'c',d.col);
  if(st==='home')L(cx,tagY,'🏠 퇴근 · 집으로','tag');
  else if(st==='late')L(bub[0],bub[1],LATEBUB[d.k],'bub late',bub[2]);
  else if(BUB[d.k])L(bub[0],bub[1],BUB[d.k],'bub',bub[2]);
}

function bossLabels(d,cx,plateY,bub,tagY){
  const st=state(d);
  const stx=st==='work'?d.st:st==='late'?'🌙 야근 중':'퇴근';
  L(cx,plateY,`★ <span>${who(d)}</span> · ${d.name} · ${stx}`,'plate boss'+(st==='home'?' off':''),'c',d.col);
  if(st==='home')L(cx,tagY,'🏠 퇴근 · 집으로','tag');
  else if(BUB[d.k])L(bub[0],bub[1],BUB[d.k],'bub',bub[2]);
}

/* ── 상단 바 ── */
function topbar(){
  const inOffice=NIGHT?LATE_N:STAFF, inVil=NIGHT?STAFF-LATE_N:0;
  const title=C==='cyworld'?`♡ ${ESC(COMPANY)}의 미니홈피 ♡`:`${C==='village'?'🐾 ':''}${ESC(COMPANY)} ${S==='office'?'오피스':(C==='village'?'마을':'타운')}`;
  const work=[...BUSY.keys()];
  const sub=work.length?`${ESC(CHIEF)} · ${TIME} · <b>${ESC(work.join('·'))} 일하는 중</b>`:
    NIGHT?`${ESC(CHIEF)} · ${TIME} 퇴근 시간 · <b>${LATE_N?'야근 '+LATE_N+'명':'모두 퇴근'}</b>`:`${ESC(CHIEF)} · ${TIME} · <b>${STAFF}명 출근</b>`;
  document.getElementById('top').innerHTML=
   `<div class="ttl">${title}</div><div class="sub">${sub}</div><div class="sp"></div>`+
   `<div class="tabs"><a href="#office" data-s="office" class="${S==='office'?'on':''}">🏢 오피스</a><a href="#village" data-s="village" class="${S==='village'?'on':''}">🏡 마을</a></div>`+
   `<div class="pill">🕒 ${TIME} · 오피스 ${inOffice}명 · 마을 ${inVil}명</div>`+
   (C==='cyworld'?`<div class="pill">TODAY ${TODAYN} | TOTAL ${TOTALN}</div>`:'')+
   `<div class="tm"><a href="#chat" data-go="chat" class="on">💬 대화창</a></div>`;
}

/* ══════════ 본사형 ══════════ */
function winCity(x,y,w,h){
  R(x-3,y-3,w+6,h+6,'#9aa3b1');R(x-1,y-1,w+2,h+2,'#7c8595');
  R(x,y,w,h,NIGHT?'#18204a':'#bfe0ff');
  if(NIGHT){R(x+w-12,y+5,6,6,'#fff6c8');R(x+w-10,y+5,4,4,'#18204a');[[6,6],[20,3],[30,9],[14,12]].forEach(s=>R(x+s[0],y+s[1],1,1,'#fff'));}
  else{R(x+w-14,y+5,7,7,'#ffe27a');ell(x+14,y+8,7,3,'#ffffff');}
  const B=[[0,22,10],[9,14,9],[17,26,8],[24,10,12],[35,20,9],[43,16,11],[53,24,8]];
  B.forEach(b=>{const bx=x+b[0],bh=h-b[1]+8;R(bx,y+h-bh+8,b[2],bh-8>0?bh-8:0,NIGHT?'#2a3352':'#8fa6c8');
    for(let yy=y+h-bh+11;yy<y+h-2;yy+=4)for(let xx=bx+2;xx<bx+b[2]-2;xx+=3)R(xx,yy,1,2,NIGHT?((xx*7+yy*3)%5<2?'#ffd86b':'#3a4466'):'#c9dbf2');});
  R(x+w/2-1,y,2,h,'#9aa3b1');R(x,y+h/2-1,w,2,'#9aa3b1');
  R(x-5,y+h+3,w+10,3,'#b9c0cc');
}
function cubicle(x,y,d){
  const st=state(d);
  R(x,y-30,92,28,'#a2aab8');R(x+2,y-28,88,26,'#cdd3dc');
  for(let i=0;i<88;i+=4)R(x+2+i,y-28,1,26,'#c6ccd6');
  R(x+8,y-25,8,9,'#ffffff');R(x+9,y-23,6,1,'#c9cfd8');R(x+9,y-21,5,1,'#c9cfd8');R(x+18,y-24,7,7,'#ffe27a');R(x+82,y-25,5,6,'#9fe0c0');
  if(st!=='home')person(x+24,y-22,d.p,2);
  else{R(x+22,y-17,24,17,'#2f3646');R(x+24,y-15,20,13,'#4b5466');}
  R(x+56,y-18,24,15,'#2f3440');R(x+58,y-16,20,11,st==='home'?'#3f4654':'#a9d8ff');
  if(st!=='home'){R(x+60,y-14,10,1,'#ffffff');R(x+60,y-12,14,1,'#e0f0ff');R(x+60,y-10,8,1,d.col);}
  R(x+66,y-3,4,3,'#2f3440');
  R(x+1,y,90,6,'#eee0c0');R(x+1,y+6,90,1,'#b49e70');R(x+3,y+7,86,13,'#d6c398');R(x+3,y+19,86,1,'#b49e70');
  R(x+46,y+1,14,3,'#cfd4dc');R(x+12,y+1,8,3,'#ffffff');R(x+84,y-4,5,5,'#ffffff');R(x+85,y-3,3,1,d.col);
  seatLabels(d,x+46,y+8,[x+46,y-33],y-14);
  if(st==='late')lit(()=>{above(y,()=>person(x+24,y-22,d.p,2));glow(x+68,y-8,34,'rgba(255,225,160,1)',.6);R(x+58,y-16,20,11,'#cfeaff');R(x+60,y-14,10,1,'#fff');R(x+60,y-10,8,1,d.col);});
  if(st!=='home'&&NIGHT===false){}
}
function mgrHQ(d){
  const st=state(d),x=4,y=62,w=94,h=132;
  // 짙은 남색 카펫 (직원 자리 회색 카펫과 구분)
  R(x,y,w,h,'#2e3858');for(let yy=y+3;yy<y+h;yy+=6)for(let xx=x+3+(((yy-y)/6)%2?3:0);xx<x+w;xx+=6)R(xx,yy,1,1,'#3d4870');
  // 손님 의자 2개 + 작은 탁자 (미팅 자리)
  rr(x+14,y+96,x+w-14,y+122,5,'#1e31ef');rr(x+16,y+98,x+w-16,y+120,4,'#2a3fff');R(x+18,y+100,w-36,1,'#cfe986');R(x+18,y+117,w-36,1,'#cfe986');
  [x+22,x+w-38].forEach(cx=>{rr(cx,y+100,cx+16,y+112,3,'#d9dde6');R(cx+2,y+110,12,6,'#b9c0cc');R(cx+2,y+116,2,3,'#7c8595');R(cx+12,y+116,2,3,'#7c8595');});
  ell(x+w/2,y+110,9,5,'#5a3a24');ell(x+w/2,y+109,8,4,'#7a5236');R(x+w/2-2,y+106,4,3,'#ffffff');
  // 뒤 책장
  R(x+4,y+2,30,40,'#5a3a24');R(x+6,y+4,26,11,'#7a5236');R(x+6,y+17,26,11,'#7a5236');R(x+6,y+30,26,10,'#7a5236');
  ['#e2525c','#1e31ef','#2f9a6a','#c9a227','#8a4fd0'].forEach((c,k)=>{R(x+7+k*5,y+6,4,9,c);R(x+8+k*5,y+19,3,9,c);});R(x+8,y+32,10,8,'#d4a72c');R(x+21,y+33,9,7,'#ffffff');
  // 액자
  R(x+62,y+6,24,16,'#d4a72c');R(x+64,y+8,20,12,'#fffaf0');R(x+68,y+11,12,1,'#1e31ef');R(x+68,y+14,9,1,'#9aa3b1');R(x+68,y+16,10,1,'#9aa3b1');
  // 높은 등받이 의자
  rr(x+33,y+22,x+63,y+64,7,'#141a2a');rr(x+36,y+25,x+60,y+62,5,'#2a3350');R(x+40,y+30,16,1,'#3d4870');
  if(st!=='home')person(x+38,y+30,d.p,2);
  // 큰 원목 책상 + 금색 테두리
  R(x+8,y+60,w-16,7,'#4a2f1c');R(x+8,y+60,w-16,2,'#d4a72c');R(x+10,y+67,w-20,22,'#6b4428');R(x+10,y+88,w-20,2,'#4a2f1c');
  R(x+14,y+71,w-28,1,'#d4a72c');R(x+14,y+84,w-28,1,'#d4a72c');
  // 듀얼 모니터
  R(x+14,y+44,18,13,'#2f3440');R(x+16,y+46,14,9,st==='home'?'#3f4654':'#a9d8ff');R(x+21,y+57,4,3,'#2f3440');
  R(x+62,y+44,18,13,'#2f3440');R(x+64,y+46,14,9,st==='home'?'#3f4654':'#cfe986');R(x+69,y+57,4,3,'#2f3440');
  if(st!=='home'){R(x+18,y+48,8,1,'#fff');R(x+18,y+50,10,1,d.col);R(x+66,y+48,9,1,'#fff');R(x+66,y+51,6,1,'#1e31ef');}
  // 금색 명패 + 머그
  R(x+36,y+62,22,4,'#d4a72c');R(x+38,y+63,18,2,'#f2d27a');R(x+76,y+57,4,4,'#ffffff');R(x+80,y+58,1,2,'#ffffff');
  plant(x+4,y+104,'#5a3a24');
  // 유리벽 + 문
  R(x+w,y,3,h,'rgba(150,200,240,.55)');R(x+w,y,1,h,'#8fb8dc');for(let yy=y+10;yy<y+h;yy+=30)R(x+w,yy,3,2,'#ffffff');
  R(x,y+h-2,w-30,3,'rgba(150,200,240,.55)');R(x,y+h-2,w-30,1,'#8fb8dc');
  L(x+w/2,y+h-12,'매니저실','tagw');
  if(st==='home'){L(x+w/2,y+44,'🏠 퇴근 · 집으로','tag');}
  bossLabels(d,x+w/2,y+76,[x+w/2,y+14],y+44);
}
function officeHQ(){
  R(0,0,400,236,'#d8dce3');
  R(0,0,400,60,'#eef0f4');R(0,0,400,3,'#dfe3ea');R(0,56,400,4,'#a9b0bc');
  for(let i=0;i<400;i+=50)R(i+20,0,10,2,NIGHT?'#cfd5df':'#ffffff');
  winCity(10,8,62,40);
  R(106,3,162,54,'#2a3550');R(108,5,158,50,'#f9fafc');R(150,57,76,2,'#2a3550');R(160,55,6,2,'#e2525c');R(170,55,6,2,'#1e31ef');
  BOX(108,5,158,50,boardHTML(),'brd');
  R(276,9,54,28,'#2a2e36');R(278,11,50,24,'#101317');
  BOX(278,11,50,24,clockHTML(),'clk');
  R(340,7,24,32,'#7a5a3a');R(342,11,20,26,'#fffdf4');R(347,5,10,4,'#9aa3b1');for(let i=0;i<5;i++)R(344,20+i*3,16,1,'#c9cfd8');R(344,13,7,6,'#ffe27a');R(353,13,6,5,'#ffb3c8');
  L(352,41,'메모장'+EM(MEMON),'tagw');
  R(368,9,28,32,'#5b6475');for(let r=0;r<3;r++)for(let c=0;c<2;c++){R(370+c*13,11+r*10,11,8,'#2d3340');}
  R(372,13,8,5,'#ffffff');R(385,23,8,5,'#ffe27a');R(372,33,8,5,'#cfe8ff');R(373,14,2,1,'#e2525c');
  L(382,43,'우편함'+EM(NOTEN),'tagw');
  for(let y=60;y<236;y+=8)for(let x=0;x<400;x+=8)R(x,y,8,8,((x+y)/8)%2?'#d3d8e0':'#dbdfe6');
  mgrHQ(D[0]);
  const COLS=[106,202,298];
  [1,2,3].forEach((i,j)=>cubicle(COLS[j],96,D[i]));
  [4,5,6].forEach((i,j)=>cubicle(COLS[j],152,D[i]));
  plant(386,176);plant(196,178);
  R(282,178,24,14,'#e6e9ee');R(284,176,20,4,'#9aa3b1');R(286,180,16,3,'#ffffff');R(282,192,24,2,'#9aa3b1');
  nightPass('#0c1230',.55);
  dialog(14,198,372,34);
}
function car(x,y,c,dir){R(x,y+2,18,5,c);R(x+3,y,11,3,c);R(x+4,y+1,4,2,'#cfe6ff');R(x+10,y+1,4,2,'#cfe6ff');R(x+2,y+7,4,2,INK);R(x+12,y+7,4,2,INK);
  if(NIGHT)lit(()=>{const hx=dir>0?x+18:x;R(hx-1,y+3,2,2,'#fff6c8');glow(hx+(dir>0?6:-6),y+4,10,'rgba(255,240,180,1)',.5);});}
function lamp(x,y){R(x,y,1,16,'#4b525e');R(x-1,y-1,5,2,'#4b525e');if(NIGHT)lit(()=>{R(x+1,y+1,2,1,'#fff3b0');glow(x+2,y+6,16,'rgba(255,220,140,1)',.55);});}
function villaHome(x,y,w,d,i){
  const wall=['#c9785a','#e6d3a8','#b8bec8','#d99a7a','#efe6d6','#a7b6a0','#d4b8c8'][i];
  const st=state(d),mode=homeMode(d,i);
  R(x,y,w,40,wall);R(x-1,y-3,w+2,4,'#5b616b');R(x,y+40,w,1,'#8a8f98');
  const lights=[];
  for(let fl=0;fl<2;fl++)for(let c=0;c<2;c++){const wx=x+5+c*(w-17),wy=y+3+fl*12;R(wx,wy,12,9,'#3a4252');R(wx+1,wy+1,10,7,'#9cc3e6');R(wx+6,wy+1,1,7,'#3a4252');lights.push([wx+1,wy+1]);}
  R(x+3,y+14,w-6,1,'#ffffff');R(x+3,y+12,1,3,'#ffffff');R(x+w-4,y+12,1,3,'#ffffff');
  R(x+w/2-5,y+28,10,12,'#5a3a2a');R(x+w/2-4,y+29,8,11,'#7a5038');R(x+w/2+2,y+34,1,1,'#ffd34d');R(x+w/2-8,y+25,16,3,d.col);
  if(d.vacant){L(x+w/2,y+42,'빈 집','home off','c','#9aa3b1');return;}
  L(x+w/2,y+42,nw(d),'home','c',d.col);
  if(st==='work')L(x+w/2,y+51,'🏢 출근 중','chip');
  else if(st==='late')L(x+w/2,y+51,'🖥 오피스 야근','chip late');
  else{
    L(x+w/2,y+51,mode==='zz'?'💤 집 안 · 자는 중':'🏠 집 앞 · 쉬는 중','chip home');
    lit(()=>{lights.forEach((l,k)=>{if(mode==='front'||k>=2)R(l[0],l[1],10,7,mode==='zz'?'#c9a24a':'#ffd86b');});R(x+w/2-4,y+29,8,11,mode==='front'?'#ffd86b':'#7a5038');glow(x+w/2,y+36,18,'rgba(255,210,120,1)',.35);
      if(mode==='front')person(x+w-12,y+24,d.p);});
    if(mode==='zz')L(x+w-8,y-9,'z z','zz');
  }
}
function villageHQ(){
  R(0,0,400,236,'#d9dce1');
  for(let y=0;y<236;y+=8)R(0,y,400,1,'#cfd3d9');for(let x=0;x<400;x+=8)R(x,0,1,236,'#cfd3d9');
  const road=(x,y,w,h,v)=>{R(x,y,w,h,'#585e69');if(v){R(x,y,1,h,'#a7adb6');R(x+w-1,y,1,h,'#a7adb6');for(let k=y;k<y+h;k+=12)R(x+w/2-1,k,2,6,'#f2f2f2');}else{R(x,y,w,1,'#a7adb6');R(x,y+h-1,w,1,'#a7adb6');for(let k=x;k<x+w;k+=12)R(k,y+h/2-1,6,2,'#f2f2f2');}};
  road(0,86,400,16);road(0,166,400,16);road(192,0,16,236,1);
  const cross=(x,y,v)=>{for(let k=0;k<16;k+=3)v?R(x,y+k,8,2,'#f2f2f2'):R(x+k,y,2,8,'#f2f2f2');};
  R(192,86,16,16,'#585e69');R(192,166,16,16,'#585e69');
  cross(182,86,1);cross(210,86,1);cross(182,166,1);cross(210,166,1);cross(192,76,0);cross(192,104,0);cross(192,156,0);cross(192,184,0);
  // 오피스 타워
  R(98,0,88,82,'#3c4f70');R(100,0,84,80,'#5d7fae');
  const litF=[2,3];
  for(let r=0;r<8;r++)for(let c=0;c<9;c++){const wx=103+c*9,wy=3+r*8;R(wx,wy,7,5,'#a9c9ef');if(NIGHT&&(litF.includes(r)||(r*3+c)%7===0)&&c<8)lit(()=>R(wx,wy,7,5,'#ffd86b'));}
  R(126,66,32,14,'#2a3550');R(128,68,13,12,'#8fb3df');R(143,68,13,12,'#8fb3df');R(98,80,88,2,'#2a3550');
  BOX(108,2,68,9,`<div class="bld" style="text-align:center">${ESC(COMPANY)} 오피스</div>`,'');
  L(142,70,'🏢 오피스 들어가기','btn');
  // 본사 (파일 보기)
  poly([[212,30],[262,10],[312,30]],'#2a3a6a');poly([[220,28],[262,13],[304,28]],'#3c5290');
  R(216,30,92,48,'#efe9dc');R(214,28,96,3,'#d9d2c2');
  for(let k=0;k<6;k++){R(222+k*15,34,6,38,'#ffffff');R(221+k*15,33,8,2,'#c9c2b2');R(221+k*15,71,8,2,'#c9c2b2');}
  R(252,52,20,26,'#6b4a3a');R(256,40,12,8,'#ffd34d');R(258,42,8,4,'#d4a62a');
  R(210,78,104,4,'#c9c2b2');
  L(262,64,'🏛 본사 (파일 보기)','btn dk');
  // 공원
  R(318,4,78,76,'#8fc46a');R(318,4,78,1,'#6fa04e');
  ell(356,44,12,8,'#cfd5df');ell(356,43,9,6,'#7cc3e6');R(355,36,2,6,'#cfe8ff');
  tree(330,18,1,'#2f6b34','#4a9a4a');tree(386,20,1,'#2f6b34','#4a9a4a');tree(332,64);tree(384,62);
  R(346,66,20,3,'#8a5a30');R(347,69,2,3,'#5a3a2a');R(363,69,2,3,'#5a3a2a');
  BOX(4,4,90,30,`<div class="sign"><b>🏙 ${ESC(COMPANY)} 타운</b><small>6시 이후엔 모두 집으로 · 야근 부서만 오피스에</small></div>`,'');
  lamp(90,66);lamp(310,66);lamp(30,146);lamp(370,146);lamp(110,146);
  // 부서 집 (빌라)
  const hx=[4,50,96,142,214,260,306];
  D.forEach((d,i)=>villaHome(hx[i],106,42,d,i));
  // 편의점
  R(354,110,42,36,'#ffffff');R(354,106,42,6,'#2f9a6a');R(354,112,42,2,'#e8892f');R(358,118,34,16,'#9cc3e6');R(370,128,10,18,'#cfe8ff');
  L(375,148,'🏪 편의점','tagw');
  // 아래 블록
  R(6,190,58,38,'#e0663b');R(4,186,62,5,'#b84a28');R(10,196,50,10,'#ffffff');R(30,210,12,18,'#8a3a20');R(12,212,12,8,'#9cc3e6');R(48,212,12,8,'#9cc3e6');
  R(14,198,10,6,'#e0663b');R(15,199,8,1,'#fff');
  L(35,228,'📮 우체국','bld','c');
  R(70,188,62,40,'#a0563a');for(let k=0;k<5;k++)R(72+k*12,188,2,40,'#8a4a30');R(68,184,66,5,'#6b3a28');R(90,212,22,16,'#4a2a1a');R(76,194,50,10,'#f6ead2');
  [['#e2525c',80],['#1e31ef',86],['#2f9a6a',92],['#c9a227',98],['#8a4fd0',104],['#e8892f',110]].forEach(b=>R(b[1],196,4,7,b[0]));
  L(101,228,'📚 도서관','bld','c');
  R(140,186,46,30,'#2a2e36');R(142,188,42,26,NIGHT?'#2c6fd5':'#3c8af0');R(146,192,22,2,'#ffffff');R(146,197,30,2,'#cfe8ff');R(146,202,26,2,'#cfe8ff');R(146,207,18,2,'#ffd34d');R(150,216,3,12,'#4b525e');R(174,216,3,12,'#4b525e');
  if(NIGHT)lit(()=>{R(142,188,42,26,'#3c8af0');R(146,192,22,2,'#ffffff');R(146,197,30,2,'#cfe8ff');R(146,207,18,2,'#ffd34d');glow(163,201,26,'rgba(120,180,255,1)',.4);});
  L(163,228,'📋 게시판','bld','c');
  R(214,192,32,3,'#2a3550');R(215,195,2,20,'#4b525e');R(243,195,2,20,'#4b525e');R(218,205,24,4,'#8a95a8');R(218,197,24,6,'#cfe8ff');
  L(230,216,'🚌 정류장','tagw');
  R(254,190,58,38,'#f2e6d2');R(252,186,62,6,'#6b4a3a');for(let k=0;k<62;k+=8)R(252+k,192,4,4,'#e2525c');R(258,200,22,14,'#9cc3e6');R(286,206,14,22,'#6b4a3a');
  L(283,228,'☕ 카페','bld','c');
  R(318,190,78,44,'#6a707b');for(let k=0;k<5;k++)R(322+k*15,192,1,16,'#f2f2f2');
  car(322,196,'#e2525c',1);car(352,196,'#ffffff',1);
  // 도로 위
  if(!NIGHT){car(30,88,'#1e31ef',1);car(250,88,'#ffd34d',-1);car(120,170,'#2f9a6a',1);car(330,170,'#ffffff',-1);
    R(150,168,30,12,'#2f9a6a');R(152,170,26,4,'#cfe8ff');R(154,180,4,2,INK);R(172,180,4,2,INK);
    person(60,72,{hair:'#3a2a22',shirt:'#9aa3b1',skin:'#f3cfb0'});person(300,148,{hair:'#a8743a',shirt:'#e6d3a8',style:'long'});person(212,150,{hair:'#1d1d26',shirt:'#5b6475'});
  }else{car(60,88,'#e2525c',1);car(300,170,'#cfd5df',-1);}
  nightPass('#0b1030',.58);
}

/* ══════════ 동물의숲형 ══════════ */
function winForest(x,y,w,h){
  R(x-3,y-3,w+6,h+6,'#6b4226');R(x,y,w,h,NIGHT?'#1d2a4a':'#bfe8f7');
  if(NIGHT){R(x+w-12,y+5,6,6,'#fff6c8');R(x+w-10,y+4,5,5,'#1d2a4a');[[5,5],[18,9],[28,4],[38,12]].forEach(s=>R(x+s[0],y+s[1],1,1,'#fff'));}
  else{ell(x+12,y+9,7,3,'#fff');R(x+w-14,y+5,7,7,'#ffd34d');}
  ell(x+w/2,y+h+6,w*.7,16,NIGHT?'#1f3a2a':'#7cc06a');
  [[8,24],[22,20],[40,26],[50,22]].forEach(t=>{R(x+t[0]-1,y+t[1]+5,2,6,'#5a3a20');ell(x+t[0],y+t[1],5,7,NIGHT?'#173022':'#2f6b34');});
  if(NIGHT)lit(()=>{[[12,30],[30,26],[44,32]].forEach(f=>{R(x+f[0],y+f[1],1,1,'#f6ff8a');glow(x+f[0],y+f[1],4,'rgba(240,255,120,1)',.7);});});
  R(x+w/2-1,y,2,h,'#6b4226');R(x,y+h/2-1,w,2,'#6b4226');R(x-5,y+h+3,w+10,3,'#8a5a30');
}
function deskVIL(x,y,w,d,bub){
  const st=state(d),cx=x+Math.round(w*.55)-10;
  if(st!=='home')animal(cx,y-22,d.a,2);
  else{R(cx-1,y-12,22,12,'#94602f');R(cx,y-14,20,3,'#b57a45');}
  R(x+8,y-13,21,13,'#4a3426');R(x+10,y-11,17,9,st==='home'?'#6b5a48':'#9fd6c8');
  if(st!=='home'){R(x+12,y-9,9,1,'#ffffff');R(x+12,y-7,12,1,d.col);}
  R(x+w-12,y-6,7,6,'#d9774a');R(x+w-13,y-6,9,2,'#b85a32');ell(x+w-9,y-9,4,3,'#5f9a3a');R(x+w-9,y-13,1,3,'#5f9a3a');
  R(x-1,y-1,w+2,22,'#4a3426');R(x,y,w,5,'#c58a52');R(x,y+5,w,1,'#8a5a30');R(x+1,y+6,w-2,14,'#a8703e');R(x+w/2-4,y+16,8,2,'#6b4226');
  seatLabels(d,x+w/2,y+7,bub||[cx+23,y-21,'l'],y-12);
  if(st==='late')lit(()=>{above(y,()=>animal(cx,y-22,d.a,2));glow(x+18,y-6,32,'rgba(255,214,140,1)',.65);R(x+10,y-11,17,9,'#bff0e0');});
}
function bossVIL(x,y,w,d){
  const st=state(d),cx=x+w/2-10;
  ell(x+w/2,y+10,w/2+8,15,'#b8323a');ell(x+w/2,y+10,w/2+5,13,'#d9454e');for(let k=0;k<40;k++){const a=k/40*Math.PI*2;if(k%2)R(x+w/2+Math.cos(a)*(w/2+1),y+10+Math.sin(a)*10,2,1,'#ffd34d');}
  // 깃발
  R(x+4,y-34,2,34,'#6b4226');poly([[x+6,y-34],[x+22,y-29],[x+6,y-24]],'#ffd34d');R(x+w-6,y-34,2,34,'#6b4226');poly([[x+w-6,y-34],[x+w-22,y-29],[x+w-6,y-24]],'#ffd34d');
  // 큰 잎사귀 의자
  ell(cx+10,y-20,17,17,'#2f6b34');ell(cx+10,y-21,14,14,'#4c9a46');R(cx+9,y-34,2,24,'#2f6b34');for(let k=1;k<5;k++){R(cx+10-k*3,y-30+k*4,k*3,1,'#2f6b34');R(cx+11,y-30+k*4,k*3,1,'#2f6b34');}
  if(st!=='home')animal(cx,y-22,d.a,2);
  R(x+8,y-13,21,13,'#4a3426');R(x+10,y-11,17,9,st==='home'?'#6b5a48':'#9fd6c8');
  if(st!=='home'){R(x+12,y-9,9,1,'#ffffff');R(x+12,y-7,12,1,d.col);}
  // 황동 종 + 명패
  R(x+w-24,y-7,10,7,'#d4a72c');R(x+w-22,y-9,6,2,'#d4a72c');R(x+w-20,y-11,2,2,'#4a3426');R(x+w-26,y-1,14,1,'#8a5a30');
  R(x-2,y-2,w+4,24,'#3a2618');R(x-1,y-1,w+2,6,'#e0a860');R(x-1,y-1,w+2,1,'#ffd34d');R(x-1,y+5,w+2,1,'#8a5a30');R(x,y+6,w,15,'#b07a46');R(x+4,y+9,w-8,1,'#ffd34d');R(x+4,y+18,w-8,1,'#ffd34d');
  bossLabels(d,x+w/2,y+9,[x+w/2+22,y-30,'l'],y-12);
  if(st==='home'){R(cx-1,y-12,22,12,'#94602f');R(cx,y-14,20,3,'#b57a45');}
}
function officeVIL(){
  for(let y=0;y<62;y+=7){R(0,y,400,6,'#a86d40');R(0,y+6,400,1,'#7a4a28');R(0,y+1,400,1,'#b97d4d');for(let k=(y*13)%60;k<400;k+=70)R(k,y+2,3,2,'#8a5530');}
  R(0,60,400,3,'#6b4226');
  winForest(14,10,58,38);
  R(98,2,164,56,'#6b4226');R(101,5,158,50,'#d8a866');
  for(let k=0;k<160;k++)R(102+(k*37)%156,6+(k*17)%48,1,1,'#c4925a');
  BOX(101,5,158,50,boardHTML(),'brd');
  R(287,3,10,5,'#5f9a3a');R(284,5,5,3,'#4a8a34');R(266,8,52,30,'#6b4226');R(269,11,46,24,'#fff3dc');
  BOX(269,11,46,24,clockHTML(),'clk');
  R(328,8,28,36,'#4a3426');R(330,10,24,32,'#fffaf0');for(let i=0;i<7;i++){R(331,13+i*4,2,2,'#4a3426');R(336,14+i*4,15,1,'#e3d4b8');}R(347,40,3,7,'#e2525c');R(338,16,9,5,'#ffd34d');
  L(342,46,'메모장'+EM(MEMON),'tagw');
  for(let y=63;y<236;y+=8){R(0,y,400,8,'#e3b47d');R(0,y+7,400,1,'#c99860');for(let x=((y-63)/8)%2?0:24;x<400;x+=48)R(x,y,1,7,'#c99860');}
  ell(200,152,140,46,'#6f9e4a');ell(200,152,136,43,'#9cc86e');R(66,152,268,1,'#7aa852');
  for(let k=-5;k<=5;k++){const sx=200+k*24;for(let t=0;t<14;t++)R(sx+t*(k<0?-1:1)*.6,152-t,1,1,'#7aa852');for(let t=0;t<14;t++)R(sx+t*(k<0?-1:1)*.6,152+t,1,1,'#7aa852');}
  // 책장
  R(286,64,58,26,'#6b4226');R(288,66,54,10,'#8a5a30');R(288,78,54,10,'#8a5a30');
  ['#e2525c','#1e31ef','#2f9a6a','#c9a227','#8a4fd0','#e8892f','#2aa3b8'].forEach((c,k)=>{R(290+k*7,67,5,9,c);R(292+k*6,79,4,9,c);});
  // 우편함
  R(377,82,4,22,'#6b4226');R(365,66,28,18,'#4a3426');R(366,67,26,16,'#e2525c');R(368,65,22,2,'#4a3426');R(370,72,18,2,'#a83a40');R(393,66,2,12,'#6b4226');R(393,66,7,4,'#ffd34d');R(372,62,8,4,'#ffffff');
  L(379,105,'우편함'+EM(NOTEN),'tagw');
  deskVIL(16,94,90,D[1]);bossVIL(140,96,120,D[0]);
  deskVIL(16,140,90,D[2]);deskVIL(156,140,90,D[3]);deskVIL(296,140,90,D[4],[341,106]);
  deskVIL(86,184,90,D[5]);deskVIL(226,184,90,D[6]);
  plant(4,66,'#d9774a');plant(388,170,'#d9774a');plant(4,176,'#d9774a');
  nightPass('#14203f',.5);
  dialog(10,207,380,27);
}
function cottage(x,y,d,i){
  const st=state(d),mode=homeMode(d,i);
  poly([[x-5,y+19],[x+20,y-1],[x+45,y+19]],'#4a3426');poly([[x-2,y+18],[x+20,y+1],[x+42,y+18]],d.col);
  for(let k=0;k<4;k++)R(x+6+k*7,y+12-((k%2)*2),5,1,'rgba(0,0,0,.15)');
  R(x+30,y+2,5,9,'#4a3426');R(x+31,y+3,3,7,'#a0563a');
  R(x+1,y+18,38,23,'#4a3426');R(x+2,y+19,36,21,'#fff3dc');
  R(x+15,y+27,10,13,'#4a3426');R(x+16,y+28,8,12,'#a8703e');R(x+22,y+34,1,1,'#ffd34d');
  R(x+4,y+23,9,8,'#4a3426');R(x+5,y+24,7,6,'#9fd6f0');R(x+8,y+24,1,6,'#4a3426');
  R(x+27,y+23,9,8,'#4a3426');R(x+28,y+24,7,6,'#9fd6f0');R(x+31,y+24,1,6,'#4a3426');
  ell(x+3,y+40,4,2,'#3f7a36');ell(x+37,y+40,4,2,'#3f7a36');R(x+2,y+38,1,1,'#ff8fb1');R(x+37,y+38,1,1,'#ffe27a');
  if(d.vacant){L(x+20,y+43,'빈 집','home off');return;}
  L(x+20,y+43,`${ESC(d.name)} · ${ESC(d.who.village)}`,'home');
  if(st==='work')L(x+20,y+51,'🏢 출근 중','chip');
  else if(st==='late')L(x+20,y+51,'🖥 오피스 야근','chip late');
  else{
    L(x+20,y+51,mode==='zz'?'💤 자는 중':'🏠 집 앞','chip');
    lit(()=>{R(x+5,y+24,7,6,'#ffd86b');R(x+28,y+24,7,6,mode==='zz'?'#c9a24a':'#ffd86b');R(x+8,y+24,1,6,'#4a3426');R(x+31,y+24,1,6,'#4a3426');glow(x+20,y+30,20,'rgba(255,210,120,1)',.35);
      if(mode==='front')animal(x+27,y+27,d.a);});
    if(mode==='zz')L(x+34,y-7,'z z','zz');
  }
}
function villageVIL(){
  R(0,0,400,236,'#4fa3d4');
  for(let y=2;y<236;y+=6)for(let x=(y%12)?0:10;x<400;x+=20)R(x,y,8,1,'#79c2e8');
  rr(3,3,397,216,18,'#e9d391');rr(5,5,395,213,16,'#f1dfa4');rr(10,10,390,208,12,'#4f8a43');
  for(let y=16;y<204;y+=8)for(let x=16;x<384;x+=8)if(((x+y)/8)%2)R(x,y,8,8,'#4a8340');
  // 길
  R(14,64,372,8,'#c4a96f');R(14,65,372,6,'#d8c08a');
  R(195,56,10,152,'#c4a96f');R(196,56,8,152,'#d8c08a');
  // 강
  R(10,140,380,12,'#c9b27a');R(10,142,380,8,'#5fb6e2');for(let k=14;k<390;k+=14)R(k,145,6,1,'#9fd8f2');
  const bridge=(x)=>{R(x,137,20,18,'#6b4226');R(x+1,138,18,16,'#a8703e');for(let k=0;k<16;k+=3)R(x+1,139+k,18,1,'#8a5a30');R(x,137,20,1,'#4a3426');R(x,154,20,1,'#4a3426');};
  bridge(190);bridge(88);
  // 오피스
  poly([[138,26],[200,2],[262,26]],'#4a3426');poly([[142,25],[200,5],[258,25]],'#e0663b');
  for(let k=0;k<5;k++)R(160+k*16,17,10,1,'rgba(0,0,0,.18)');
  R(146,24,108,34,'#4a3426');R(148,25,104,32,'#f6ead2');
  for(let k=0;k<4;k++){const wx=154+k*24+(k>1?14:0);if(k===1||k===2)continue;R(wx,31,14,11,'#4a3426');R(wx+1,32,12,9,'#9fd6f0');}
  R(156,31,14,11,'#4a3426');R(157,32,12,9,'#9fd6f0');R(230,31,14,11,'#4a3426');R(231,32,12,9,'#9fd6f0');
  R(192,40,16,18,'#4a3426');R(193,41,14,17,'#a8703e');
  ell(200,15,6,6,'#fffaf0');ell(200,15,4,4,'#5f9a3a');
  if(NIGHT)lit(()=>{R(157,32,12,9,'#ffd86b');R(231,32,12,9,'#ffd86b');glow(200,40,40,'rgba(255,210,120,1)',.35);});
  BOX(170,26,60,8,`<div class="bld" style="text-align:center">${ESC(COMPANY)} 오피스</div>`,'');
  L(200,59,'🏢 오피스 들어가기','btn');
  // 본사
  poly([[282,28],[334,6],[386,28]],'#4a3426');poly([[286,27],[334,9],[382,27]],'#2f6f73');
  R(288,26,92,32,'#4a3426');R(290,27,88,30,'#efe3c8');
  for(let k=0;k<6;k++)R(294+k*14,30,5,26,'#fffaf0');
  R(326,40,16,18,'#4a3426');R(327,41,14,17,'#6b4a3a');R(329,15,10,8,'#fffaf0');R(331,17,6,4,'#2f6f73');
  L(334,59,'🏛 본사 (파일 보기)','btn');
  BOX(14,12,104,40,`<div class="sign"><b>🌿 ${ESC(COMPANY)} 마을</b><small>6시가 지나면 모두 집으로 퇴근<br>일을 시키면 그 부서만 나와서 야근</small></div>`,'');
  tree(126,40,1,'#2f6b34','#3f8a43','#e2525c');tree(272,46,.8);
  // 부서 집
  const hx=[16,62,108,154,218,264,310];
  D.forEach((d,i)=>cottage(hx[i],78,d,i));
  tree(370,96,1,'#2f6b34','#3f8a43','#ff9a3a');
  // 아래
  const bldg=(x,w,roof,lab,ic)=>{poly([[x-4,176],[x+w/2,158],[x+w+4,176]],'#4a3426');poly([[x-1,175],[x+w/2,160],[x+w+1,175]],roof);R(x,174,w,24,'#4a3426');R(x+1,175,w-2,22,'#fff3dc');R(x+w/2-5,184,10,14,'#4a3426');R(x+w/2-4,185,8,13,'#a8703e');R(x+4,179,9,8,'#4a3426');R(x+5,180,7,6,'#9fd6f0');R(x+w-13,179,9,8,'#4a3426');R(x+w-12,180,7,6,'#9fd6f0');ic(x+w/2,165);L(x+w/2,199,lab,'bld');};
  bldg(18,56,'#e2525c','📮 우체국',(cx,cy)=>{R(cx-4,cy,8,6,'#fffaf0');R(cx-4,cy,8,1,'#4a3426');});
  bldg(86,56,'#4f7fd6','📚 도서관',(cx,cy)=>{R(cx-4,cy,4,6,'#ffd34d');R(cx,cy,4,6,'#e2525c');});
  R(160,166,26,20,'#4a3426');R(162,168,22,16,'#d8a866');R(164,170,8,6,'#fffaf0');R(174,171,8,7,'#ffd34d');R(166,178,9,5,'#ffb3c8');R(164,186,3,12,'#4a3426');R(179,186,3,12,'#4a3426');
  L(173,199,'📋 게시판','bld');
  // 캠핑장 + 과수원 + 꽃밭
  poly([[222,192],[240,164],[258,192]],'#4a3426');poly([[225,191],[240,167],[255,191]],'#ffd34d');poly([[236,191],[240,178],[244,191]],'#6b4226');
  L(240,199,'⛺ 쉼터','tagw');
  tree(280,170,1,'#2f6b34','#3f8a43','#e2525c');tree(306,180,1,'#2f6b34','#3f8a43','#ff9a3a');tree(334,168,1,'#2f6b34','#3f8a43','#e2525c');tree(366,182,1,'#2f6b34','#3f8a43','#ffd34d');
  for(let k=0;k<14;k++){const fx=270+(k*29)%110,fy=196+(k*7)%8;R(fx,fy,2,2,['#ff8fb1','#ffe27a','#ffffff'][k%3]);}
  for(let k=0;k<10;k++){const fx=24+(k*37)%150,fy=124+(k*5)%10;R(fx,fy,2,2,['#ff8fb1','#ffe27a','#ffffff'][k%3]);}
  // 부두
  R(192,206,16,30,'#6b4226');R(193,206,14,30,'#a8703e');for(let k=208;k<236;k+=4)R(193,k,14,1,'#8a5a30');
  if(!NIGHT){
    [[60,146],[70,147],[300,145]].forEach(p=>{R(p[0],p[1],5,3,'#ffffff');R(p[0]+4,p[1]-1,2,2,'#ffffff');R(p[0]+6,p[1]-1,1,1,'#e8892f');});
    R(250,60,3,2,'#ffe27a');R(252,59,1,1,'#4a3426');R(110,130,2,2,'#ff8fb1');R(113,130,2,2,'#ff8fb1');
    animal(212,112,{kind:'cat',fur:'#9aa3b1',mz:'#ffffff',shirt:'#5f9a3a'});L(217,129,'이웃 냥이','tagw');
  }else{
    lit(()=>{for(let k=0;k<18;k++){const fx=20+(k*53)%360,fy=60+(k*31)%140;R(fx,fy,1,1,'#f6ff8a');glow(fx,fy,4,'rgba(240,255,120,1)',.6);}
      R(330,224,10,2,'#fff6c8');R(326,228,18,1,'#fff6c8');});
  }
  nightPass('#0e1838',.55);
}

/* ══════════ 싸이월드형 ══════════ */
function cyFrame(){
  R(0,0,400,236,'#2c6fd5');for(let y=1;y<236;y+=6)for(let x=((y-1)/6)%2?4:1;x<400;x+=6)R(x,y,2,2,'#4a88e2');
  R(5,3,390,230,'#9ec0ee');R(6,4,388,228,'#ffffff');
  R(5,3,2,2,'#2c6fd5');R(393,3,2,2,'#2c6fd5');R(5,231,2,2,'#2c6fd5');R(393,231,2,2,'#2c6fd5');
}
function cyHeader(title){
  const tabs=S==='office'?['홈','미니룸','다이어리','방명록']:['홈','동네','사진첩','방명록'];
  BOX(8,5,384,21,`<div class="hdr" style="padding-top:2px"><span class="bgm">♪ <b>BGM</b> 오늘도 출근 완료 — ${ESC(COMPANY)} ▶ ▮▮</span><div class="t">${title}</div></div><div class="hdr" style="margin-top:7px">${tabs.map((t,i)=>`<a class="${i===1?'on':''}">${t}</a>`).join('')}</div>`,'');
  R(10,21,380,1,'#2c6fd5');
}
function cyDesk(cx,dy,d){
  const st=state(d);
  if(st!=='home')minimi(cx-26,dy-28,d.m,2);
  else{R(cx-24,dy-6,24,6,'#f48fb1');R(cx-22,dy-8,20,3,'#ffc2d6');}
  R(cx-24,dy,44,3,'#a86a48');R(cx-23,dy,42,2,'#d89a6a');R(cx-21,dy+3,38,8,'#b5764a');R(cx-21,dy+3,38,1,'#8a5236');R(cx-21,dy+11,2,3,'#8a5236');R(cx+15,dy+11,2,3,'#8a5236');
  R(cx+4,dy-11,15,11,'#8a93a6');R(cx+5,dy-10,13,9,st==='home'?'#c9cfd8':'#eef1f6');R(cx+10,dy-7,3,3,'#ff8fb1');R(cx+2,dy-1,19,1,'#8a93a6');
  if(d.vacant){L(cx-2,dy+14,'빈 자리','plate off','c','#9aa3b1');return;}
  const stx=st==='work'?d.st:st==='late'?'야근 중':'퇴근';
  L(cx-2,dy+14,`<span>${ESC(d.name)}</span> · ${stx}`,'plate'+(st==='home'?' off':''),'c',d.col);
  if(st==='late')L(cx-2,dy-36,LATEBUB[d.k],'bub late');
  else if(st==='work'&&BUB[d.k])L(cx-2,dy-36,BUB[d.k],'bub');
  else if(st==='home')L(cx-12,dy-16,'🏠 퇴근','tag');
  if(st==='late')lit(()=>{above(dy,()=>minimi(cx-26,dy-28,d.m,2));glow(cx,dy-6,26,'rgba(255,200,220,1)',.6);R(cx+5,dy-10,13,9,'#ffffff');});
}
function bigHeart(cx,cy,r,c){ell(cx-r*.5,cy,r*.55,r*.5,c);ell(cx+r*.5,cy,r*.55,r*.5,c);poly([[cx-r*1.05,cy+r*.1],[cx+r*1.05,cy+r*.1],[cx,cy+r*1.15]],c);}
function cyBoss(cx,dy,d){
  const st=state(d);
  ell(cx,dy+6,40,9,'#ffd34d');ell(cx,dy+6,37,7,'#fff1b8');
  bigHeart(cx-2,dy-24,17,'#e2457a');bigHeart(cx-2,dy-24,14,'#ff8fb1');R(cx-12,dy-28,3,2,'#ffffff');
  if(st!=='home')minimi(cx-16,dy-30,d.m,2);
  R(cx-34,dy,64,3,'#8a5236');R(cx-33,dy,62,2,'#d89a6a');R(cx-33,dy,62,1,'#ffd34d');R(cx-31,dy+3,58,9,'#b5764a');R(cx-29,dy+5,54,1,'#ffd34d');R(cx-31,dy+12,2,3,'#8a5236');R(cx+25,dy+12,2,3,'#8a5236');
  R(cx+12,dy-11,15,11,'#8a93a6');R(cx+13,dy-10,13,9,st==='home'?'#c9cfd8':'#eef1f6');R(cx+18,dy-7,3,3,'#ff8fb1');R(cx+10,dy-1,19,1,'#8a93a6');
  R(cx-28,dy-5,10,5,'#ffd34d');R(cx-27,dy-4,8,2,'#fff1b8');
  const stx=st==='work'?d.st:st==='late'?'야근 중':'퇴근';
  L(cx-2,dy+15,`★ <span>${who(d)}</span> · ${stx}`,'plate boss'+(st==='home'?' off':''),'c',d.col);
  if(st==='work'&&BUB[d.k])L(cx+24,dy-5,BUB[d.k],'bub','l');
  else if(st==='home')L(cx-2,dy-24,'🏠 퇴근','tag');
}
function officeCY(){
  cyFrame();cyHeader(`MINI ROOM · <b>${ESC(COMPANY)}</b> 미니룸`);
  poly([[12,28],[388,28],[354,42],[46,42]],'#fde7ef');
  poly([[12,28],[46,42],[46,112],[12,198]],'#f7c3d4');poly([[388,28],[354,42],[354,112],[388,198]],'#f7c3d4');
  R(46,42,308,70,'#fcd9e5');
  for(let y=48;y<108;y+=12)for(let x=52+((y/12)%2?6:0);x<350;x+=12)heart(x,y,'#f9c6d7');
  poly([[46,112],[354,112],[388,198],[12,198]],'#efd2a8');
  for(let y=118;y<198;y+=8){const l=46-(y-112)*34/86,r=354+(y-112)*34/86;R(l,y,r-l,1,'#e2bf8f');}
  for(let k=1;k<8;k++){const tx=46+k*38.5,bx=12+k*47;for(let y=112;y<198;y+=1){const xx=tx+(bx-tx)*(y-112)/86;if((y%8)<4)R(xx,y,1,1,'#e6c597');}}
  R(46,110,308,2,'#e6a3b9');
  // 창문
  R(58,50,52,40,'#ffffff');R(60,52,48,36,NIGHT?'#2a2f6a':'#bfe6ff');
  if(NIGHT){R(96,56,6,6,'#fff6c8');R(98,55,5,5,'#2a2f6a');[[66,58],[78,70],[88,62],[70,80]].forEach(s=>R(s[0],s[1],1,1,'#fff'));}else{ell(74,62,8,3,'#fff');ell(92,74,6,2,'#fff');}
  R(83,52,2,36,'#ffffff');R(60,69,48,2,'#ffffff');R(54,48,4,46,'#ff9fbf');R(110,48,4,46,'#ff9fbf');
  // 보드 (코르크)
  R(122,44,148,64,'#c98a6a');R(124,46,144,60,'#ecd2a6');
  BOX(124,46,144,60,boardHTML(),'brd');
  // 시계
  ell(292,62,13,13,'#ff8fb1');ell(292,62,11,11,'#ffffff');
  for(let k=0;k<12;k++){const a=k/12*Math.PI*2;R(292+Math.sin(a)*9,62-Math.cos(a)*9,1,1,'#ff8fb1');}
  const hA=((T%12)/12)*Math.PI*2,mA=((T%1))*Math.PI*2;
  for(let r=0;r<6;r++)R(292+Math.sin(hA)*r,62-Math.cos(hA)*r,1,1,'#3a3550');for(let r=0;r<8;r++)R(292+Math.sin(mA)*r,62-Math.cos(mA)*r,1,1,'#3a3550');R(291,61,2,2,'#e2457a');
  BOX(272,76,40,9,clockHTML().replace(/<span>.*<\/span>/,''),'clk');
  // 쪽지함
  R(318,54,28,24,'#e2457a');R(320,56,24,20,'#ff8fb1');R(318,52,28,3,'#c9346a');heart(328,64,'#ffffff');R(324,59,16,2,'#c9346a');R(346,56,2,12,'#8a5a3a');R(346,56,6,4,'#ffd34d');
  L(332,80,'쪽지함'+EM(NOTEN),'tagw');
  // 방명록 메모 탁자
  R(18,180,30,3,'#ffffff');R(18,183,30,1,'#e6a3b9');R(22,184,2,10,'#e6a3b9');R(42,184,2,10,'#e6a3b9');R(24,173,18,8,'#fffbe0');R(24,173,18,1,'#e8c86a');R(26,175,12,1,'#e8c86a');R(26,177,10,1,'#e8c86a');R(40,171,2,7,'#ff7a1a');
  L(33,165,'방명록 메모'+EM(MEMON),'tagw');
  // 러그 + 화분 + 곰인형
  ell(200,170,122,22,'#f48fb1');ell(200,170,119,20,'#fbc4d8');for(let k=0;k<60;k++){const a=k/60*Math.PI*2;if(k%2)R(200+Math.cos(a)*112,170+Math.sin(a)*17,2,1,'#ffffff');}
  plant(360,150,'#ff9fbf');
  // 자리
  [[78,146,1],[166,146,2],[254,146,3],[338,146,4],[100,186,5],[308,186,6]].forEach(s=>cyDesk(s[0],s[1],D[s[2]]));cyBoss(204,184,D[0]);
  nightPass('#1a1650',.5,[12,28,376,170]);
  dialog(12,209,376,21);
}
function cyHouse(x,y,d,i){
  const st=state(d),mode=homeMode(d,i);
  const pastel=['#ffd1dc','#d6f0ff','#e6d8ff','#fff1b8','#d8f5df','#ffe0c2','#f1f1f6'][i];
  poly([[x-3,y+11],[x+6,y],[x+34,y],[x+43,y+11]],'#6b5a7a');poly([[x-1,y+10],[x+7,y+1],[x+33,y+1],[x+41,y+10]],d.col);
  R(x,y+10,40,18,'#6b5a7a');R(x+1,y+10,38,17,pastel);
  R(x+5,y+13,11,9,'#ffffff');heart(x+7,y+15,'#ff8fb1');
  R(x+25,y+15,9,12,'#b98a6a');R(x+26,y+16,7,11,'#d6a77e');R(x+31,y+21,1,1,'#ffd34d');
  if(d.vacant){L(x+20,y+30,'빈 집','home off','c','#9aa3b1');return;}
  L(x+20,y+30,nw(d),'home','c',d.col);
  if(st==='work')L(x+20,y+38,'🏢 출근 중','chip');
  else if(st==='late')L(x+20,y+38,'🖥 미니룸 야근','chip late');
  else{
    L(x+20,y+38,mode==='zz'?'💤 자는 중':'🏠 집 앞','chip');
    lit(()=>{R(x+6,y+14,9,7,'#ffe9a8');heart(x+7,y+15,'#ff8fb1');glow(x+20,y+20,20,'rgba(255,220,180,1)',.35);if(mode==='front'){R(x+26,y+16,7,11,'#ffe9a8');minimi(x+40,y+9,d.m);}});
    if(mode==='zz')L(x+38,y-8,'z z','zz');
  }
}
function villageCY(){
  cyFrame();cyHeader(`<b>${ESC(COMPANY)}</b> 미니홈피 동네 · 일촌 ${STAFF}명`);
  const top=27,bot=230;
  for(let y=top;y<132;y++){const t=(y-top)/(105);const c=NIGHT?mix('#151a46','#4a3f80',t):mix('#8fd0ff','#e6f6ff',t);R(8,y,384,1,c);}
  if(NIGHT){lit(()=>{for(let k=0;k<40;k++)R(12+(k*97)%376,30+(k*37)%60,1,1,'#ffffff');ell(360,44,7,7,'#fff6c8');ell(363,42,6,6,mix('#151a46','#4a3f80',.15));});}
  else{[[60,40],[150,52],[250,38],[340,56]].forEach(c=>{ell(c[0],c[1],14,5,'#ffffff');ell(c[0]+8,c[1]-3,9,5,'#ffffff');});R(372,34,10,10,'#ffe27a');}
  // 언덕
  for(let x=8;x<392;x++){const h=96+Math.round(5*Math.sin(x/38));R(x,h,1,140-h,NIGHT?'#7fb08a':'#bde5a5');R(x,h,1,2,NIGHT?'#9cc8a2':'#d6f2c6');}
  const hx=[16,70,124,178,232,286,340];
  D.forEach((d,i)=>{const base=96+Math.round(5*Math.sin((hx[i]+20)/38));cyHouse(hx[i],base-24,d,i);});
  // 울타리
  R(8,138,384,14,NIGHT?'#6d9a78':'#a6dc8f');for(let x=10;x<392;x+=6){R(x,132,3,10,'#ffffff');R(x,131,3,1,'#e6e6f0');}R(8,135,384,1,'#ffffff');
  // 앞줄 건물
  R(8,200,384,30,'#f6d4e2');for(let x=8;x<392;x+=12)for(let y=202;y<230;y+=8)R(x+((y/8)%2?6:0),y,5,1,'#efb8cf');
  const win=(x,y,c)=>{R(x,y,8,7,'#ffffff');R(x+1,y+1,6,5,c||'#bfe6ff');};
  // 미니룸 오피스
  R(22,140,86,60,'#e2457a');R(24,142,82,58,'#ffb3c8');poly([[20,142],[65,128],[110,142]],'#e2457a');
  for(let r=0;r<3;r++)for(let c=0;c<5;c++){win(29+c*15,156+r*12);if(NIGHT&&r===1&&c<3)lit(()=>{R(30+c*15,157+12,6,5,'#ffe9a8');});}
  R(56,186,18,14,'#c9346a');R(58,188,14,12,'#ffd6e4');heart(62,132,'#ffffff');
  BOX(30,143,70,9,`<div class="bld" style="text-align:center">MINI ROOM 오피스</div>`,'');
  L(65,202,'🏢 오피스 들어가기','btn');
  // 본사
  R(118,150,70,50,'#2c6fd5');R(120,152,66,48,'#a9c9ff');poly([[114,152],[153,136],[192,152]],'#2c6fd5');
  for(let k=0;k<5;k++)R(124+k*13,158,5,40,'#ffffff');R(144,184,18,16,'#1a4a99');R(146,140,14,8,'#ffffff');R(148,142,10,4,'#ffd34d');
  L(153,202,'🏛 본사 (파일 보기)','btn bl');
  // 쪽지 우체국
  R(198,160,50,40,'#ff9a3a');R(200,162,46,38,'#ffd9a8');R(196,156,54,6,'#ff7a1a');R(210,166,26,14,'#ffffff');poly([[210,166],[223,174],[236,166]],'#ff9a3a');R(216,186,14,14,'#c95500');
  L(223,202,'✉ 쪽지 우체국','bld');
  // 사진첩 도서관
  R(256,156,56,44,'#8a6ad6');R(258,158,52,42,'#e2d6ff');R(254,152,60,6,'#8a6ad6');
  [[262,164,'#ffb3c8'],[278,166,'#bfe6ff'],[294,163,'#fff1b8']].forEach(p=>{R(p[0],p[1],12,12,'#ffffff');R(p[0]+1,p[1]+1,10,8,p[2]);});R(276,184,16,16,'#6a4ab6');
  L(284,202,'📷 사진첩 도서관','bld');
  // 방명록 게시판
  R(322,162,58,28,'#c98a6a');R(324,164,54,24,'#fffbe0');R(328,168,30,2,'#ff7a1a');R(328,173,44,1,'#e8c86a');R(328,177,40,1,'#e8c86a');R(328,181,34,1,'#e8c86a');R(330,190,3,10,'#c98a6a');R(369,190,3,10,'#c98a6a');
  L(351,202,'📋 방명록 게시판','bld');
  // 가로등
  [112,192,250,316,386].forEach(x=>{R(x,170,1,30,'#8a93a6');R(x-2,168,5,3,'#8a93a6');if(NIGHT)lit(()=>{R(x-1,170,3,1,'#fff3b0');glow(x,176,16,'rgba(255,230,170,1)',.55);});});
  if(!NIGHT){minimi(96,212,{hair:'#5a3a2a',style:'long',shirt:'#9ec0ee',ribbon:'#ffd34d'});minimi(114,212,{hair:'#2a2a3a',shirt:'#ffd9a8'});L(132,216,'일촌 산책 중 ♪','bub','l');
    L(330,212,'🌰 도토리 12개','tagw');}
  else L(200,216,'🌙 밤이 되면 일촌들은 집으로 · 야근 부서만 미니룸 불이 켜져요','note');
  BOX(14,30,124,22,`<div class="note">6시가 지나면 모두 집으로 퇴근 ♡<br>일을 시키면 그 부서만 미니룸에서 야근</div>`,'');
  nightPass('#1a1650',.45,[8,27,384,203]);
}

/* ══════════ 휴대폰 배치 (2026-11-01 대표님) — 위에서부터 진행 보드 · 매니저 · 직원(한 줄에 3~4명) ══════════ */
const MC={hq:{sw:92,top:34,bot:24,km:1.5,mH:165},village:{sw:90,top:42,bot:24,km:1.5,mH:96},cyworld:{sw:50,top:38,bot:30,km:1.75,mH:130}};
const q4=v=>Math.round(v*4)/4;
function mobPlan(){
  const c=MC[C],list=D.slice(1).filter(d=>!d.vacant),n=list.length,per=n&&n%4===0?4:3,cw=392/per;
  const k=Math.max(.75,Math.floor(Math.min(cw*.9/c.sw,c.km)*4)/4);
  const rowH=(c.top+c.bot)*k+14,rows=Math.ceil(n/per),WALL=204;
  const need=WALL+12+c.mH+14+Math.max(rows,1)*rowH+(EXTRA?18:0)+12+62+104;
  return {c,list,n,per,cw,k,rowH,rows,WALL,need};
}
function mobBody(P,mgr,seat,dx){
  const gap=Math.max(0,MH-P.need)/2,ym=P.WALL+12,ys=ym+P.c.mH+14+gap;
  mgr(ym);
  P.list.forEach((d,i)=>{const r=Math.floor(i/P.per),c=i%P.per,cnt=Math.min(P.per,P.n-r*P.per);
    xf(q4(4+(P.per-cnt)*P.cw/2+c*P.cw+(P.cw-P.c.sw*P.k)/2),q4(ys+r*P.rowH+P.c.top*P.k),P.k);seat(d);});
  xf(0,0,1);
  const ye=ys+Math.max(P.rows,1)*P.rowH;
  if(!P.n)L(200,ys+20,'부서를 만들면 여기에 직원 자리가 생겨요','tagw','c');
  if(EXTRA)L(200,ye,`+${EXTRA}개 부서 더`,'tagw','c');
  return ye+(EXTRA?18:0)+12+gap;
}
function mobHQ(){
  const P=mobPlan(),W=P.WALL;
  R(0,0,400,W,'#eef0f4');R(0,0,400,3,'#dfe3ea');
  R(4,4,392,136,'#2a3550');R(6,6,388,132,'#f9fafc');BOX(6,6,388,132,boardHTML(),'brd');
  winCity(16,152,62,36);
  R(104,150,74,36,'#2a2e36');R(106,152,70,32,'#101317');BOX(106,152,70,32,clockHTML(),'clk');
  xf(-120,143,1);
  R(340,7,24,32,'#7a5a3a');R(342,11,20,26,'#fffdf4');R(347,5,10,4,'#9aa3b1');for(let i=0;i<5;i++)R(344,20+i*3,16,1,'#c9cfd8');R(344,13,7,6,'#ffe27a');R(353,13,6,5,'#ffb3c8');
  L(352,41,'메모장'+EM(MEMON),'tagw');
  xf(-68,143,1);
  R(368,9,28,32,'#5b6475');for(let r=0;r<3;r++)for(let c=0;c<2;c++){R(370+c*13,11+r*10,11,8,'#2d3340');}
  R(372,13,8,5,'#ffffff');R(385,23,8,5,'#ffe27a');R(372,33,8,5,'#cfe8ff');R(373,14,2,1,'#e2525c');
  L(382,43,'우편함'+EM(NOTEN),'tagw');
  xf(0,0,1);plant(368,176);
  for(let y=W;y<MH;y+=8)for(let x=0;x<400;x+=8)R(x,y,8,8,((x+y)/8)%2?'#d3d8e0':'#dbdfe6');
  R(0,W-4,400,4,'#a9b0bc');
  const yd=mobBody(P,ym=>{xf(q4(200-51*1.25),q4(ym-62*1.25),1.25);mgrHQ(D[0]);},d=>cubicle(0,0,d));
  nightPass('#0c1230',.55);
  dialog(6,yd,388,62);
}
function mobVIL(){
  const P=mobPlan(),W=P.WALL;
  for(let y=0;y<W;y+=7){R(0,y,400,6,'#a86d40');R(0,y+6,400,1,'#7a4a28');R(0,y+1,400,1,'#b97d4d');for(let k=(y*13)%60;k<400;k+=70)R(k,y+2,3,2,'#8a5530');}
  R(4,4,392,136,'#6b4226');R(7,7,386,130,'#d8a866');for(let k=0;k<200;k++)R(8+(k*37)%384,8+(k*17)%128,1,1,'#c4925a');
  BOX(7,7,386,130,boardHTML(),'brd');
  winForest(16,152,56,32);
  xf(-166,140,1);
  R(287,3,10,5,'#5f9a3a');R(284,5,5,3,'#4a8a34');R(266,8,52,30,'#6b4226');R(269,11,46,24,'#fff3dc');BOX(269,11,46,24,clockHTML(),'clk');
  xf(-138,138,1);
  R(328,8,28,36,'#4a3426');R(330,10,24,32,'#fffaf0');for(let i=0;i<7;i++){R(331,13+i*4,2,2,'#4a3426');R(336,14+i*4,15,1,'#e3d4b8');}R(347,40,3,7,'#e2525c');R(338,16,9,5,'#ffd34d');
  L(342,46,'메모장'+EM(MEMON),'tagw');
  xf(-83,84,1);
  R(377,82,4,22,'#6b4226');R(365,66,28,18,'#4a3426');R(366,67,26,16,'#e2525c');R(368,65,22,2,'#4a3426');R(370,72,18,2,'#a83a40');R(393,66,2,12,'#6b4226');R(393,66,7,4,'#ffd34d');R(372,62,8,4,'#ffffff');
  L(379,105,'우편함'+EM(NOTEN),'tagw');
  xf(0,0,1);plant(374,174,'#d9774a');
  for(let y=W;y<MH;y+=8){R(0,y,400,8,'#e3b47d');R(0,y+7,400,1,'#c99860');for(let x=((y-W)/8)%2?0:24;x<400;x+=48)R(x,y,1,7,'#c99860');}
  R(0,W-3,400,3,'#6b4226');
  const yd=mobBody(P,ym=>{xf(q4(200-60*1.5),q4(ym+37*1.5),1.5);bossVIL(0,0,120,D[0]);},d=>deskVIL(0,0,90,d,[45,-40,'c']));
  nightPass('#14203f',.5);
  dialog(6,yd,388,62);
}
function mobCY(){
  const P=mobPlan(),W=P.WALL;
  R(0,0,400,MH,'#2c6fd5');for(let y=1;y<MH;y+=6)for(let x=((y-1)/6)%2?4:1;x<400;x+=6)R(x,y,2,2,'#4a88e2');
  R(5,3,390,MH-6,'#9ec0ee');R(6,4,388,MH-8,'#ffffff');
  R(10,8,380,W-8,'#fcd9e5');for(let y=14;y<W-8;y+=12)for(let x=16+((y/12)%2?6:0);x<384;x+=12)heart(x,y,'#f9c6d7');
  R(10,W,380,MH-W-10,'#efd2a8');for(let y=W+6;y<MH-10;y+=8)R(10,y,380,1,'#e2bf8f');R(10,W-2,380,2,'#e6a3b9');
  R(12,10,376,132,'#c98a6a');R(14,12,372,128,'#ecd2a6');BOX(14,12,372,128,boardHTML(),'brd');
  xf(-34,102,1);
  R(58,50,52,40,'#ffffff');R(60,52,48,36,NIGHT?'#2a2f6a':'#bfe6ff');
  if(NIGHT){R(96,56,6,6,'#fff6c8');R(98,55,5,5,'#2a2f6a');[[66,58],[78,70],[88,62],[70,80]].forEach(s=>R(s[0],s[1],1,1,'#fff'));}else{ell(74,62,8,3,'#fff');ell(92,74,6,2,'#fff');}
  R(83,52,2,36,'#ffffff');R(60,69,48,2,'#ffffff');R(54,48,4,46,'#ff9fbf');R(110,48,4,46,'#ff9fbf');
  xf(-142,104,1);
  ell(292,62,13,13,'#ff8fb1');ell(292,62,11,11,'#ffffff');
  for(let k=0;k<12;k++){const a=k/12*Math.PI*2;R(292+Math.sin(a)*9,62-Math.cos(a)*9,1,1,'#ff8fb1');}
  const hA=((T%12)/12)*Math.PI*2,mA=((T%1))*Math.PI*2;
  for(let r=0;r<6;r++)R(292+Math.sin(hA)*r,62-Math.cos(hA)*r,1,1,'#3a3550');for(let r=0;r<8;r++)R(292+Math.sin(mA)*r,62-Math.cos(mA)*r,1,1,'#3a3550');R(291,61,2,2,'#e2457a');
  BOX(272,76,40,9,clockHTML().replace(/<span>.*<\/span>/,''),'clk');
  xf(-98,98,1);
  R(318,54,28,24,'#e2457a');R(320,56,24,20,'#ff8fb1');R(318,52,28,3,'#c9346a');heart(328,64,'#ffffff');R(324,59,16,2,'#c9346a');R(346,56,2,12,'#8a5a3a');R(346,56,6,4,'#ffd34d');
  L(332,80,'쪽지함'+EM(NOTEN),'tagw');
  xf(282,-13,1);
  R(18,180,30,3,'#ffffff');R(18,183,30,1,'#e6a3b9');R(22,184,2,10,'#e6a3b9');R(42,184,2,10,'#e6a3b9');R(24,173,18,8,'#fffbe0');R(24,173,18,1,'#e8c86a');R(26,175,12,1,'#e8c86a');R(26,177,10,1,'#e8c86a');R(40,171,2,7,'#ff7a1a');
  L(33,165,'방명록 메모'+EM(MEMON),'tagw');
  xf(0,0,1);
  const yd=mobBody(P,ym=>{xf(200,q4(ym+42*1.75),1.75);ell(0,6,52,11,'#f48fb1');ell(0,6,49,9,'#fbc4d8');cyBoss(0,0,D[0]);},d=>cyDesk(26,0,d));
  nightPass('#1a1650',.5);
  dialog(12,yd,376,62);
}
function mix(a,b,t){const p=s=>[1,3,5].map(i=>parseInt(s.substr(i,2),16));const A=p(a),B=p(b);return 'rgb('+A.map((v,i)=>Math.round(v+(B[i]-v)*t)).join(',')+')';}

/* ── 실행 — 데이터 읽기 · 다시 그리기 ── */
const F={hq:{office:officeHQ,village:villageHQ},village:{office:officeVIL,village:villageVIL},cyworld:{office:officeCY,village:villageCY}};
const MF={hq:mobHQ,village:mobVIL,cyworld:mobCY};
function render(){
  syncMode();clock();recompute();
  g.setTransform(1,0,0,1,0,0);g.globalAlpha=1;g.globalCompositeOperation='source-over';g.clearRect(0,0,cv.width,cv.height);
  ov.innerHTML='';LATE.length=0;xf(0,0,1);
  topbar();(MOB?MF[C]:F[C][S])();
}
const strip=s=>String(s||'').replace(/^\s*(\d{2}|MY)\s+/,'').trim();
function readParent(){
  try{
    const P=parent.document,ts=P.querySelectorAll('#stream .turn');
    const t=ts[ts.length-1];
    if(t){const b=t.querySelector('.bubble');LAST={who:t.classList.contains('me')?CALL:CHIEF,text:(b&&b.innerText||'').replace(/^📋[^\n]*\n/,'')};}
  }catch(e){}
}
async function J(u){try{const r=await fetch(u,{credentials:'same-origin',cache:'no-store'});return r.ok?await r.json():null;}catch(e){return null;}}
async function load(){
  const [o,td,mm,nt]=await Promise.all([J('/api/office'),J('/api/todo'),J('/api/memos'),J('/api/notices')]);
  BUSY=new Map();DONE=new Set();
  if(o){(o.working||[]).forEach(w=>{const n=strip(w.dept);const d=D.find(x=>!x.vacant&&x.name===n);BUSY.set(d?d.name:D[0].name,w);});
    const now=Date.now()/1000;(o.done||[]).forEach(w=>{if(now-(w.ts||0)<3600)DONE.add(strip(w.dept));});}
  if(td){const it=(td.items||[]).filter(i=>!i.checked&&BUCK[i.bucket]&&!i.personal);
    const ord=['today','tomorrow','sched','week'];it.sort((a,b)=>ord.indexOf(a.bucket)-ord.indexOf(b.bucket));
    CARDS=it.map(i=>[BUCK[i.bucket][0],i.text||'',i.due?('마감 '+i.due.slice(5).replace('-','/')):(i.bucket==='today'&&i.since&&i.since<td.today?'밀린 일':(i.note||'')).slice(0,30)]);
    CARDN=it.length;TODAYN=it.filter(i=>i.bucket==='today').length;TOTALN=(td.items||[]).length;}
  if(mm)MEMON=(mm.memos||[]).length;
  if(nt){const seen=(()=>{try{return parent.localStorage.getItem('noticeSeen')||'';}catch(e){return '';}})();NOTEN=(nt.items||[]).filter(x=>x.t>seen).length;}
  readParent();render();
}
document.addEventListener('click',e=>{
  const a=e.target.closest('a,[data-s],.lb');if(!a)return;
  if(a.dataset.s){e.preventDefault();S=a.dataset.s;localStorage.setItem('osvScene',S);render();return;}
  if(a.dataset.go==='chat'){e.preventDefault();if(parent.OSV_close)parent.OSV_close();return;}
  const t=a.textContent||'';
  if(/오피스 들어가기/.test(t)){S='office';localStorage.setItem('osvScene',S);render();return;}
  if(/본사|파일 보기/.test(t)){if(parent.OSV_files)parent.OSV_files();return;}
  if(/메모장|방명록 메모/.test(t)){if(parent.OSV_memo)parent.OSV_memo();return;}
  if(/우편함|쪽지함/.test(t)){if(parent.OSV_bell)parent.OSV_bell();return;}
  const sp=a.classList.contains('plate')||a.classList.contains('home')?a.querySelector('span'):null;
  if(sp&&parent.OSV_ask){const d=D.find(x=>x.name===sp.textContent&&!x.vacant);if(d)parent.OSV_ask(d===D[0]?'':d.name);}
});
// 화면 크기에 맞추기 — 컴퓨터는 한 화면에 꼭 맞게. 휴대폰 오피스는 세로 배치(보드 · 매니저 · 직원 3~4명씩)로 폭에 맞추고,
// 휴대폰 마을은 전체가 잘리지 않게 작게 (2026-11-01 대표님)
function syncMode(){
  const W=innerWidth,H=innerHeight,ph=W<700,mob=ph&&S==='office',B=document.body,st=document.getElementById('stage');
  const z=mob?W/1600:Math.min(W/1600,H/1000);
  const de=document.documentElement;de.classList.toggle('ph',ph);de.classList.toggle('mob',mob);
  B.style.zoom=z;B.style.marginTop=(ph&&!mob)?Math.max(0,(H-1000*z)/2/z)+'px':'';
  const mh=mob?Math.max(Math.ceil(mobPlan().need),Math.floor((H/z-168)/4)):236;
  if(mob===MOB&&mh===MH)return false;
  MOB=mob;PX=mob?4:1;MH=mh;cv.width=mob?1600:400;cv.height=mob?MH*4:236;
  const hh=mob?MH*4+'px':'';cv.style.height=hh;st.style.height=hh;B.style.height=mob?(168+MH*4)+'px':'';
  return true;
}
function fit(){if(syncMode())render();}
addEventListener('resize',fit);
// 휴대폰 — 앱 쪽 '마을/오피스' 단추가 부른다
window.OSV_toggle=()=>{S=S==='office'?'village':'office';localStorage.setItem('osvScene',S);render();fit.done=0;fit();return S;};
window.OSV_scene=()=>S;
render();fit();load();
setInterval(load,20000);
try{const P=parent.document;const mo=new MutationObserver(()=>{clearTimeout(load.t);load.t=setTimeout(load,600);});
  ['what','tag','stream'].forEach(id=>{const el=P.getElementById(id);if(el)mo.observe(el,{childList:true,characterData:true,subtree:id!=='stream'});});}catch(e){}
})();
