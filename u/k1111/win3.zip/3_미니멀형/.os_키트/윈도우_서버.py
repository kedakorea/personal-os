# -*- coding: utf-8 -*-
"""퍼스널 OS 앱 서버 — 윈도우 감싸개 (2026-10-24)
elvin_server.py 는 맥 기준이라, 윈도우에 없는 기능(프로세스 묶음 끝내기·새 세션으로 띄우기)을 윈도우 것으로 바꿔 끼운 뒤 그대로 실행한다.
시작 프로그램의 퍼스널OS_서버.vbs 가 pythonw 로 부른다(창 없이). 로그: .os_데이터/앱.log"""
import os, sys, subprocess, runpy

KIT = os.path.dirname(os.path.abspath(__file__))
OS_DIR = os.path.dirname(KIT)
sys.path.insert(0, OS_DIR)                       # fcntl 대역(fcntl.py)·elvin_todo 를 찾게
os.chdir(OS_DIR)
os.environ.setdefault("PYTHONUTF8", "1")
LOCALBIN = os.path.join(os.path.expanduser("~"), ".local", "bin")
os.environ["PATH"] = LOCALBIN + os.pathsep + os.environ.get("PATH", "")

log = open(os.path.join(OS_DIR, ".os_데이터", "앱.log"), "a", encoding="utf-8", buffering=1)
sys.stdout = sys.stderr = log                    # pythonw 는 화면이 없으니 기록 파일로

NEW_GROUP, NO_WINDOW = 0x00000200, 0x08000000


def killpg(pid, sig):
    subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"], capture_output=True, creationflags=NO_WINDOW)
os.killpg = killpg

_Popen = subprocess.Popen
class Popen(_Popen):
    def __init__(self, *a, **k):
        if k.pop("start_new_session", False):
            k["creationflags"] = k.get("creationflags", 0) | NEW_GROUP
        k["creationflags"] = k.get("creationflags", 0) | NO_WINDOW     # 검은 창이 뜨지 않게
        if k.get("text") or k.get("universal_newlines"):
            k.setdefault("encoding", "utf-8"); k.setdefault("errors", "replace")
        super().__init__(*a, **k)
subprocess.Popen = Popen

_run = subprocess.run
def run(*a, **k):
    if k.get("text") or k.get("universal_newlines"):
        k.setdefault("encoding", "utf-8"); k.setdefault("errors", "replace")
    return _run(*a, **k)
subprocess.run = run

sys.argv = [os.path.join(OS_DIR, "elvin_server.py")] + sys.argv[1:]
runpy.run_path(sys.argv[0], run_name="__main__")
