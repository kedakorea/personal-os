#!/usr/bin/env python3
"""카드뉴스 → 세로 숏폼(1080×1920) — 퍼스널 OS 교안 실습 '카드뉴스→숏폼' 단계 (2026-11-07)
사용: python3 카드뉴스_숏폼.py 카드폴더 결과.mp4 [--초 2.6] [--음악 bgm.mp3]
  카드폴더의 01.jpg, 02.jpg … 를 순서대로, 카드마다 살짝 줌인 + 다음 카드로 부드럽게 넘김.
  바탕은 카드를 흐리게 키운 것(위아래 빈 곳이 어색하지 않게). 음악이 있으면 깔고 끝에서 줄인다.
"""
import argparse, glob, os, subprocess, tempfile
from PIL import Image, ImageFilter, ImageEnhance
import imageio_ffmpeg

W, H, FPS = 1080, 1920, 30
BGM = os.path.join(os.path.dirname(os.path.abspath(__file__)), "숏폼_배경음악.mp3")

ap = argparse.ArgumentParser()
ap.add_argument("folder"); ap.add_argument("out")
ap.add_argument("--초", dest="sec", type=float, default=2.6)
ap.add_argument("--음악", dest="music", default=BGM)
a = ap.parse_args()

cards = sorted(f for f in glob.glob(os.path.join(glob.escape(a.folder), "[0-9][0-9].jpg")))
if not cards:
    raise SystemExit("카드(01.jpg …)가 없습니다")
FADE = 0.35
per = int(a.sec * FPS); fade = int(FADE * FPS)


def frame_for(img, t):
    """t: 0~1 카드 안 진행도 → 줌 1.00→1.04"""
    z = 1.0 + 0.04 * t
    bg = img.resize((int(H * img.width / img.height * 1.0), H), Image.LANCZOS)
    bg = bg.crop(((bg.width - W) // 2, 0, (bg.width - W) // 2 + W, H)).filter(ImageFilter.GaussianBlur(40))
    bg = ImageEnhance.Brightness(bg).enhance(0.55)
    cw = int(W * z); ch = int(img.height * cw / img.width)
    card = img.resize((cw, ch), Image.LANCZOS)
    bg.paste(card, ((W - cw) // 2, (H - ch) // 2))
    return bg


imgs = [Image.open(c).convert("RGB") for c in cards]
tmp = tempfile.mkdtemp()
silent = os.path.join(tmp, "v.mp4")
FF = imageio_ffmpeg.get_ffmpeg_exe()
p = subprocess.Popen([FF, "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                      "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "20", "-preset", "medium", silent], stdin=subprocess.PIPE)
for i, im in enumerate(imgs):
    for k in range(per):
        f = frame_for(im, k / per)
        if i + 1 < len(imgs) and k >= per - fade:  # 다음 카드로 넘김
            nxt = frame_for(imgs[i + 1], 0)
            f = Image.blend(f, nxt, (k - (per - fade)) / fade)
        p.stdin.write(f.tobytes())
# 마지막 카드 1초 더
last = frame_for(imgs[-1], 1.0)
for _ in range(FPS):
    p.stdin.write(last.tobytes())
p.stdin.close(); p.wait()

dur = (len(imgs) * per + FPS) / FPS
if a.music and os.path.exists(a.music):
    subprocess.run([FF, "-y", "-loglevel", "error", "-i", silent, "-stream_loop", "-1", "-i", a.music, "-t", f"{dur:.2f}",
                    "-filter_complex", f"[1:a]volume=0.6,afade=t=out:st={max(0, dur - 1.5):.2f}:d=1.5[a]",
                    "-map", "0:v", "-map", "[a]", "-c:v", "copy", "-c:a", "aac", "-b:a", "160k", "-shortest", a.out], check=True)
else:
    os.replace(silent, a.out)
print(f"{a.out}  ({len(imgs)}장, {dur:.1f}초)")
