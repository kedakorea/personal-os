/* 퍼스널 OS 채팅 테마 — 공통 (2026-10-28). 적용.py 가 window.OS_THEME = "<화면>" 과 함께 앱 화면 맨 끝에 붙인다.
   하는 일: ① body 에 ct · ct-<화면> 표시 ② 캐릭터형은 매니저 도트 얼굴(--ct-av)을 그려 말풍선 옆에 ③ 대화 머리에 매니저 이름
   ④ 매거진형·다이어리형은 컴퓨터에서 '대화 크게' 단추 ⑤ 주소 끝 #chat / #office 로 첫 화면 고르기 */
(function () {
  var B = document.body, K = window.OS_THEME || "", CHIEF = "{{실장}}", CALL = "{{호칭}}";
  B.classList.add("ct", "ct-" + K);
  B.style.setProperty("--ct-ini", JSON.stringify((CHIEF.trim() || "매").charAt(0)));
  var CHAR = { hq: 1, village: 1, cyworld: 1 };

  // ② 도트 얼굴 — 오피스 화면의 매니저와 같은 캐릭터
  function sprite(kind) {
    var c = document.createElement("canvas"), S = 4, N = 16, g, INK = "#2b2220";
    c.width = c.height = N * S; g = c.getContext("2d");
    var ox = 0, oy = 0;
    function R(x, y, w, h, col) { g.fillStyle = col; g.fillRect((x + ox) * S, (y + oy) * S, w * S, h * S); }
    function spr(p, ol) { p.forEach(function (q) { if (q[5] !== 0) R(q[0] - 1 / S, q[1] - 1 / S, q[2] + 2 / S, q[3] + 2 / S, ol); }); p.forEach(function (q) { R(q[0], q[1], q[2], q[3], q[4]); }); }
    if (kind === "village") {   // 강아지 매니저 (오피스 화면 매니저와 같은 색)
      var F = "#d9a066", M = "#f6e2c4", E = "#8a5a30"; ox = 4; oy = 3;
      spr([[1, 2, 8, 6, F], [1, 8, 8, 4, "#2b3a7a"], [-1, 3, 2, 5, E], [8, 3, 2, 5, E], [3, 5, 4, 3, M, 0], [3, 4, 1, 1, INK, 0], [6, 4, 1, 1, INK, 0], [4, 5, 2, 1, INK, 0], [2, 6, 1, 1, "#f4a3a3", 0], [7, 6, 1, 1, "#f4a3a3", 0], [3, 8, 4, 1, "rgba(255,255,255,.35)", 0]], "#3a2a20");
    } else if (kind === "cyworld") {   // 미니미 (리본)
      var H = "#3a2a22", Sk = "#fde2cc"; ox = 1; oy = 4;
      spr([[1, 0, 12, 4, H], [0, 2, 14, 4, H], [2, 3, 10, 7, Sk], [4, 10, 6, 2, "#2b3a7a"], [5, -3, 4, 3, H], [0, 4, 2, 3, H], [12, 4, 2, 3, H],
           [2, 3, 10, 1, H, 0], [2, 4, 4, 1, H, 0], [9, 4, 3, 1, H, 0], [4, 6, 1, 2, INK, 0], [9, 6, 1, 2, INK, 0], [6, 8, 2, 1, "#d0605a", 0], [3, 8, 1, 1, "#f6a6b2", 0], [10, 8, 1, 1, "#f6a6b2", 0], [10, -1, 3, 2, "#ff5c8a", 0], [11, 1, 1, 1, "#ff5c8a", 0]], "#3a3550");
    } else {   // 본사형 사람 (올림머리 · 남색 정장)
      var Hh = "#3a2a22", Ss = "#f3cfb0"; ox = 3; oy = 4;
      spr([[1, 1, 8, 3, Hh], [2, 0, 6, 1, Hh], [2, 3, 6, 5, Ss], [1, 8, 8, 4, "#2b3a7a"], [3, -2, 4, 2, Hh], [1, 3, 1, 2, Hh], [8, 3, 1, 2, Hh],
           [2, 3, 6, 1, Hh, 0], [3, 5, 1, 1, INK, 0], [6, 5, 1, 1, INK, 0], [2, 6, 1, 1, "#f2a1a1", 0], [7, 6, 1, 1, "#f2a1a1", 0], [4, 8, 2, 4, "#1e31ef", 0], [3, 8, 1, 1, "#fff", 0], [6, 8, 1, 1, "#fff", 0]], INK);
    }
    return c.toDataURL();
  }
  if (CHAR[K]) {
    try { B.style.setProperty("--ct-av", "url(" + sprite(K) + ")"); } catch (e) {}
    // ③ 대화 머리 — 얼굴 + 이름 (컴퓨터)
    var tb = document.getElementById("topbar"), what = document.getElementById("what");
    if (tb && what && !document.getElementById("ctHead")) {
      var h = document.createElement("span"); h.id = "ctHead"; h.className = "ct-head";
      h.innerHTML = '<i class="ct-av"></i><b></b>'; h.querySelector("b").textContent = CHIEF;
      tb.insertBefore(h, what);
    }
  }

  // ④ 대화 크게 (매거진형·다이어리형 — 컴퓨터에서 오른쪽 좁은 대화칸을 넓게)
  if (K === "magazine" || K === "diary") {
    var bar = document.querySelector(".topbar .barright");
    if (bar) {
      var w = document.createElement("button"); w.type = "button"; w.className = "ct-wide-btn";
      var paint = function () { w.textContent = B.classList.contains("ct-wide") ? (K === "magazine" ? "📰 표지로" : "📒 플래너로") : "⤢ 대화 크게"; };
      w.onclick = function () { B.classList.toggle("ct-wide"); localStorage.setItem("ctWide", B.classList.contains("ct-wide") ? "1" : "0"); paint(); setTimeout(function () { window.dispatchEvent(new Event("resize")); }, 50); };
      bar.prepend(w);
      if (localStorage.getItem("ctWide") === "1") B.classList.add("ct-wide");
      paint();
      var hw = function () { if (location.hash === "#chat") B.classList.add("ct-wide"); else if (location.hash === "#office") B.classList.remove("ct-wide"); paint(); };
      addEventListener("hashchange", hw); hw();
    }
  }
})();
