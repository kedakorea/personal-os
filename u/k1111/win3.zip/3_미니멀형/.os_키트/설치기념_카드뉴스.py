#!/usr/bin/env python3
"""설치 기념 카드뉴스 (글·캡션에 AI가 만들었다는 티를 내지 않는다 — 2026-11-07 대표님)
설치 기념 카드뉴스 + 모션 숏폼 — 설치 날 실습용 고정 콘텐츠 (2026-11-07 대표님 지시)
"오늘 퍼스널 OS를 설치했더니 내 컴퓨터 안에 이런 부서와 직원이 생겼어요"
- 고객에게 아무것도 묻지 않는다. 설정.json(매니저·회사·화면) + 부서/부서표.json(부서·일·예) 만 읽는다.
- 등장 캐릭터는 그 고객 OS 화면의 실제 직원: 본사형(hq)=사람 · 동물의숲형(village)=동물 · 싸이월드형(cyworld)=미니미
  (모양은 오피스마을_엔진.js 의 직원 표를 그대로 읽는다). 캐릭터가 없는 화면이면 단순한 동그라미 직원.
- 카드(정지 그림)와 영상(캐릭터가 걸어 들어오고·뛰고·손 흔드는 모션)을 같은 장면 함수로 그린다.
사용: python3 설치기념_카드뉴스.py [퍼스널OS 폴더=~/퍼스널OS] [결과 폴더] [--영상만|--카드만]
결과: 01.jpg … (1080×1350) · 설치기념_01.mp4 (1080×1920) · 캡션.txt · 유튜브_제목.txt
"""
import json, math, os, re, subprocess, sys, tempfile, time
from PIL import Image, ImageDraw, ImageFont

ARGS = [a for a in sys.argv[1:] if not a.startswith("--")]
OS_DIR = os.path.expanduser(ARGS[0] if ARGS else "~/퍼스널OS")
OUT = ARGS[1] if len(ARGS) > 1 else os.path.join(OS_DIR, "결과물", "설치기념_" + time.strftime("%y%m%d"))
KIT = os.path.dirname(os.path.abspath(__file__))
os.makedirs(OUT, exist_ok=True)

c = json.load(open(os.path.join(OS_DIR, "설정.json"), encoding="utf-8"))
ds = json.load(open(os.path.join(OS_DIR, "부서", "부서표.json"), encoding="utf-8")).get("부서", [])
ds = [d for d in ds if not d["폴더"].startswith("00")] or ds  # 비서실(OS 관리)은 매니저로 소개
MGR = (c.get("실장") or "매니저").strip()
CO = (c.get("회사") or "").strip()
STYLE = (c.get("화면") or "").strip()
TODAY = time.strftime("%Y.%m.%d")

W, H = 1080, 1350
BG, INK, SUB, LINE = (250, 249, 246), (28, 28, 30), (120, 120, 126), (226, 224, 218)
PAL = [(255, 214, 102), (155, 214, 190), (160, 196, 255), (255, 170, 165), (200, 180, 255), (255, 196, 140), (170, 220, 120), (150, 210, 230)]


# ───────── 캐릭터 (오피스마을_엔진.js 의 직원 표·그리기 규칙을 그대로 옮김) ─────────
def _hex(s):
    s = s.strip()
    if s.startswith("#"):
        s = s[1:]
        if len(s) == 3: s = "".join(ch * 2 for ch in s)
        return tuple(int(s[i:i + 2], 16) for i in (0, 2, 4)) + (255,)
    m = re.match(r"rgba\(([\d.]+),([\d.]+),([\d.]+),([\d.]+)\)", s.replace(" ", ""))
    return (int(float(m[1])), int(float(m[2])), int(float(m[3])), int(float(m[4]) * 255))


def load_staff():
    try:
        s = open(os.path.join(KIT, "오피스마을_엔진.js"), encoding="utf-8").read()
        a = s.index("const D=[") + len("const D="); b = s.index("];", a) + 1
        t = re.sub(r"([{,])\s*(\w+):", r'\1"\2":', s[a:b]).replace("'", '"')
        return json.loads(re.sub(r",\s*\]", "]", t))
    except Exception:
        return None


STAFF = load_staff() if STYLE in ("hq", "village", "cyworld") else None
PINK, PK = "#f2a1a1", "#f4a3a3"


def parts_person(o):
    Hh, S, C, P, K = o["hair"], o.get("skin", "#f3cfb0"), o["shirt"], o.get("pants", "#3a3f52"), "#2b2220"
    p = [[1, 1, 8, 3, Hh], [2, 0, 6, 1, Hh], [2, 3, 6, 5, S], [1, 8, 8, 5, C], [3, 13, 2, 2, P], [5, 13, 2, 2, P], [2, 15, 3, 1, K], [5, 15, 3, 1, K]]
    p += [[1, 3, 1, 7, Hh], [8, 3, 1, 7, Hh]] if o.get("style") == "long" else [[1, 3, 1, 2, Hh], [8, 3, 1, 2, Hh]]
    if o.get("style") == "bun": p.append([3, -2, 4, 2, Hh])
    p += [[2, 3, 6, 1, Hh, 0], [3, 5, 1, 1, K, 0], [6, 5, 1, 1, K, 0], [2, 6, 1, 1, PINK, 0], [7, 6, 1, 1, PINK, 0], [1, 12, 1, 1, S, 0], [8, 12, 1, 1, S, 0],
          [2, 9, 1, 3, "rgba(0,0,0,.18)", 0], [7, 9, 1, 3, "rgba(0,0,0,.18)", 0]]
    p += [[4, 8, 2, 4, o["tie"], 0]] if o.get("tie") else [[3, 8, 1, 1, "#fff", 0], [6, 8, 1, 1, "#fff", 0]]
    if o.get("glasses"): p += [[2, 5, 2, 1, K, 0], [6, 5, 2, 1, K, 0], [4, 5, 2, 1, K, 0]]
    return p, "#2b2220"


def parts_animal(o):
    F, M, E, C, P, Kd, K = o["fur"], o["mz"], o.get("ear", o["fur"]), o["shirt"], o.get("pants", "#6b5440"), o["kind"], "#2b2220"
    p = []
    if Kd == "rabbit": p += [[2, -4, 2, 6, F], [6, -4, 2, 6, F]]
    if Kd == "cat": p += [[1, 0, 2, 3, F], [7, 0, 2, 3, F]]
    if Kd == "fox": p += [[1, -1, 2, 4, F], [7, -1, 2, 4, F]]
    if Kd in ("bear", "panda", "hamster"):
        e = K if Kd == "panda" else F; p += [[1, 1, 2, 2, e], [7, 1, 2, 2, e]]
    p += [[1, 2, 8, 6, F], [1, 8, 8, 5, C], [3, 13, 2, 2, P], [5, 13, 2, 2, P], [2, 15, 3, 1, F], [5, 15, 3, 1, F]]
    if Kd == "dog": p += [[-1, 3, 2, 5, E], [8, 3, 2, 5, E]]
    p += [[3, 5, 4, 3, M, 0], [3, 4, 1, 1, K, 0], [6, 4, 1, 1, K, 0], [4, 5, 2, 1, K, 0], [2, 6, 1, 1, PK, 0], [7, 6, 1, 1, PK, 0], [1, 12, 1, 1, F, 0], [8, 12, 1, 1, F, 0],
          [3, 8, 4, 1, "rgba(255,255,255,.35)", 0]]
    if Kd == "rabbit": p += [[3, -3, 1, 4, PK, 0], [6, -3, 1, 4, PK, 0]]
    if Kd == "cat": p += [[2, 1, 1, 1, PK, 0], [7, 1, 1, 1, PK, 0]]
    if Kd == "fox": p += [[1, -1, 2, 1, K, 0], [7, -1, 2, 1, K, 0]]
    if Kd == "panda": p += [[2, 4, 2, 2, K, 0], [6, 4, 2, 2, K, 0], [3, 4, 1, 1, "#fff", 0], [6, 4, 1, 1, "#fff", 0]]
    if Kd == "hamster": p += [[1, 5, 2, 2, "#f6c39a", 0], [7, 5, 2, 2, "#f6c39a", 0]]
    return p, "#3a2a20"


def parts_minimi(o):
    Hh, S, C, P, K = o["hair"], o.get("skin", "#fde2cc"), o["shirt"], o.get("pants", "#4a5a8a"), "#2b2220"
    p = [[1, 0, 12, 4, Hh], [0, 2, 14, 4, Hh], [2, 3, 10, 7, S], [4, 10, 6, 5, C], [3, 11, 1, 3, C], [10, 11, 1, 3, C], [5, 15, 2, 2, P], [7, 15, 2, 2, P], [4, 17, 3, 1, K], [7, 17, 3, 1, K]]
    p += [[0, 4, 2, 9, Hh], [12, 4, 2, 9, Hh]] if o.get("style") == "long" else [[0, 4, 2, 3, Hh], [12, 4, 2, 3, Hh]]
    if o.get("style") == "bun": p.append([5, -3, 4, 3, Hh])
    p += [[2, 3, 10, 1, Hh, 0], [2, 4, 4, 1, Hh, 0], [9, 4, 3, 1, Hh, 0], [4, 6, 1, 2, K, 0], [9, 6, 1, 2, K, 0], [6, 8, 2, 1, "#d0605a", 0], [3, 8, 1, 1, "#f6a6b2", 0],
          [10, 8, 1, 1, "#f6a6b2", 0], [3, 14, 1, 1, S, 0], [10, 14, 1, 1, S, 0], [6, 10, 2, 1, "#fff", 0]]
    if o.get("glasses"): p += [[3, 5, 3, 3, K, 0], [4, 6, 1, 1, "#cfe8ff", 0], [8, 5, 3, 3, K, 0], [9, 6, 1, 1, "#cfe8ff", 0], [6, 6, 2, 1, K, 0]]
    if o.get("ribbon"): p += [[10, -1, 3, 2, o["ribbon"], 0], [11, 1, 1, 1, o["ribbon"], 0]]
    return p, "#3a3550"


_SPR = {}


def sprite(idx, k):
    """idx 0 = 매니저, 1~ = 부서 순서. 엔진처럼 부서 6자리를 돌려 쓴다."""
    key = (idx, k)
    if key in _SPR: return _SPR[key]
    d = STAFF[0] if idx == 0 else STAFF[1 + (idx - 1) % 6]
    parts, ol = {"hq": lambda: parts_person(d["p"]), "village": lambda: parts_animal(d["a"]), "cyworld": lambda: parts_minimi(d["m"])}[STYLE]()
    pad = 6 * k
    im = Image.new("RGBA", (16 * k + 2 * pad, 22 * k + 2 * pad), (0, 0, 0, 0))
    ox, oy = pad + 2 * k, pad + 4 * k
    dr = ImageDraw.Draw(im)
    for p in parts:  # 테두리
        if len(p) < 6 or p[5] != 0:
            dr.rectangle([ox + p[0] * k - k // 2, oy + p[1] * k - k // 2, ox + (p[0] + p[2]) * k + k // 2 - 1, oy + (p[1] + p[3]) * k + k // 2 - 1], fill=_hex(ol))
    for p in parts:
        col = _hex(p[4]); box = [ox + p[0] * k, oy + p[1] * k, ox + (p[0] + p[2]) * k - 1, oy + (p[1] + p[3]) * k - 1]
        if col[3] < 255:
            lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); ImageDraw.Draw(lay).rectangle(box, fill=col); im = Image.alpha_composite(im, lay); dr = ImageDraw.Draw(im)
        else:
            dr.rectangle(box, fill=col)
    im = im.crop(im.getbbox())
    _SPR[key] = im
    return im


def staff(im, d, idx, x, y, s=1.0, hop=0.0, wave=False, ph=0.0):
    """직원 한 명 — (x,y)=발밑 가운데. hop: 위로 뜨는 픽셀, wave: 손 흔들기"""
    col = PAL[idx % len(PAL)]
    if STAFF:
        sp = sprite(idx, max(3, int(7 * s)))
        im.paste(sp, (int(x - sp.width / 2), int(y - sp.height - hop)), sp)
        if wave:
            hx, hy = x + sp.width / 2 + 6, y - sp.height * 0.62 - hop
            a = math.sin(ph * 10) * 10
            d.line([(hx - 8, hy + 22), (hx + a, hy - 14)], fill=INK, width=max(4, int(6 * s)))
    else:  # 캐릭터 없는 화면 — 단순화한 직원
        y2 = y - hop
        d.rounded_rectangle([x - 34 * s, y2 - 92 * s, x + 34 * s, y2 - 24 * s], radius=int(30 * s), fill=col)
        blink = (ph * 3) % 1 < 0.08
        for ex in (-12, 12):
            if blink: d.line([(x + (ex - 4) * s, y2 - 66 * s), (x + (ex + 4) * s, y2 - 66 * s)], fill=INK, width=3)
            else: d.ellipse([x + (ex - 4) * s, y2 - 70 * s, x + (ex + 4) * s, y2 - 62 * s], fill=INK)
        if wave:
            a = math.sin(ph * 10) * 10
            d.line([(x + 34 * s, y2 - 50 * s), (x + (54 + a) * s, y2 - 96 * s)], fill=col, width=int(12 * s))
    # 책상(발밑 그림자 겸)
    d.rectangle([x - 70 * s, y - 2, x + 70 * s, y + 14 * s], fill=INK)


# ───────── 그리기 도구 ─────────
_F = {}


def font(w, s):
    k = (w, s)
    if k in _F: return _F[k]
    for p in (f"~/Library/Fonts/Pretendard-{w}.otf", f"/Library/Fonts/Pretendard-{w}.otf",
              "C:/Windows/Fonts/malgunbd.ttf" if w in ("Bold", "ExtraBold") else "C:/Windows/Fonts/malgun.ttf",
              "/System/Library/Fonts/AppleSDGothicNeo.ttc"):
        p = os.path.expanduser(p)
        if os.path.exists(p):
            _F[k] = ImageFont.truetype(p, s); return _F[k]
    return ImageFont.load_default()


def wrap(d, text, f, width):
    """띄어쓰기 단위로 줄바꿈(낱말 중간에서 끊지 않음)"""
    out, cur = [], ""
    for w in text.split(" "):
        nxt = (cur + " " + w).strip()
        if d.textlength(nxt, font=f) > width and cur:
            out.append(cur); cur = w
        else:
            cur = nxt
    return out + ([cur] if cur else [])


def clamp(v): return max(0.0, min(1.0, v))
def ease(v): v = clamp(v); return 1 - (1 - v) ** 3
def back(v): v = clamp(v); c1 = 1.70158; return 1 + (c1 + 1) * (v - 1) ** 3 + c1 * (v - 1) ** 2


def text(im, xy, s, f, fill, a=1.0, dy=0, anchor="la"):
    if a <= 0: return
    if a >= 1 and dy == 0:
        ImageDraw.Draw(im).text(xy, s, font=f, fill=fill, anchor=anchor); return
    lay = Image.new("RGBA", im.size, (0, 0, 0, 0))
    ImageDraw.Draw(lay).text((xy[0], xy[1] + dy), s, font=f, fill=fill + (int(255 * a),), anchor=anchor)
    im.alpha_composite(lay)


def foot(im, n):
    d = ImageDraw.Draw(im)
    d.text((80, H - 90), f"{CO + ' · ' if CO else ''}퍼스널 OS 설치 첫날", font=font("Medium", 30), fill=SUB)
    d.text((W - 80, H - 90), f"{n}", font=font("Bold", 30), fill=SUB, anchor="ra")


# ───────── 장면 (t: 장면 안 시간(초), 정지 카드는 t=99) ─────────
def row_pos(i, n):
    cols = 4
    return 160 + (i % cols) * 253, 880 + (i // cols) * 220


def s_cover(im, t):
    d = ImageDraw.Draw(im)
    text(im, (80, 150), TODAY, font("Bold", 40), SUB, ease(t / 0.4))
    for i, s in enumerate(["오늘,", "내 컴퓨터에", "회사가 생겼어요"]):
        v = ease((t - 0.2 - i * 0.25) / 0.5)
        text(im, (80, 230 + i * 120), s, font("ExtraBold", 104), INK, v, dy=int(40 * (1 - v)))
    n = min(len(ds), 8)
    for i in range(n):
        x, y = row_pos(i, n)
        st = 0.9 + i * 0.12  # 하나씩 위에서 톡 떨어짐
        v = clamp((t - st) / 0.45)
        if v <= 0: continue
        drop = (1 - back(v)) * 260
        bob = abs(math.sin((t - st) * 5 + i)) * 10 if v >= 1 else 0
        staff(im, d, i + 1, x, y, hop=drop + bob, ph=t + i * .3)
    text(im, (80, 1150), f"부서 {len(ds)}개 · 매니저 1명, 오늘 첫 출근", font("Bold", 44), INK, ease((t - 1.9) / 0.4))


def s_manager(im, t):
    d = ImageDraw.Draw(im)
    text(im, (80, 150), "제일 먼저 출근한 사람", font("Bold", 44), SUB, ease(t / 0.4))
    v = ease((t - 0.2) / 0.5)
    text(im, (80, 230), MGR, font("ExtraBold", 130), INK, v, dy=int(40 * (1 - v)))
    # 왼쪽에서 걸어 들어와 자리에서 손 흔들기
    walk = ease((t - 0.3) / 1.0)
    x = -150 + (W // 2 + 150) * walk
    step = abs(math.sin(t * 14)) * 18 if walk < 1 else 0
    staff(im, d, 0, x, 820, s=2.2, hop=step, wave=walk >= 1, ph=t)
    for i, s in enumerate([f"제 말은 {MGR}이 먼저 듣고,", "맞는 부서로 넘겨요.", "끝나면 휴대폰으로 알려 줘요."]):
        text(im, (80, 930 + i * 70), s, font("Medium", 48), INK, ease((t - 1.3 - i * 0.3) / 0.4))


def s_depts(k):
    grp = ds[k:k + 4]

    def f(im, t):
        d = ImageDraw.Draw(im)
        text(im, (80, 140), "우리 회사 부서", font("Bold", 44), SUB, ease(t / 0.4))
        text(im, (80, 205), f"{len(ds)}개 중 {k + 1}~{k + len(grp)}", font("ExtraBold", 80), INK, ease((t - 0.1) / 0.4))
        for i, dep in enumerate(grp):
            v = ease((t - 0.35 - i * 0.28) / 0.5)
            if v <= 0: continue
            y = 360 + i * 205; dx = int((1 - v) * 700)
            col = PAL[(k + i + 1) % len(PAL)]
            lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); ld = ImageDraw.Draw(lay)
            ld.rounded_rectangle([80 + dx, y, W - 80 + dx, y + 180], radius=28, fill=(255, 255, 255, 255), outline=LINE, width=3)
            ld.rounded_rectangle([80 + dx, y, 104 + dx, y + 180], radius=12, fill=col)
            ld.text((140 + dx, y + 30), dep["이름"].split(" ", 1)[-1], font=font("ExtraBold", 54), fill=INK)
            for j, l in enumerate(wrap(ld, dep.get("일", ""), font("Medium", 36), W - 400)[:2]):
                ld.text((140 + dx, y + 100 + j * 42), l, font=font("Medium", 36), fill=SUB)
            im.alpha_composite(lay)
            # 카드 오른쪽 끝에 그 부서 직원이 뛰어오름
            pv = clamp((t - 0.6 - i * 0.28) / 0.4)
            if pv > 0:
                hop = (1 - back(pv)) * 120 + (abs(math.sin(t * 4 + i)) * 8 if pv >= 1 else 0)
                staff(im, ImageDraw.Draw(im), k + i + 1, W - 175 + dx, y + 160, s=0.95, hop=hop, ph=t + i)
        if len(grp) < 4:  # 빈 칸은 손 흔드는 매니저로
            y = 360 + len(grp) * 205 + 60
            v = clamp((t - 1.4) / 0.5)
            if v > 0:
                staff(im, d, 0, W // 2, y + 120, s=1.4, hop=(1 - back(v)) * 160, wave=v >= 1, ph=t)
    return f


ex = [d["예"] for d in ds if d.get("예")][:3]


def s_say(im, t):
    d = ImageDraw.Draw(im)
    text(im, (80, 150), "이제 이렇게 말하면 돼요", font("Bold", 44), SUB, ease(t / 0.4))
    text(im, (80, 220), "말 한마디면 끝", font("ExtraBold", 96), INK, ease((t - 0.15) / 0.4))
    for i, s in enumerate(ex):
        v = clamp((t - 0.5 - i * 0.55) / 0.35)
        if v <= 0: continue
        sc = back(v)
        y = 420 + i * 230; f = font("Bold", 46)
        ls = wrap(d, f"“{s}”", f, W - 420)[:2]
        bw = max(d.textlength(l, font=f) for l in ls) + 80; bh = 40 + 60 * len(ls)
        b = Image.new("RGBA", (int(bw), int(bh)), (0, 0, 0, 0)); bd = ImageDraw.Draw(b)
        bd.rounded_rectangle([0, 0, bw - 1, bh - 1], radius=34, fill=(10, 132, 255))
        for j, l in enumerate(ls): bd.text((40, 22 + j * 60), l, font=f, fill="white")
        b = b.resize((max(1, int(bw * sc)), max(1, int(bh * sc))))
        im.alpha_composite(b, (int(W - 80 - b.width), int(y + (bh - b.height) / 2)))
        # 말 걸면 그 부서 직원이 "넵!" 하고 튀어 오름
        j = next((n for n, dd in enumerate(ds) if dd.get("예") == s), i)
        pv = clamp((t - 0.75 - i * 0.55) / 0.35)
        if pv > 0:
            staff(im, d, j + 1, 190, y + bh + 10, s=0.9, hop=(1 - back(pv)) * 90 + (abs(math.sin(t * 4 + i)) * 8 if pv >= 1 and t < 99 else 0), ph=t)
            text(im, (150, y - 80), "넵!", font("ExtraBold", 40), (10, 132, 255), pv)


def s_end(im, t):
    d = ImageDraw.Draw(im)
    v1 = ease(t / 0.5); v2 = ease((t - 0.25) / 0.5)
    text(im, (80, 300), "오늘부터", font("ExtraBold", 110), INK, v1, dy=int(40 * (1 - v1)))
    text(im, (80, 430), "잘 부탁해요!", font("ExtraBold", 110), INK, v2, dy=int(40 * (1 - v2)))
    n = min(len(ds), 8)
    for i in range(n):  # 다 같이 파도처럼 점프
        x, y = row_pos(i, n)
        hop = max(0.0, math.sin(t * 6 - i * 0.6)) * 50 if t < 99 else 0
        staff(im, d, i + 1, x, y, hop=hop, wave=t < 99 and i % 2 == 0, ph=t + i)
    text(im, (80, 1150), f"부서 {len(ds)}개, 오늘부터 같이 일해요", font("Bold", 42), INK, ease((t - 0.8) / 0.4))


SCENES = [s_cover, s_manager] + [s_depts(k) for k in range(0, len(ds), 4)] + [s_say, s_end]
# 장면 길이 = 요소가 다 나오는 시간 + 읽을 시간(READ). 읽는 동안에도 캐릭터 모션은 계속 돈다
READ = 1.7  # 2026-11-07 대표님: 3초는 느림 → 1.7초
_last = lambda n: 1.4 if n < 4 else 0.35 + (n - 1) * 0.28 + 0.6  # 부서 카드 마지막 직원 착지
DUR = [2.4 + READ, 2.3 + READ] + [_last(len(ds[k:k + 4])) + READ + 0.5 for k in range(0, len(ds), 4)] \
    + [0.75 + (len(ex) - 1) * 0.55 + 0.4 + READ + 0.5, 1.3 + READ]


def frame(n, t):
    im = Image.new("RGBA", (W, H), BG + (255,))
    SCENES[n](im, t)
    foot(im, n + 1)
    return im.convert("RGB")


# 1) 카드
if "--영상만" not in sys.argv:
    for n in range(len(SCENES)):
        frame(n, 99).save(os.path.join(OUT, f"{n + 1:02d}.jpg"), quality=93)

# 2) 모션 숏폼 1080×1920 — 카드 판을 가운데, 위아래는 같은 바탕색 + 장면 사이 옆으로 밀기
if "--카드만" not in sys.argv:
    import imageio_ffmpeg
    FF = imageio_ffmpeg.get_ffmpeg_exe(); FPS = 30; VW, VH = 1080, 1920; TOP = (VH - H) // 2
    tmp = os.path.join(tempfile.mkdtemp(), "v.mp4")
    p = subprocess.Popen([FF, "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{VW}x{VH}", "-r", str(FPS), "-i", "-",
                          "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "20", tmp], stdin=subprocess.PIPE)
    TR = int(0.35 * FPS)
    for n, dur in enumerate(DUR):
        N = int(dur * FPS)
        for k in range(N):
            canvas = Image.new("RGB", (VW, VH), BG)
            cur = frame(n, k / FPS)
            if n + 1 < len(SCENES) and k >= N - TR:  # 다음 장면이 옆에서 밀고 들어옴
                v = ease((k - (N - TR)) / TR); off = int(VW * v)
                canvas.paste(cur, (-off, TOP)); canvas.paste(frame(n + 1, 0), (VW - off, TOP))
            else:
                canvas.paste(cur, (0, TOP))
            p.stdin.write(canvas.tobytes())
    p.stdin.close(); p.wait()
    dur = sum(DUR)
    bgm = os.path.join(KIT, "숏폼_배경음악.mp3")
    mp4 = os.path.join(OUT, "설치기념_01.mp4")
    if os.path.exists(bgm):
        subprocess.run([FF, "-y", "-loglevel", "error", "-i", tmp, "-stream_loop", "-1", "-i", bgm, "-t", f"{dur:.2f}",
                        "-filter_complex", f"[1:a]volume=0.6,afade=t=out:st={dur - 1.5:.2f}:d=1.5[a]", "-map", "0:v", "-map", "[a]",
                        "-c:v", "copy", "-c:a", "aac", "-b:a", "160k", "-shortest", mp4], check=True)
    else:
        os.replace(tmp, mp4)

names = " · ".join(d["이름"].split(" ", 1)[-1] for d in ds)
open(os.path.join(OUT, "캡션.txt"), "w", encoding="utf-8").write(
    f"오늘 퍼스널 OS를 설치했어요.\n내 컴퓨터 안에 {names}이 생겼어요.\n"
    f"부서마다 맡을 일을 정해 두니, 이제 일이 생기면 말 한마디로 맡길 수 있어요.\n\n#퍼스널OS #1인기업 #1인대표 #설치첫날")
open(os.path.join(OUT, "유튜브_제목.txt"), "w", encoding="utf-8").write("오늘 내 컴퓨터에 회사가 생겼어요 #퍼스널OS")

# 블로그 본문 — 사진 → 설명 → 사진 → 설명 (카드 글자만 옮기지 않고 블로그 글로 풀어 쓴다, 2026-11-08 대표님)
def _josa(w, a, b):
    ch = (w or " ")[-1]
    return w + (a if "가" <= ch <= "힣" and (ord(ch) - 0xAC00) % 28 else b)


_cards = []
_cards.append(["오늘 컴퓨터에 퍼스널 OS를 설치했어요.",
               f"설치를 마치고 화면을 열어 보니 부서 {len(ds)}개와 매니저 한 명이 자리를 잡고 있더라고요. 오늘은 이 친구들을 하나씩 소개해 볼게요."])
_cards.append([f"가장 먼저 만난 건 매니저 {_josa(MGR, '이에요', '예요')}.",
               "제가 하는 말을 먼저 듣고, 어느 부서 일인지 골라서 넘겨 주는 역할을 해요.",
               "일이 끝나면 휴대폰으로 알려 줘서, 자리에 없을 때도 진행 상황을 알 수 있어요."])
for k in range(0, len(ds), 4):
    grp = ds[k:k + 4]
    _cards.append(["다음은 부서들이에요." if k == 0 else "나머지 부서도 볼게요."]
                  + ["· " + d["이름"].split(" ", 1)[-1] + " — " + d.get("일", "") for d in grp]
                  + (["부서마다 맡는 일이 정해져 있어서, 일을 맡길 때 어디로 보낼지 따로 고민할 필요가 없어요."] if k + 4 >= len(ds) else []))
_cards.append(["쓰는 방법은 간단해요. 평소 말하듯 한 줄로 부탁하면 돼요. 예를 들면 이렇게요."]
              + ["“" + e + "”" for e in ex]
              + ["그러면 그 일을 맡는 부서가 받아서 처리해요."])
_cards.append(["오늘은 설치 첫날이라 부서와 직원을 둘러보는 정도로 마쳤어요.",
               "내일부터는 실제 일을 하나씩 맡겨 보면서 어떻게 쓰이는지 기록해 볼게요."])
_imgs = sorted(f for f in os.listdir(OUT) if re.match(r"\d\d\.jpg$", f))
json.dump({"제목": "오늘, 내 컴퓨터에 회사가 생겼어요",
           "카드": [{"사진": im, "글": _cards[i] if i < len(_cards) else []} for i, im in enumerate(_imgs)],
           "영상글": ["설치 첫날 모습을 짧은 영상으로도 담아 봤어요."],
           "태그": ["퍼스널OS", "1인기업", "1인대표", "설치첫날"]},
          open(os.path.join(OUT, "블로그_본문.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(OUT, f"카드 {len(SCENES)}장 · 영상 {sum(DUR):.1f}초 · 캐릭터 {STYLE if STAFF else '단순'}")
