﻿# 퍼스널 OS 설치 — 윈도우 시작 단계 (2026-10-24). 설치_윈도우.bat 이 이 파일을 '이번 한 번만 허용'(Bypass)으로 부른다.
# 하는 일: 인터넷에서 받은 파일 표시 지우기 → 파이썬 찾기(없으면 내 계정에만 설치, 관리자 필요 없음) → 설치기_윈도우.py 실행
$ErrorActionPreference = "Continue"
[Console]::OutputEncoding = [Text.Encoding]::UTF8
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Get-ChildItem -Recurse -Force (Split-Path $here) -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue

function Find-Py {
  foreach ($c in @("py", "python")) {
    $p = Get-Command $c -ErrorAction SilentlyContinue
    if ($p -and ($p.Source -notmatch "WindowsApps")) { return $p.Source }   # 마이크로소프트 스토어 가짜 python 은 건너뜀
  }
  $cand = Get-ChildItem "$env:LOCALAPPDATA\Programs\Python\Python3*\python.exe" -ErrorAction SilentlyContinue | Sort-Object FullName -Descending | Select-Object -First 1
  if ($cand) { return $cand.FullName }
  return $null
}
$py = Find-Py
if (-not $py) {
  Write-Host "`n  파이썬 설치 중 (2~3분, 내 계정에만 설치 — 관리자 승인 필요 없음)…"
  winget install -e --id Python.Python.3.12 --scope user --silent --accept-package-agreements --accept-source-agreements
  $py = Find-Py
}
if (-not $py) {
  Write-Host "`n  파이썬을 설치하지 못했어요. 열리는 python.org 에서 설치할 때 'Add python.exe to PATH' 를 꼭 체크하고, 이 파일을 다시 실행해 주세요."
  Start-Process "https://www.python.org/downloads/windows/"
  exit 1
}
$env:PYTHONUTF8 = "1"
& $py -X utf8 "$here\설치기_윈도우.py" @args
