# -*- coding: utf-8 -*-
"""퍼스널 OS 설치기 — 윈도우판 (2026-10-24). 설치_윈도우.bat → 설치_윈도우.ps1 → 이 파일.

맥판(설치기.py)의 단계를 그대로 쓰고, 맥에만 있는 부분만 윈도우 방식으로 바꾼다.
- 관리자 권한 없이: 파이썬·깃·클로드 코드·파일은 내 계정에만. 관리자 승인('예')은 테일스케일 설치 한 번뿐.
- 자동 시작: '시작 프로그램' 폴더(관리자 필요 없음) / 반복 업무: 내 계정 작업 스케줄러
- 서버는 윈도우_서버.py(맥 전용 기능을 윈도우 것으로 바꿔 끼우는 감싸개)로 띄운다.
몇 번을 다시 돌려도 안전하다."""
import json, os, re, shutil, subprocess, sys, time, urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import 설치기 as M                      # 맥판 단계 함수들을 빌려 쓴다

HOME = os.path.expanduser("~")
OS_DIR, KIT, DATA = M.OS_DIR, M.KIT, M.DATA
PY = sys.executable
PYW = os.path.join(os.path.dirname(PY), "pythonw.exe")
if not os.path.exists(PYW):
    PYW = PY
LOCALBIN = os.path.join(HOME, ".local", "bin")
CLAUDE = os.path.join(LOCALBIN, "claude.exe")
M.PY, M.CLAUDE = PY, CLAUDE
M.LOG = os.path.join(HOME, "퍼스널OS_설치기록.log")
NOWIN = 0x08000000
step, ok, warn, ask, log = M.step, M.ok, M.warn, M.ask, M.log


def run(cmd, **kw):
    return subprocess.run(cmd, shell=isinstance(cmd, str), capture_output=True, text=True, encoding="utf-8", errors="replace", **kw)
M.run = run


def ps(code, **kw):
    """한글이 든 명령도 깨지지 않게 UTF-16 으로 인코딩해 넘긴다"""
    import base64
    enc = base64.b64encode(("[Console]::OutputEncoding=[Text.Encoding]::UTF8; " + code).encode("utf-16-le")).decode()
    return run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-EncodedCommand", enc], **kw)


TEST = ("--시험" in sys.argv) or ("--test" in sys.argv)
CI = "--ci" in sys.argv                # 깃허브 윈도우 컴퓨터에서 자동 시험할 때(로그인·휴대폰·질문 없이)
if CI:
    M.ask = ask = lambda q, default="": {"비밀번호": "brand2026", "매니저가 부를 호칭": "대표님", "회사(브랜드) 이름": "시험회사"}.get(q, default)


def setx(name, value):
    if not TEST:                       # 시험 설치 때는 그 컴퓨터의 환경 변수를 바꾸지 않는다
        run(["setx", name, value])
    os.environ[name] = value


def which_bash():
    for p in (shutil.which("bash") or "", os.path.join(os.environ.get("ProgramFiles", r"C:\Program Files"), "Git", "bin", "bash.exe"),
              os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs", "Git", "bin", "bash.exe")):
        if p and os.path.exists(p) and "System32" not in p:      # System32\bash.exe 는 WSL — 쓰지 않는다
            return p
    return None


def winget(pkg, user=True):
    a = ["winget", "install", "-e", "--id", pkg, "--silent", "--accept-package-agreements", "--accept-source-agreements"]
    if user:
        a += ["--scope", "user"]
    return subprocess.run(a).returncode


# ───────────────────────── 1. 클로드 코드 (+ 깃 배시: 윈도우에서 클로드가 명령을 실행하는 데 필요)
def s_claude():
    step(1, "클로드 코드 (OS의 두뇌)")
    bash = which_bash()
    if not bash:
        print("   깃(Git) 설치 중 — 클로드가 일할 때 쓰는 도구예요 (2~3분, 내 계정에만)…")
        if winget("Git.Git") != 0:
            print("   내 계정 설치가 안 돼서 컴퓨터 전체 설치로 다시 시도합니다 — '예'를 눌러 주세요.")
            winget("Git.Git", user=False)
        bash = which_bash()
    if bash:
        setx("CLAUDE_CODE_GIT_BASH_PATH", bash)
        ok("깃 배시: " + bash)
    else:
        warn("깃을 설치하지 못했어요. git-scm.com 에서 설치한 뒤 설치_윈도우.bat 를 다시 실행해 주세요.")
        subprocess.run(["cmd", "/c", "start", "https://git-scm.com/download/win"])
        sys.exit(1)
    if os.path.exists(CLAUDE) or shutil.which("claude"):
        ok("클로드 코드 이미 설치돼 있음")
    else:
        print("   공식 설치 프로그램을 받습니다 (1~2분)…")
        subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", "irm https://claude.ai/install.ps1 | iex"])
        if os.path.exists(CLAUDE):
            ok("설치 완료")
        else:
            warn("설치가 끝나지 않았습니다. 인터넷(핫스팟)을 확인하고 설치_윈도우.bat 를 다시 실행해 주세요.")
            sys.exit(1)
    # 내 계정 PATH 에 ~/.local/bin (클로드·python3 바로가기)
    up = ps("[Environment]::GetEnvironmentVariable('Path','User')").stdout.strip()
    if LOCALBIN.lower() not in up.lower() and not TEST:
        ps("[Environment]::SetEnvironmentVariable('Path', '%s;' + [Environment]::GetEnvironmentVariable('Path','User'), 'User')" % LOCALBIN)
    os.environ["PATH"] = LOCALBIN + os.pathsep + os.environ.get("PATH", "")
    setx("PYTHONUTF8", "1")                                          # 한글 깨짐 방지(모든 파이썬)


def logged_in():
    try:
        r = run([CLAUDE, "-p", "ok", "--max-turns", "1"], timeout=120, cwd=HOME)
    except Exception:
        return False
    low = ((r.stdout or "") + (r.stderr or "")).lower()
    return r.returncode == 0 and "invalid api key" not in low and "please run /login" not in low and "oauth" not in low
M.logged_in = logged_in


def s_login():
    step("1-2", "클로드 로그인 (설치 중 한 번만)")
    M.trust_folders()
    for n in range(3):
        if logged_in():
            ok("로그인돼 있음")
            return
        print("   클로드 창이 열리면: ① /login 입력 → 엔터 ② 'Claude account with subscription' → 브라우저에서 로그인·승인")
        print("   ③ 'Login successful' 이 보이면 엔터 → /exit 입력 → 설치가 이어집니다 (이 창을 닫지 마세요)")
        subprocess.call([CLAUDE, "--dangerously-skip-permissions"], cwd=HOME)
    warn("로그인이 아직 안 됐습니다. 설치는 계속하고, 나중에 설치_윈도우.bat 를 다시 실행하면 이 단계부터 합니다.")


# ───────────────────────── 2. 부품
def s_parts():
    step(2, "휴대폰 알림·그림 부품")
    run([PY, "-m", "pip", "install", "--user", "--quiet", "--upgrade", "pip"])
    r = run([PY, "-m", "pip", "install", "--user", "--quiet", "pywebpush", "pillow"])
    if run([PY, "-c", "import pywebpush, py_vapid"]).returncode == 0:
        ok("설치 완료")
    else:
        warn("알림 부품 설치 실패 — 알림만 안 되고 나머지는 됩니다. (%s)" % (r.stderr or "")[-200:])


# ───────────────────────── 3-2. 윈도우 손질 — 깔린 파일에서 맥 전용 부분 바꾸기
FCNTL = '''# 윈도우에는 fcntl 이 없다 — 파일 잠금을 msvcrt 로 대신하는 작은 대역 (퍼스널 OS 윈도우판)
import msvcrt, os
LOCK_EX, LOCK_SH, LOCK_UN, LOCK_NB = 2, 1, 8, 4
def flock(f, op):
    fd = f if isinstance(f, int) else f.fileno()
    try:
        os.lseek(fd, 0, 0)
        msvcrt.locking(fd, msvcrt.LK_UNLCK if op & LOCK_UN else msvcrt.LK_LOCK, 1)
    except OSError:
        pass
'''
USAGE_NEW = '''def usage_token():
    """(윈도우판) 클로드 로그인 정보는 ~/.claude/.credentials.json 에 있다."""
    try:
        d = json.load(open(os.path.expanduser("~/.claude/.credentials.json"), encoding="utf-8"))
        return (d.get("claudeAiOauth") or d).get("accessToken")
    except Exception:
        return None
'''


def s_winfix():
    step("3-2", "윈도우에 맞게 손질")
    open(os.path.join(OS_DIR, "fcntl.py"), "w", encoding="utf-8").write(FCNTL)
    sv = os.path.join(OS_DIR, "elvin_server.py")
    t = open(sv, encoding="utf-8").read()
    t = t.replace('env["PATH"] = ":".join(', 'env["PATH"] = os.pathsep.join(')
    t = re.sub(r"def usage_token\(\):.*?\n(?=def )", USAGE_NEW + "\n", t, count=1, flags=re.S)
    open(sv, "w", encoding="utf-8").write(t)
    # python3 바로가기(깃 배시에서 'python3 …' 이 되게) + .sh 안의 /usr/bin/python3
    os.makedirs(LOCALBIN, exist_ok=True)
    pyu = PY.replace("\\", "/")
    open(os.path.join(LOCALBIN, "python3"), "w", encoding="utf-8", newline="\n").write('#!/bin/sh\nexec "%s" -X utf8 "$@"\n' % pyu)
    n = 0
    for d, ds, fs in os.walk(OS_DIR):
        if ".os_데이터" in d:
            continue
        for f in fs:
            if f.endswith(".sh"):
                p = os.path.join(d, f)
                s = open(p, encoding="utf-8").read()
                s2 = s.replace("/usr/bin/python3", "python3")
                if s2 != s:
                    open(p, "w", encoding="utf-8", newline="\n").write(s2); n += 1
    # 매니저 지침에 윈도우 안내 덧붙이기(추가지침 → 적용.py 가 맨 위 지침에 붙임)
    ad = os.path.join(OS_DIR, "부서", "00_비서실", "추가지침.md")
    s = open(ad, encoding="utf-8").read() if os.path.exists(ad) else ""
    if "## 윈도우 컴퓨터" not in s:
        s += ("\n\n## 윈도우 컴퓨터 (설치기가 넣음)\n"
              "- 이 OS는 윈도우에서 돈다. 명령은 깃 배시로 실행된다. 파이썬은 `python3`(안 되면 `py`).\n"
              "- 서버 다시 띄우기: `python3 ~/퍼스널OS/.os_키트/윈도우_서버재시작.py` 만 쓴다(맥용 떼어내기.py·서버재시작.sh·launchctl 은 윈도우에 없다).\n"
              "- 자동 업무 등록은 '작업 스케줄러'(schtasks, 내 계정)로 한다. 맥의 LaunchAgents·osascript·화면 조작(손.sh)은 없다.\n"
              "- 노트북이면 덮거나 잠자기에 들어가면 일을 멈춘다. 전원 연결 상태로 켜 두시게 안내한다.\n")
        open(ad, "w", encoding="utf-8").write(s)
    run([PY, os.path.join(KIT, "적용.py")])
    ok("파일 손질 (.sh %d개, 서버, fcntl 대역, python3 바로가기)" % n)


# ───────────────────────── 5. 자동 실행
def vbs(path, args, hidden=True):
    q = lambda s: '"' + s.replace('"', '""') + '"'
    body = ('Set sh = CreateObject("WScript.Shell")\r\nsh.CurrentDirectory = %s\r\nsh.Run %s, %d, False\r\n'
            % (q(OS_DIR), q(" ".join('"%s"' % a for a in args)), 0 if hidden else 1))
    open(path, "w", encoding="utf-16").write(body)          # 한글 경로 때문에 UTF-16 으로 저장


def s_agents():
    step(5, "자동 실행 등록 (컴퓨터를 켜면 알아서 출근)")
    startup = ps("[Environment]::GetFolderPath('Startup')").stdout.strip()
    sv = os.path.join(startup, "퍼스널OS_서버.vbs")
    vbs(sv, [PYW, "-X", "utf8", os.path.join(KIT, "윈도우_서버.py"), "--phone"])
    ok("시작 프로그램에 서버 등록")
    bash = which_bash() or "bash.exe"
    b = os.path.join(OS_DIR, "부서", "00_비서실")
    jobs = [
        ("morningbrief", ["/SC", "MINUTE", "/MO", "10"], [PYW, "-X", "utf8", os.path.join(b, "자동", "아침브리핑.py")]),   # ☀️ 먼저 말 걸기
        ("calendarcache", ["/SC", "DAILY", "/ST", "10:00"], [bash, os.path.join(b, "자동", "캘린더_캐시.sh")]),
        ("calendarcache2", ["/SC", "DAILY", "/ST", "13:00"], [bash, os.path.join(b, "자동", "캘린더_캐시.sh")]),
        ("calendarcache3", ["/SC", "DAILY", "/ST", "17:00"], [bash, os.path.join(b, "자동", "캘린더_캐시.sh")]),
        ("vaultbackup", ["/SC", "DAILY", "/ST", "23:40"], [bash, os.path.join(b, "백업", "금고백업.sh")]),
        ("gitbackup", ["/SC", "DAILY", "/ST", "04:00"], [PY, os.path.join(b, "백업", "깃백업.py")]),
    ]
    for name, sch, cmd in jobs:
        if not os.path.exists(cmd[-1]):
            continue
        tr = " ".join('"%s"' % c for c in cmd)
        r = run(["schtasks", "/Create", "/F", "/TN", "PersonalOS\\" + name, "/TR", tr] + sch)
        ok(name) if r.returncode == 0 else warn("%s 등록 실패: %s" % (name, (r.stderr or r.stdout)[-150:]))
    # 인계노트 훅(맥판과 같게, 파이썬 경로만 윈도우 것)
    M.PY = PY.replace("\\", "/")
    try:
        sp = os.path.join(OS_DIR, ".claude", "settings.json"); os.makedirs(os.path.dirname(sp), exist_ok=True)
        st = json.load(open(sp, encoding="utf-8")) if os.path.exists(sp) else {}
        hk = st.setdefault("hooks", {})
        hk["PreCompact"] = [{"matcher": "", "hooks": [{"type": "command", "command": '"%s" "$CLAUDE_PROJECT_DIR/부서/00_비서실/백업/인계노트_저장.py"' % M.PY, "timeout": 60}]}]
        hk["SessionStart"] = [{"matcher": "compact", "hooks": [{"type": "command", "command": '"%s" "$CLAUDE_PROJECT_DIR/부서/00_비서실/백업/인계노트_읽기.py"' % M.PY, "timeout": 30}]}]
        json.dump(st, open(sp, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    except Exception as e:
        warn("인계노트 훅 등록 실패 — %s" % e)
    M.PY = PY
    # 지금 바로 서버 켜기
    subprocess.Popen(["wscript", sv])
    for i in range(25):
        try:
            urllib.request.urlopen("http://127.0.0.1:8765/api/hello", timeout=2)
            ok("앱 서버 켜짐 — http://127.0.0.1:8765")
            return True
        except Exception:
            time.sleep(1)
    warn("앱 서버가 아직 안 떴습니다. 로그: 퍼스널OS\\.os_데이터\\앱.log")
    return False


# ───────────────────────── 5-2. 전원(노트북 덮어도 계속)
def s_power():
    step("5-2", "전원 설정 — 전원 연결 시 잠자기·덮개 닫기에도 계속 일하기")
    run(["powercfg", "/change", "standby-timeout-ac", "0"])
    run(["powercfg", "/setacvalueindex", "SCHEME_CURRENT", "SUB_BUTTONS", "LIDACTION", "0"])
    run(["powercfg", "/setactive", "SCHEME_CURRENT"])
    ok("전원 연결 상태에서는 잠자기 안 함 · 덮개를 닫아도 계속(배터리일 때는 원래대로)")


# ───────────────────────── 6. 휴대폰 연결
def ts_exe():
    for p in (shutil.which("tailscale") or "", os.path.join(os.environ.get("ProgramFiles", r"C:\Program Files"), "Tailscale", "tailscale.exe")):
        if p and os.path.exists(p):
            return p
    return None


def s_phone():
    step(6, "휴대폰 연결 (테일스케일)")
    ts = ts_exe()
    if not ts:
        print("   테일스케일 설치 — 곧 '이 앱이 디바이스를 변경하도록 허용?' 창이 뜨면 [예]를 눌러 주세요(이번 설치에서 딱 한 번).")
        winget("tailscale.tailscale", user=False)
        ts = ts_exe()
    if not ts:
        warn("테일스케일을 설치하지 못했어요. tailscale.com/download 에서 설치·로그인한 뒤 휴대폰연결_윈도우.bat 를 실행해 주세요.")
        subprocess.run(["cmd", "/c", "start", "https://tailscale.com/download/windows"])
        return
    if run([ts, "status"]).returncode != 0:
        subprocess.Popen([ts, "login"])
        warn("열리는 브라우저에서 테일스케일에 로그인해 주세요(휴대폰과 같은 계정). 로그인 뒤 휴대폰연결_윈도우.bat 를 실행하세요.")
        return
    run([ts, "serve", "--bg", "--https=443", "http://127.0.0.1:8765"])
    try:
        dns = json.loads(run([ts, "status", "--json"]).stdout)["Self"]["DNSName"].rstrip(".")
    except Exception:
        dns = ""
    if not dns:
        warn("주소를 못 읽었습니다. 테일스케일 로그인 상태를 확인해 주세요.")
        return
    url = "https://" + dns
    conf_p = os.path.join(OS_DIR, "설정.json")
    c = json.load(open(conf_p, encoding="utf-8"))
    if c.get("보안주소") != url:
        c["보안주소"] = url
        json.dump(c, open(conf_p, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        run([PY, os.path.join(KIT, "적용.py")])
    ok("휴대폰 주소: " + url)
    print("   → 휴대폰에 Tailscale 앱 → 같은 계정 로그인 → 위 주소 열기 → 홈 화면에 추가")
    print("   → 삼성 등 안드로이드: Tailscale ⚙ → '앱별 분할 터널링'에서 크롬만 · '항상 켜진 VPN' 끄기 (삼성페이·은행 앱 막힘 방지)")


# ───────────────────────── 6-2. 바탕화면 앱
def browser():
    for p in (os.path.join(os.environ.get("ProgramFiles", ""), r"Google\Chrome\Application\chrome.exe"),
              os.path.join(os.environ.get("ProgramFiles(x86)", ""), r"Google\Chrome\Application\chrome.exe"),
              os.path.join(os.environ.get("LOCALAPPDATA", ""), r"Google\Chrome\Application\chrome.exe"),
              os.path.join(os.environ.get("ProgramFiles(x86)", ""), r"Microsoft\Edge\Application\msedge.exe"),
              os.path.join(os.environ.get("ProgramFiles", ""), r"Microsoft\Edge\Application\msedge.exe")):
        if p and os.path.exists(p):
            return p
    return None


def s_app():
    step("6-2", "바탕화면에 앱 아이콘 만들기")
    br = browser()
    asc = os.path.join(os.environ.get("LOCALAPPDATA", HOME), "PersonalOS")        # 바로가기 도구가 한글 경로를 못 읽어 영문 폴더에 아이콘을 둔다
    os.makedirs(asc, exist_ok=True)
    ico = os.path.join(asc, "icon.ico")
    png = os.path.join(OS_DIR, "os_아이콘.png")
    if os.path.exists(png):
        run([PY, "-c", "from PIL import Image;Image.open(r'%s').save(r'%s',sizes=[(256,256),(64,64),(32,32),(16,16)])" % (png, ico)])
    code = ("$d=[Environment]::GetFolderPath('Desktop'); New-Item -ItemType Directory -Force $d | Out-Null; "
            "$t=Join-Path $d 'PersonalOS_tmp.lnk'; $s=(New-Object -ComObject WScript.Shell).CreateShortcut($t); "
            "$s.TargetPath='%s'; $s.Arguments='%s'; %s $s.Save(); "
            "Move-Item -Force $t (Join-Path $d '퍼스널 OS.lnk')"
            % (br or "http://127.0.0.1:8765", "--app=http://127.0.0.1:8765 --window-size=1440,900" if br else "",
               ("$s.IconLocation='%s';" % ico) if os.path.exists(ico) else ""))
    r = ps(code)
    ok("바탕화면에 '퍼스널 OS' 아이콘") if r.returncode == 0 else warn("아이콘 만들기 실패: " + (r.stderr or "")[-150:])

def port_busy(port=8765):
    import socket
    s = socket.socket(); s.settimeout(1)
    try:
        return s.connect_ex(("127.0.0.1", port)) == 0
    finally:
        s.close()


def test_mode():
    """--시험: 이미 다른 OS를 쓰는 컴퓨터(지호 실장님 PC 등)에서 시험할 때. 그 컴퓨터 설정은 건드리지 않는다.
    빼는 것: 시작 프로그램·작업 스케줄러·전원 설정·테일스케일(휴대폰 주소). 서버는 이 창에서만 잠깐 띄운다."""
    print("\n  [시험 설치] 이 컴퓨터의 기존 설정(테일스케일·자동 시작·전원)은 건드리지 않습니다.")
    if os.path.exists(OS_DIR) and not os.path.exists(os.path.join(OS_DIR, "설정.json")):
        warn("~/퍼스널OS 폴더가 이미 있는데 우리 것이 아닙니다 — 덮어쓰지 않으려고 멈춥니다."); sys.exit(1)
    if port_busy():
        warn("8765 번 자리를 이미 다른 프로그램이 쓰고 있습니다(기존 OS 서버일 수 있음) — 시험을 멈춥니다."); sys.exit(1)
    s_claude(); s_login(); s_parts(); M.s_files(); s_winfix(); M.s_hello()
    step("시험", "서버를 이 창에서 띄웁니다 — 브라우저에서 http://127.0.0.1:8765 확인 후 이 창을 닫으면 꺼집니다")
    br = browser()
    subprocess.Popen([br, "--app=http://127.0.0.1:8765"] if br else ["cmd", "/c", "start", "http://127.0.0.1:8765"])
    subprocess.call([PY, "-X", "utf8", os.path.join(KIT, "윈도우_서버.py")])


def main():
    M.nfc_tree(os.path.dirname(HERE))
    print("\n  퍼스널 OS 설치 (윈도우) — BRANDiUM · keda\n  중간에 멈춰도 괜찮습니다. 다시 실행하면 이어서 합니다.")
    if "--phone" in sys.argv:
        s_phone(); return
    if "--시험" in sys.argv or "--test" in sys.argv:
        test_mode(); return
    if CI:
        s_claude(); s_parts(); M.s_files(); s_winfix(); M.s_hello(); s_agents(); s_power(); s_app()
        print("CI 끝"); return
    s_claude()
    s_login()
    s_parts()
    M.s_files()
    s_winfix()
    M.s_hello()
    s_agents()
    s_power()
    s_phone()
    s_app()
    step(7, "연결하기 — 구글 캘린더 · 지메일 · 구글 드라이브 · 노션")
    print("   열리는 클로드 설정(커넥터) 화면에서 ① Google Calendar ② Gmail ③ Google Drive ④ Notion 을 각각 [연결] → 같은 계정으로 허용")
    subprocess.run(["cmd", "/c", "start", "https://claude.ai/settings/connectors"])
    try:
        input("   네 개 다 연결하셨으면 엔터 ↵ (나중에 하려면 그냥 엔터)")
    except EOFError:
        pass
    step(8, "마무리 — 퍼스널 OS 열기")
    pw = json.load(open(os.path.join(OS_DIR, "설정.json"), encoding="utf-8")).get("비밀번호", "")
    br = browser()
    subprocess.Popen([br, "--app=http://127.0.0.1:8765"] if br else ["cmd", "/c", "start", "http://127.0.0.1:8765"])
    ok("설치 끝 — 바탕화면 '퍼스널 OS' 아이콘으로 열립니다. 처음 들어갈 때 비밀번호: %s" % pw)


if __name__ == "__main__":
    main()
