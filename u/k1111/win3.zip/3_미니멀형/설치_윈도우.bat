@echo off
chcp 65001 >nul
cd /d "%~dp0"
rem 퍼스널 OS 설치 (윈도우) - 더블클릭하세요. 파란 창 "Windows의 PC 보호"가 뜨면 [추가 정보] - [실행]
powershell -NoProfile -ExecutionPolicy Bypass -File ".os_키트\설치_윈도우.ps1" %*
pause
