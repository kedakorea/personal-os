@echo off
chcp 65001 >nul
cd /d "%~dp0"
rem 시험 설치 - 이미 다른 퍼스널 OS를 쓰는 컴퓨터용(기존 설정은 건드리지 않음)
powershell -NoProfile -ExecutionPolicy Bypass -File ".os_키트\설치_윈도우.ps1" --test
pause
